import React, { useEffect, useState } from 'react';

/* =====================================================================
   TERRASSE – IKEA-manual
   Hvert steg er delt i små deler. Hver del vises på tre måter:
     1) kort tekst med dine egne mål
     2) en IKEA-tegning (strektegning med deler, antall og mål)
     3) 3D der den nye delen faller på plass i din terrasse
   + en plass for ekte video (fylles inn i TERRASSE_VIDEO under).

   Tallene kommer fra:
   - BJELKE_SPENN: kopi av den verifiserte tabellen i TamerFixApp.jsx
     (NOBB/Norsk Byggtjeneste, C24, snølast 4,5 kN/m²). HOLD LIK.
   - Dragerspenn 1,4 m for 48×198: Byggforsk 526.413 (lastbredde 1,75 m).
     Derfor holdes avstanden mellom dragerne på maks 1,75 m.
   - c/c 600 bjelker, 2 skruer per bjelke, 5×100 i hjørner (forbores):
     Byggmax / XL-Bygg / Bolighjelpa.
   - Rekkverk: påkrevd ved ≥ 0,5 m (TEK17 §12-11), min 1,0 m høyt og
     åpninger maks 10 cm (TEK17 §12-15), stendere maks 80 cm (Moelven).
   - Søknadsfri: gulv maks 0,5 m over terreng (Huseierne/Byggmakker).
   ===================================================================== */

/* Ekte videoer: lim inn lenke (mp4) når snekkeren har filmet steget.
   Tom = 3D-animasjonen vises i stedet. Rekkefølgen følger stegene. */
export const TERRASSE_VIDEO = ['', '', '', '', '', ''];

export const BJELKE_SPENN_600 = { '48x98': 1.6, '48x123': 2.0, '48x148': 2.3, '48x173': 2.7, '48x198': 3.1, '48x223': 3.5 };
const DRAGER_DIM = '48x198';
const DRAGER_SPENN = 1.4; // maks stolpeavstand, verifisert ved lastbredde ≤ 1,75 m
const MAKS_LASTBREDDE = 1.75;
const CC = 0.6;
const BORD_B = 0.12, FUGE = 0.005, BORD_T = 0.028;

const cm = (m) => Math.round(m * 100);

/* ---------- beregning: én kilde for tegning, 3D og materialliste ---------- */
export function terrasseGeo({ b, l, h }) {
  const nDr = Math.max(2, Math.ceil(l / MAKS_LASTBREDDE) + 1);
  const drAvst = l / (nDr - 1);
  const bjelkeDim = Object.keys(BJELKE_SPENN_600).find((d) => BJELKE_SPENN_600[d] >= drAvst) || null;
  const bjelkeH = bjelkeDim ? Number(bjelkeDim.split('x')[1]) / 1000 : 0.223;
  const nSt = Math.ceil(b / DRAGER_SPENN) + 1;
  const stAvst = b / (nSt - 1);
  const nBj = Math.ceil(b / CC) + 1;
  const bjAvst = b / (nBj - 1);
  const nBord = Math.ceil(l / (BORD_B + FUGE));
  const stolpeH = h - BORD_T - bjelkeH - 0.198;
  const rekkverk = h >= 0.5;
  const stenderPrSide = (len) => Math.ceil(len / 0.8) + 1;
  const nStender = rekkverk ? stenderPrSide(b) + 2 * (stenderPrSide(l) - 1) : 0;
  const varsler = [];
  if (!bjelkeDim) varsler.push('Ingen bjelke i tabellen dekker spennet – kontakt fagperson.');
  if (stolpeH < 0) varsler.push(`Høyden ${cm(h)} cm er for lav for drager + bjelke + bord (${cm(BORD_T + bjelkeH + 0.198)} cm). Senk bakken eller velg lavere oppbygging.`);
  if (h > 0.5) varsler.push('Gulvet blir over 0,5 m – da må du normalt søke kommunen.');
  return {
    b, l, h, nDr, drAvst, bjelkeDim, bjelkeH, nSt, stAvst, nBj, bjAvst, nBord,
    stolpeH: Math.max(0, stolpeH), utenStolpe: stolpeH < 0.05, rekkverk, nStender,
    diag: Math.sqrt(b * b + l * l), punkter: nDr * nSt, varsler,
  };
}

/* ---------- 3D-bokser med merkelapper (tag) ---------- */
export function terrasseBokser(p) {
  const g = terrasseGeo(p.mal); const { b, l } = g; const bx = [];
  const H = Math.max(g.h, BORD_T + g.bjelkeH + 0.198);
  const zDr = g.stolpeH, zBj = zDr + 0.198, zBord = zBj + g.bjelkeH;
  const add = (tag, o) => bx.push({ tag, ...o });
  for (const [x, y] of [[0, 0], [b, 0], [0, l], [b, l]]) add('snor', { x: x - 0.03, y: y - 0.03, z: 0, w: 0.06, d: 0.06, h: 0.35, c: '#e0e0e0' });
  add('snor', { x: 0, y: 0, z: 0.3, w: b, d: 0.015, h: 0.015, c: '#ff5a36' }); add('snor', { x: 0, y: l, z: 0.3, w: b, d: 0.015, h: 0.015, c: '#ff5a36' });
  add('snor', { x: 0, y: 0, z: 0.3, w: 0.015, d: l, h: 0.015, c: '#ff5a36' }); add('snor', { x: b, y: 0, z: 0.3, w: 0.015, d: l, h: 0.015, c: '#ff5a36' });
  const dy = (j) => Math.min(j * g.drAvst, l - 0.1);
  const sx = (i) => Math.min(i * g.stAvst, b - 0.1);
  for (let j = 0; j < g.nDr; j++) for (let i = 0; i < g.nSt; i++) {
    add('punkt', { x: sx(i) + 0.02, y: dy(j) + 0.02, z: 0, w: 0.06, d: 0.06, h: 0.02, c: '#ff5a36' });
    add('fundament', { x: sx(i) - 0.05, y: dy(j) - 0.05, z: -0.02, w: 0.2, d: 0.2, h: 0.06, c: '#B8C4B0' });
    add('sko', { x: sx(i) - 0.005, y: dy(j) - 0.005, z: 0.04, w: 0.11, d: 0.11, h: 0.04, c: '#6d7a84' });
    if (!g.utenStolpe) add('stolpe', { x: sx(i), y: dy(j), z: 0.08, w: 0.1, d: 0.1, h: Math.max(0.02, zDr - 0.08), c: '#A6412F' });
  }
  for (let j = 0; j < g.nDr; j++) add('drager', { x: 0, y: dy(j), z: zDr, w: b, d: 0.1, h: 0.198, c: '#184c6e' });
  for (let i = 0; i < g.nBj; i++) add('bjelke', { x: Math.min(i * g.bjAvst, b - 0.048), y: 0, z: zBj, w: 0.048, d: l, h: g.bjelkeH, c: '#1D5F8A' });
  for (let k = 0; k < g.nBord; k++) add(k === 0 ? 'bord1' : 'bord', { x: 0, y: Math.min(k * (BORD_B + FUGE), l - BORD_B), z: zBord, w: b, d: BORD_B, h: BORD_T, c: k % 2 ? '#d4b27a' : '#C9A66B' });
  if (g.rekkverk) {
    const top = zBord + BORD_T;
    const poster = (len) => Array.from({ length: Math.ceil(len / 0.8) + 1 }, (_, i) => Math.min(i * (len / Math.ceil(len / 0.8)), len - 0.07));
    poster(b).forEach((x) => add('stender', { x, y: 0, z: top, w: 0.07, d: 0.07, h: 1.0, c: '#c79a60' }));
    poster(l).slice(1).forEach((y) => { add('stender', { x: 0, y, z: top, w: 0.07, d: 0.07, h: 1.0, c: '#c79a60' }); add('stender', { x: b - 0.07, y, z: top, w: 0.07, d: 0.07, h: 1.0, c: '#c79a60' }); });
    add('list', { x: 0, y: 0, z: top + 0.96, w: b, d: 0.09, h: 0.045, c: '#b98c52' });
    add('list', { x: 0, y: 0, z: top + 0.96, w: 0.09, d: l, h: 0.045, c: '#b98c52' });
    add('list', { x: b - 0.09, y: 0, z: top + 0.96, w: 0.09, d: l, h: 0.045, c: '#b98c52' });
    for (let x = 0.1; x < b - 0.1; x += 0.12) add('spiler', { x, y: 0.02, z: top + 0.05, w: 0.036, d: 0.036, h: 0.9, c: '#d6ad74' });
    for (let y = 0.12; y < l - 0.1; y += 0.12) { add('spiler', { x: 0.02, y, z: top + 0.05, w: 0.036, d: 0.036, h: 0.9, c: '#d6ad74' }); add('spiler', { x: b - 0.056, y, z: top + 0.05, w: 0.036, d: 0.036, h: 0.9, c: '#d6ad74' }); }
  }
  if (H > 0.25) {
    const tr = Math.max(1, Math.round(H / 0.18));
    for (let k = 0; k < tr; k++) add('trapp', { x: b / 2 - 0.6, y: l + k * 0.28, z: 0, w: 1.2, d: 0.28, h: H - (k + 1) * (H / (tr + 1)) + 0.03, c: '#d09c5c' });
  }
  return bx;
}

/* ---------- delene i hvert steg ---------- */
export function terrasseDeler(p) {
  const g = terrasseGeo(p.mal);
  const D = (tittel, tegning, tekst, deler, ny) => ({ tittel, tegning, tekst, deler, ny });
  const bj = g.bjelkeDim ? g.bjelkeDim.replace('x', ' × ') : '—';
  return [
    [
      D('Sett plugger i hjørnene', 'snor', `Slå ned én plugg i hvert hjørne: ${cm(g.b)} × ${cm(g.l)} cm. Strekk snor mellom pluggene ca. 30 cm over bakken. Snoren er ytterkanten av terrassen.`, [['plugg', 4], ['snor', 1]], ['snor']),
      D('Sjekk at hjørnene er rette', 'diagonal', `Mål begge diagonalene fra hjørne til hjørne. Begge skal være ${cm(g.diag)} cm. Er de ulike, flytt én plugg til de er like lange.`, [['maalebaand', 1]], []),
      D('Fjern gress og legg duk', 'grunn', 'Fjern gress og matjord innenfor snoren. Legg fiberduk over hele flaten så ugress ikke vokser opp gjennom terrassen.', [['spade', 1], ['duk', 1]], []),
    ],
    [
      D('Merk fundamentpunktene', 'punkter', `Du trenger ${g.punkter} fundamenter: ${g.nDr} rader med ${g.nSt} i hver. Avstand langs raden: ${cm(g.stAvst)} cm. Avstand mellom radene: ${cm(g.drAvst)} cm.`, [['merkespray', 1]], ['punkt']),
      D('Grav og støp fundament', 'hull', 'Grav ned til telefri dybde – den varierer fra sted til sted, så sjekk hva som gjelder hos deg (kommunen eller byggevarehuset). Er grunnen myk eller ujevn, bruk betongsøyler.', [['betongsoyle', g.punkter], ['betong', 1]], ['fundament']),
      D('Sett stolpesko i lodd', 'lodd', `Støp inn en justerbar stolpesko i hvert fundament (${g.punkter} stk). Sjekk med vater i begge retninger før betongen herder.`, [['stolpesko', g.punkter], ['vater', 1]], ['sko']),
    ],
    [
      D(g.utenStolpe ? 'Legg dragerne på fundamentene' : 'Stolper og dragere', 'drager', g.utenStolpe
        ? `Terrassen er så lav at dragerne (${DRAGER_DIM.replace('x', ' × ')}) festes rett i stolpeskoene. ${g.nDr} dragere à ${cm(g.b)} cm.`
        : `Kapp ${g.punkter} stolper (98 × 98) til ${cm(g.stolpeH)} cm. Legg ${g.nDr} dragere (${DRAGER_DIM.replace('x', ' × ')}) à ${cm(g.b)} cm oppå. Maks ${cm(DRAGER_SPENN)} cm mellom stolpene. Fest med 2 treskruer 6,0 × 120 per stolpe.`,
      [['stolpe', g.utenStolpe ? 0 : g.punkter], ['drager', g.nDr], ['skrue6x120', g.punkter * 2]], ['stolpe', 'drager']),
      D('Legg bjelkene c/c 60', 'bjelker', `Legg ${g.nBj} bjelker (${bj}) à ${cm(g.l)} cm på tvers av dragerne. Avstand senter–senter: ${cm(g.bjAvst)} cm.`, [['bjelke', g.nBj]], ['bjelke']),
      D('Fest bjelkene', 'beslag', `Fest hver bjelke til dragerne med vinkelbeslag og beslagspiker 4,0 × 40. I hjørnene: 2 skruer 5,0 × 100 – forbor først så treet ikke sprekker.`, [['beslag', g.nBj * g.nDr * 2], ['skrue5x100', 8]], []),
      D('Kontroller vater', 'vater', 'Legg vateret over flere bjelker på skrå. Juster stolpeskoene til boblen står midt i – før du legger ett eneste bord.', [['vater', 1]], []),
    ],
    [
      D('Legg første bord', 'forste', 'Start ved husveggen. Første bord må ligge helt rett – det styrer alle de andre. Kjerneveden (årringene) skal vende opp.', [['bord', 1]], ['bord1']),
      D('Skru fast bordene', 'skru', `2 skruer i hvert bord på hver bjelke, midt over bjelken. Hold 5 mm fuge mellom bordene. Totalt ${g.nBord} bordrader.`, [['bord', g.nBord], ['skrue5x70', g.nBord * g.nBj * 2]], ['bord']),
      D('Forskyv skjøtene', 'skjot', 'Må du skjøte, legg skjøten midt over en bjelke. La skjøtene i nabobord ligge på ulike bjelker – aldri side om side.', [], []),
      D('Kapp endene til slutt', 'kapp', 'La bordene stikke litt utenfor. Strekk snor langs kanten og kapp alle endene i én rett linje til slutt.', [['sag', 1]], []),
    ],
    [
      D(g.rekkverk ? 'Rekkverksstolper' : 'Rekkverk (valgfritt)', 'stender', g.rekkverk
        ? `Terrassen er ${cm(g.h)} cm høy, så rekkverk er påkrevd (TEK17). Sett ${g.nStender} stendere, maks 80 cm mellom hver. Fest i bjelkelaget, ikke bare i bordene.`
        : `Terrassen er ${cm(g.h)} cm høy – under 50 cm er rekkverk ikke påkrevd. Vil du ha det likevel: maks 80 cm mellom stenderne.`, [['stender', g.nStender]], ['stender']),
      D('Håndlist 100 cm over gulvet', 'list', 'Monter håndlisten på toppen av stenderne. Den skal være minst 100 cm over terrassegulvet.', [['list', 1]], ['list']),
      D('Spiler – maks 10 cm åpning', 'spiler', 'Bruk stående spiler. Ingen åpning større enn 10 cm, og ingen liggende spiler barn kan klatre på.', [['spile', 1]], ['spiler']),
    ],
    [
      D('Trapp', 'trapp', 'Trinnhøyde og -dybde regnes ut i Byggemoduler → Trapp. Alle trinn skal være like høye.', [['vange', 2]], ['trapp']),
      D('Beis eller olje', 'beis', 'Nytt impregnert trevirke må tørke før første behandling: vent 4–8 uker.', [['pensel', 1]], []),
      D('Sluttkontroll', 'ferdig', 'Gå over alle skruer, sjekk at rekkverket står stødig og at ingen skruehoder stikker opp.', [], []),
    ],
  ];
}

/* ---------- IKEA-tegninger (strek på hvitt) ---------- */
export const K = '#1a1a1a';
export const ln = { stroke: K, strokeWidth: 2, fill: 'none', strokeLinecap: 'round', strokeLinejoin: 'round' };
export const tynn = { ...ln, strokeWidth: 1.2 };
export function Mal({ x1, y1, x2, y2, t, side = -12 }) {
  const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy) || 1, nx = -dy / L, ny = dx / L;
  const a = [x1 + nx * side, y1 + ny * side], b2 = [x2 + nx * side, y2 + ny * side];
  const ang = (Math.atan2(dy, dx) * 180) / Math.PI;
  const tx = (a[0] + b2[0]) / 2 + nx * 9 * Math.sign(side || -1), ty = (a[1] + b2[1]) / 2 + ny * 9 * Math.sign(side || -1);
  return (
    <g>
      <line x1={x1} y1={y1} x2={a[0]} y2={a[1]} {...tynn} /><line x1={x2} y1={y2} x2={b2[0]} y2={b2[1]} {...tynn} />
      <line x1={a[0]} y1={a[1]} x2={b2[0]} y2={b2[1]} {...tynn} markerStart="url(#pil)" markerEnd="url(#pil)" />
      <text x={tx} y={ty + 4} textAnchor="middle" fontSize={12} fontWeight={800} fill={K} transform={Math.abs(ang) > 60 && Math.abs(ang) < 120 ? `rotate(-90 ${tx} ${ty + 4})` : undefined}>{t}</text>
    </g>
  );
}
export const Skrue = ({ x, y, s = 1, r = 0 }) => (
  <g transform={`translate(${x} ${y}) rotate(${r}) scale(${s})`}>
    <line x1={-7} y1={0} x2={7} y2={0} {...ln} strokeWidth={3} /><line x1={0} y1={0} x2={0} y2={26} {...ln} />
    {[6, 11, 16, 21].map((v) => <line key={v} x1={-3} y1={v} x2={3} y2={v + 2} {...tynn} />)}
  </g>
);
export const Nr = ({ x, y, n }) => <g><circle cx={x} cy={y} r={11} fill="#fff" stroke={K} strokeWidth={2} /><text x={x} y={y + 4.5} textAnchor="middle" fontSize={13} fontWeight={900} fill={K}>{n}</text></g>;
export const OK = ({ x, y, ja }) => ja
  ? <g><circle cx={x} cy={y} r={12} fill="#fff" stroke={K} strokeWidth={2} /><path d={`M${x - 6} ${y} l4 5 l8 -10`} {...ln} strokeWidth={3} /></g>
  : <g><circle cx={x} cy={y} r={12} fill="#fff" stroke={K} strokeWidth={2} /><path d={`M${x - 5} ${y - 5} l10 10 M${x + 5} ${y - 5} l-10 10`} {...ln} strokeWidth={3} /></g>;
const Gress = ({ x1, x2, y }) => <g><line x1={x1} y1={y} x2={x2} y2={y} {...ln} />{Array.from({ length: Math.floor((x2 - x1) / 14) }, (_, i) => <path key={i} d={`M${x1 + 7 + i * 14} ${y} l-3 -6 M${x1 + 7 + i * 14} ${y} l3 -6`} {...tynn} />)}</g>;
export const Vater = ({ x, y, w = 110, r = 0 }) => (
  <g transform={`rotate(${r} ${x + w / 2} ${y})`}>
    <rect x={x} y={y - 8} width={w} height={16} rx={3} fill="#fff" {...ln} />
    <rect x={x + w / 2 - 14} y={y - 5} width={28} height={10} rx={5} fill="#fff" {...tynn} />
    <circle cx={x + w / 2} cy={y} r={3.5} fill={K} /><line x1={x + w / 2 - 7} y1={y - 5} x2={x + w / 2 - 7} y2={y + 5} {...tynn} /><line x1={x + w / 2 + 7} y1={y - 5} x2={x + w / 2 + 7} y2={y + 5} {...tynn} />
  </g>
);

function Tegning({ type, g }) {
  const W = 340, H = 220;
  const fit = (bw, bh, maxW = 230, maxH = 120) => Math.min(maxW / bw, maxH / bh);
  let inn = null;
  if (type === 'snor' || type === 'diagonal' || type === 'punkter' || type === 'bjelker') {
    const s = fit(g.b, g.l); const w = g.b * s, h = g.l * s, x0 = (W - w) / 2, y0 = 70;
    inn = (
      <g>
        <rect x={x0} y={y0} width={w} height={h} {...ln} stroke={type === 'bjelker' ? '#bbb' : '#d33'} strokeDasharray={type === 'bjelker' ? '5 4' : undefined} />
        {[[x0, y0], [x0 + w, y0], [x0, y0 + h], [x0 + w, y0 + h]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r={4.5} fill={K} />)}
        {type === 'snor' && <><Mal x1={x0} y1={y0} x2={x0 + w} y2={y0} t={`${cm(g.b)} cm`} /><Mal x1={x0} y1={y0 + h} x2={x0} y2={y0} t={`${cm(g.l)} cm`} /><Nr x={x0 - 22} y={y0 - 22} n={1} /></>}
        {type === 'diagonal' && <>
          <line x1={x0} y1={y0} x2={x0 + w} y2={y0 + h} {...ln} strokeDasharray="6 4" /><line x1={x0 + w} y1={y0} x2={x0} y2={y0 + h} {...ln} strokeDasharray="6 4" />
          <text x={x0 + w * 0.28} y={y0 + h * 0.28 - 6} fontSize={15} fontWeight={900} fill={K}>A</text><text x={x0 + w * 0.72} y={y0 + h * 0.28 - 6} fontSize={15} fontWeight={900} fill={K}>B</text>
          <text x={W / 2} y={y0 + h + 30} textAnchor="middle" fontSize={15} fontWeight={900} fill={K}>A = B = {cm(g.diag)} cm</text><OK x={x0 + w + 26} y={y0 + h + 24} ja />
        </>}
        {type === 'punkter' && <>
          {Array.from({ length: g.nDr }, (_, j) => Array.from({ length: g.nSt }, (_, i) => <g key={j + '-' + i}><circle cx={x0 + (i * g.stAvst) * s} cy={y0 + (j * g.drAvst) * s} r={7} fill="#fff" {...ln} /><path d={`M${x0 + i * g.stAvst * s - 4} ${y0 + j * g.drAvst * s - 4} l8 8 M${x0 + i * g.stAvst * s + 4} ${y0 + j * g.drAvst * s - 4} l-8 8`} {...tynn} /></g>))}
          <Mal x1={x0} y1={y0} x2={x0 + g.stAvst * s} y2={y0} t={`${cm(g.stAvst)}`} side={-16} />
          <Mal x1={x0} y1={y0 + g.drAvst * s} x2={x0} y2={y0} t={`${cm(g.drAvst)}`} side={-16} />
          <text x={W / 2} y={y0 + h + 30} textAnchor="middle" fontSize={14} fontWeight={900} fill={K}>{g.punkter} ×</text>
        </>}
        {type === 'bjelker' && <>
          {Array.from({ length: g.nBj }, (_, i) => <rect key={i} x={x0 + i * g.bjAvst * s - 2} y={y0} width={4} height={h} fill={K} />)}
          {Array.from({ length: g.nDr }, (_, j) => <line key={j} x1={x0} y1={y0 + j * g.drAvst * s} x2={x0 + w} y2={y0 + j * g.drAvst * s} stroke="#999" strokeWidth={5} />)}
          <Mal x1={x0} y1={y0} x2={x0 + g.bjAvst * s} y2={y0} t={`c/c ${cm(g.bjAvst)}`} side={-16} />
          <text x={W / 2} y={y0 + h + 30} textAnchor="middle" fontSize={14} fontWeight={900} fill={K}>{g.nBj} × {g.bjelkeDim?.replace('x', '×')}</text>
        </>}
      </g>
    );
  } else if (type === 'grunn') {
    inn = <g>
      <Gress x1={20} x2={90} y={150} /><Gress x1={250} x2={320} y={150} />
      <path d="M90 150 L100 170 L240 170 L250 150" {...ln} /><line x1={100} y1={166} x2={240} y2={166} stroke={K} strokeWidth={2} strokeDasharray="3 3" />
      <text x={170} y={195} textAnchor="middle" fontSize={12} fontWeight={800} fill={K}>fiberduk</text>
      <path d="M150 60 l0 60 M140 60 l20 0 M150 120 l-12 20 l24 0 z" {...ln} /><path d="M195 90 q10 -30 25 -10" {...ln} markerEnd="url(#pil)" />
      <Nr x={40} y={60} n={1} />
    </g>;
  } else if (type === 'hull') {
    inn = <g>
      <Gress x1={20} x2={130} y={80} /><Gress x1={210} x2={320} y={80} />
      <path d="M130 80 L130 190 L210 190 L210 80" {...ln} />
      <rect x={148} y={90} width={44} height={100} fill="url(#skrav)" {...ln} />
      <path d="M150 90 l0 -22 l40 0 l0 22" {...ln} strokeWidth={3} /><line x1={170} y1={90} x2={170} y2={60} {...ln} strokeWidth={3} />
      <Mal x1={230} y1={80} x2={230} y2={190} t="telefri" side={14} />
      <Nr x={40} y={40} n={2} />
    </g>;
  } else if (type === 'lodd') {
    inn = <g>
      <Gress x1={20} x2={320} y={170} /><rect x={140} y={150} width={60} height={20} fill="url(#skrav)" {...ln} />
      <path d="M150 150 l0 -40 M190 150 l0 -40 M150 110 l40 0" {...ln} strokeWidth={3} />
      <Vater x={115} y={95} />
      <g transform="translate(250 95)"><rect x={-8} y={-50} width={16} height={100} rx={3} fill="#fff" {...ln} /><circle cx={0} cy={0} r={3.5} fill={K} /></g>
      <OK x={290} y={45} ja />
    </g>;
  } else if (type === 'drager') {
    const n = Math.min(4, g.nSt); const sp = 240 / (n - 1);
    inn = <g>
      <Gress x1={20} x2={320} y={190} />
      {Array.from({ length: n }, (_, i) => <g key={i}>{!g.utenStolpe && <rect x={42 + i * sp} y={120} width={16} height={60} fill="#fff" {...ln} />}<rect x={36 + i * sp} y={180} width={28} height={10} fill="url(#skrav)" {...tynn} /></g>)}
      <rect x={30} y={g.utenStolpe ? 150 : 90} width={280} height={30} fill="#fff" {...ln} />
      <Mal x1={50} y1={112} x2={50 + sp} y2={112} t={`maks ${cm(DRAGER_SPENN)}`} side={-40} />
      <circle cx={50 + sp} cy={g.utenStolpe ? 165 : 115} r={20} {...tynn} strokeDasharray="3 3" />
      <Skrue x={220} y={20} s={0.9} /><Skrue x={240} y={20} s={0.9} /><text x={262} y={40} fontSize={14} fontWeight={900} fill={K}>2×</text>
      {!g.utenStolpe && <Mal x1={70} y1={180} x2={70} y2={120} t={`${cm(g.stolpeH)}`} side={16} />}
    </g>;
  } else if (type === 'beslag') {
    inn = <g>
      <rect x={30} y={120} width={140} height={34} fill="#fff" {...ln} /><rect x={86} y={40} width={26} height={80} fill="#fff" {...ln} />
      <path d="M112 90 l18 0 l0 30 M112 90 l0 0" {...ln} strokeWidth={3} /><path d="M68 90 l18 0 M68 90 l0 30" {...ln} strokeWidth={3} />
      {[98, 108].map((y) => <g key={y}><circle cx={122} cy={y} r={2} fill={K} /><circle cx={76} cy={y} r={2} fill={K} /></g>)}
      <text x={100} y={180} textAnchor="middle" fontSize={12} fontWeight={800} fill={K}>4,0 × 40</text>
      <line x1={190} y1={20} x2={190} y2={210} stroke="#ccc" />
      <path d="M220 150 l90 0 l0 -22 l-68 0 l0 -80 l-22 0 z" fill="#fff" {...ln} />
      <Skrue x={236} y={100} s={0.75} r={-90} /><Skrue x={236} y={120} s={0.75} r={-90} />
      <path d="M205 40 l30 0 l6 -6 l0 12 l-6 -6" {...ln} /><text x={262} y={50} fontSize={11} fontWeight={800} fill={K}>forbor</text>
      <text x={265} y={180} textAnchor="middle" fontSize={12} fontWeight={800} fill={K}>2× 5,0 × 100</text>
    </g>;
  } else if (type === 'vater') {
    inn = <g>
      {[60, 110, 160, 210, 260].map((x) => <rect key={x} x={x} y={120} width={10} height={70} fill="#fff" {...ln} />)}
      <Vater x={70} y={112} w={200} r={-6} /><OK x={300} y={60} ja />
    </g>;
  } else if (type === 'forste') {
    inn = <g>
      <rect x={20} y={30} width={40} height={170} fill="url(#skrav)" {...ln} /><text x={40} y={220} textAnchor="middle" fontSize={11} fontWeight={800} fill={K}>husvegg</text>
      <rect x={66} y={60} width={24} height={130} fill="#fff" {...ln} strokeWidth={3} />
      {[110, 150, 190, 230, 270].map((x) => <rect key={x} x={x} y={60} width={24} height={130} fill="#fff" stroke="#bbb" strokeWidth={1.5} strokeDasharray="4 4" />)}
      <g transform="translate(250 30)"><path d="M0 0 a24 24 0 0 1 48 0" {...ln} /><path d="M8 0 a16 16 0 0 1 32 0" {...tynn} /><path d="M16 0 a8 8 0 0 1 16 0" {...tynn} /><text x={24} y={22} textAnchor="middle" fontSize={11} fontWeight={800} fill={K}>opp</text></g>
      <Nr x={78} y={40} n={1} />
    </g>;
  } else if (type === 'skru') {
    inn = <g>
      <rect x={130} y={30} width={60} height={180} fill="#fff" stroke="#999" strokeWidth={2} strokeDasharray="5 4" />
      <rect x={40} y={60} width={240} height={50} fill="#fff" {...ln} /><rect x={40} y={116} width={240} height={50} fill="#fff" {...ln} />
      {[[150, 85], [170, 85], [150, 141], [170, 141]].map(([x, y], i) => <g key={i}><circle cx={x} cy={y} r={5} fill="#fff" {...ln} /><path d={`M${x - 3} ${y} l6 0 M${x} ${y - 3} l0 6`} {...tynn} /></g>)}
      <Mal x1={300} y1={110} x2={300} y2={116} t="5 mm" side={-12} />
      <Skrue x={70} y={10} s={0.8} /><Skrue x={90} y={10} s={0.8} /><text x={106} y={30} fontSize={14} fontWeight={900} fill={K}>2×</text>
      <text x={160} y={200} textAnchor="middle" fontSize={11} fontWeight={800} fill={K}>bjelke</text>
    </g>;
  } else if (type === 'skjot') {
    const panel = (ox, ja) => <g transform={`translate(${ox} 30)`}>
      <rect x={0} y={0} width={140} height={150} rx={6} fill="#fff" stroke="#bbb" />
      {[35, 70, 105].map((x) => <line key={x} x1={x} y1={10} x2={x} y2={140} stroke="#aaa" strokeWidth={6} />)}
      {[20, 50, 80, 110].map((y, k) => <g key={y}><rect x={10} y={y} width={120} height={22} fill="#fff" {...ln} /><line x1={ja ? [35, 70, 105, 35][k] : 70} y1={y} x2={ja ? [35, 70, 105, 35][k] : 70} y2={y + 22} {...ln} strokeWidth={3} /></g>)}
      <OK x={130} y={170} ja={ja} />
    </g>;
    inn = <g>{panel(20, true)}{panel(180, false)}</g>;
  } else if (type === 'kapp') {
    inn = <g>
      {[40, 70, 100, 130, 160].map((y, k) => <rect key={y} x={30} y={y} width={220 + [10, 22, 4, 16, 8][k]} height={24} fill="#fff" {...ln} />)}
      <line x1={250} y1={25} x2={250} y2={200} stroke="#d33" strokeWidth={2} strokeDasharray="7 5" />
      <path d="M290 40 l-20 30 l10 6 l20 -30 z M270 70 l-8 20" {...ln} /><Nr x={300} y={170} n={4} />
    </g>;
  } else if (type === 'stender' || type === 'list' || type === 'spiler') {
    inn = <g>
      <rect x={20} y={180} width={300} height={14} fill="#fff" {...ln} />
      {[40, 130, 220, 300].map((x) => <rect key={x} x={x} y={60} width={10} height={120} fill="#fff" {...ln} strokeWidth={type === 'stender' ? 3 : 2} />)}
      <rect x={30} y={52} width={290} height={10} fill="#fff" {...ln} strokeWidth={type === 'list' ? 3 : 2} />
      {type === 'stender' && <Mal x1={45} y1={60} x2={135} y2={60} t="maks 80" side={-18} />}
      {type === 'list' && <Mal x1={85} y1={180} x2={85} y2={62} t="min 100 cm" side={0.01} />}
      {type === 'spiler' && <>
        {Array.from({ length: 11 }, (_, i) => <rect key={i} x={140 + i * 7} y={64} width={3} height={114} fill={K} />)}
        <circle cx={85} cy={120} r={18} {...ln} strokeDasharray="4 3" /><text x={85} y={124} textAnchor="middle" fontSize={11} fontWeight={900} fill={K}>10 cm</text><OK x={85} y={160} ja={false} />
      </>}
    </g>;
  } else if (type === 'trapp') {
    inn = <g><Gress x1={20} x2={320} y={190} /><path d="M60 190 l0 -30 l50 0 l0 -30 l50 0 l0 -30 l50 0 l0 -30 l70 0" {...ln} strokeWidth={3} /><Nr x={40} y={50} n={1} /></g>;
  } else if (type === 'beis') {
    inn = <g>
      <rect x={60} y={100} width={70} height={90} rx={6} fill="#fff" {...ln} /><path d="M60 110 q35 -25 70 0" {...ln} />
      <path d="M190 60 l40 40 M200 50 l40 40 l-10 10 l-40 -40 z" {...ln} /><path d="M190 60 l-30 -30" {...ln} strokeWidth={5} />
      <text x={240} y={170} textAnchor="middle" fontSize={16} fontWeight={900} fill={K}>4–8 uker</text>
    </g>;
  } else {
    inn = <g><rect x={60} y={100} width={220} height={70} fill="#fff" {...ln} />{[80, 100, 120, 140, 160].map((y) => <line key={y} x1={60} y1={y} x2={280} y2={y} {...tynn} />)}<OK x={170} y={60} ja /></g>;
  }
  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', display: 'block', background: '#fff' }} role="img" aria-label="Monteringstegning">
      <defs>
        <marker id="pil" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 1 L9 5 L0 9 z" fill={K} /></marker>
        <pattern id="skrav" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="6" stroke="#999" strokeWidth="1.5" /></pattern>
      </defs>
      {inn}
    </svg>
  );
}

/* ---------- delene du trenger (IKEA-rute) ---------- */
const DEL_NAVN = {
  plugg: 'Plugg', snor: 'Snor', maalebaand: 'Målebånd', spade: 'Spade', duk: 'Fiberduk', merkespray: 'Merkespray',
  betongsoyle: 'Betongsøyle', betong: 'Betong', stolpesko: 'Justerbar stolpesko', vater: 'Vater', stolpe: 'Stolpe 98×98',
  drager: 'Drager 48×198', skrue6x120: 'Treskrue 6,0×120', bjelke: 'Bjelke', beslag: 'Vinkelbeslag', skrue5x100: 'Skrue 5,0×100',
  bord: 'Terrassebord 28×120', skrue5x70: 'Terrasseskrue', sag: 'Sag', stender: 'Stender', list: 'Håndlist', spile: 'Spiler',
  vange: 'Trappevange', pensel: 'Pensel',
};

/* ---------- 3D: ny del faller på plass ---------- */
export function Animasjon3D({ p, synlig, ny, Iso }) {
  const [t, setT] = useState(0);
  useEffect(() => {
    let id; const s = performance.now();
    const tikk = (n) => { setT(((n - s) / 1000) % 3.2); id = requestAnimationFrame(tikk); };
    const redusert = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if (!redusert) id = requestAnimationFrame(tikk); else setT(2);
    return () => cancelAnimationFrame(id);
  }, [ny.join()]);
  const fall = Math.max(0, 1 - t / 1.3); const e = fall * fall;
  const blink = t > 1.3 && t < 2.6;
  const bx = terrasseBokser(p).filter((q) => synlig.has(q.tag) || ny.includes(q.tag)).map((q) => ny.includes(q.tag)
    ? { ...q, dz: e * 1.2, fall: true, c: blink || e > 0 ? '#f7b83f' : q.c } : q);
  return <Iso p={p} bokser={bx} vinkel={30} hoyde={240} interaktiv />;
}

/* ---------- hovedkomponent i steg-skjermen ---------- */
export function TerrasseManual({ p, stegIdx, delIdx, settDel, kryss, vend, Iso, C }) {
  const alle = terrasseDeler(p); const deler = alle[stegIdx]; const d = deler[Math.min(delIdx, deler.length - 1)];
  const g = terrasseGeo(p.mal);
  const video = TERRASSE_VIDEO[stegIdx];
  const [vis, setVis] = useState('tegning');
  useEffect(() => { if (vis === 'video' && !video) setVis('tegning'); }, [video, vis]);
  // hvilke deler finnes allerede i 3D før denne delen
  const synlig = new Set();
  alle.forEach((ds, si) => ds.forEach((x, di) => { if (si < stegIdx || (si === stegIdx && di < delIdx)) x.ny.forEach((tg) => synlig.add(tg)); }));
  if (synlig.has('bord1') || synlig.has('bord')) { synlig.delete('snor'); synlig.delete('punkt'); }
  let ny = d.ny;
  if (!ny.length && synlig.size === 0) ny = ['snor'];
  const faner = [['tegning', 'Tegning'], ['3d', '3D'], ...(video ? [['video', 'Video']] : [])];
  const fn = { border: 0, borderRadius: 9, padding: '8px 0', fontWeight: 800, fontSize: 13, flex: 1 };
  return (
    <div>
      {stegIdx === 0 && delIdx === 0 && g.varsler.map((v, i) => <div key={i} style={{ background: '#5a2a1f', border: '1px solid #e25b4b', borderRadius: 10, padding: 10, fontSize: 13, marginBottom: 8 }}>⚠️ {v}</div>)}
      <div style={{ display: 'flex', gap: 6, marginBottom: 8, background: '#ffffff10', padding: 4, borderRadius: 12 }}>
        {faner.map(([k, t]) => <button key={k} onClick={() => setVis(k)} style={{ ...fn, background: vis === k ? C.gold : 'transparent', color: vis === k ? C.ink : 'white' }}>{t}</button>)}
      </div>
      <div style={{ borderRadius: 12, overflow: 'hidden', background: '#fff', position: 'relative' }}>
        {vis === 'tegning' && <Tegning type={d.tegning} g={g} />}
        {vis === '3d' && <div style={{ background: '#FBFBF9' }}><Animasjon3D p={p} synlig={synlig} ny={ny} Iso={Iso} /></div>}
        {vis === 'video' && <video src={video} controls playsInline style={{ width: '100%', display: 'block', background: '#000' }} />}
        <div style={{ position: 'absolute', left: 8, top: 8, background: C.ink, color: 'white', borderRadius: 8, padding: '3px 8px', fontWeight: 900, fontSize: 13 }}>{stegIdx + 1}.{delIdx + 1}</div>
      </div>
      {d.deler.filter(([, n]) => n > 0).length > 0 && (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 8 }}>
          {d.deler.filter(([, n]) => n > 0).map(([k, n]) => <span key={k} style={{ background: '#fff', color: C.ink, borderRadius: 8, padding: '4px 8px', fontSize: 12, fontWeight: 800 }}>{n > 1 ? `${n} × ` : ''}{k === 'bjelke' && g.bjelkeDim ? `Bjelke ${g.bjelkeDim.replace('x', '×')}` : DEL_NAVN[k]}</span>)}
        </div>
      )}
      <div style={{ marginTop: 10, fontWeight: 800, fontSize: 17 }}>{d.tittel}</div>
      <p style={{ margin: '6px 0 0', fontSize: 15, lineHeight: 1.5, color: '#dfe8ef' }}>{d.tekst}</p>
      <div style={{ display: 'flex', gap: 6, marginTop: 12 }}>
        {deler.map((x, k) => (
          <button key={k} aria-label={`Del ${k + 1}: ${x.tittel}`} onClick={() => settDel(k)} style={{ flex: 1, height: 8, border: 0, borderRadius: 4, padding: 0, background: kryss[k] ? C.ok : k === delIdx ? C.gold : '#ffffff30' }} />
        ))}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 8, marginTop: 10 }}>
        <button disabled={delIdx === 0} onClick={() => settDel(delIdx - 1)} style={{ border: '1px solid #ffffff30', background: '#ffffff14', color: 'white', borderRadius: 12, padding: 12, fontWeight: 800, opacity: delIdx === 0 ? 0.4 : 1 }}>Forrige</button>
        <button onClick={() => { if (!kryss[delIdx]) vend(delIdx); if (delIdx + 1 < deler.length) settDel(delIdx + 1); }} style={{ border: 0, background: kryss[delIdx] ? C.ok : 'white', color: C.ink, borderRadius: 12, padding: 12, fontWeight: 900 }}>
          {kryss[delIdx] ? '✓ Gjort' : 'Gjort'}{delIdx + 1 < deler.length ? ' – neste del' : ''}
        </button>
      </div>
    </div>
  );
}
