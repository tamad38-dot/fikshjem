import React from 'react';
import { visBeskjed } from '../lib/beskjed.js';

/* ================================================================
   LEVERANSE TIL KOMMUNEN
   ----------------------------------------------------------------
   Samler 3D-rommet, plantegningen, fasade før/etter, takskjema og
   fagjobber i én utskriftsklar leveranse med adresse, gnr/bnr og
   kommune. Kan skrives ut eller lagres som PDF og leveres byggesak.
   ================================================================ */

export const TOM_LEVERANSE = {
  adresse: '', postnr: '', sted: '', kommune: '', gnr: '', bnr: '', snr: '',
  tiltakshaver: '', epost: '', telefon: '', beskrivelse: '',
};

const T = {
  rot: { display: 'grid', gap: 12, background: '#FBFBF9', color: '#1C2321', borderRadius: 12, padding: 12 }, // lyst papir: tekstene her er laget for lys bakgrunn (før var de mørke på mørkt kort)
  tittel: { fontSize: 14, fontWeight: 700, color: '#1C2321' },
  tekst: { fontSize: 13, lineHeight: 1.5, color: '#3A443E' },
  smaa: { fontSize: 11, color: '#8A938C', lineHeight: 1.4 },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: 8 },
  felt: { display: 'grid', gap: 4, fontSize: 11, color: '#5C665E' },
  inn: { padding: '8px 9px', borderRadius: 8, border: '1px solid #C8D0C8', fontSize: 13, background: '#fff', width: '100%' },
  boks: { border: '1px solid #E3E7E2', borderRadius: 10, padding: 10, display: 'grid', gap: 8, background: '#fff' },
  knapp: { padding: '10px 12px', borderRadius: 10, border: 'none', background: '#2F5F55', color: '#fff', fontSize: 13, fontWeight: 700, cursor: 'pointer' },
  adv: { background: '#FDF3E3', border: '1px solid #E3B341', borderRadius: 10, padding: 10, fontSize: 12, color: '#6A4E10', lineHeight: 1.5 },
  rad: { display: 'flex', justifyContent: 'space-between', gap: 10, fontSize: 12, borderBottom: '1px solid #EDF0EC', padding: '5px 0' },
  a4: { border: '1px solid #DDE2DC', borderRadius: 10, background: '#fff', padding: 14, display: 'grid', gap: 8 },
};

const kr = (n) => Math.round(Number(n) || 0).toLocaleString('no-NO');

function Felt({ label, value, onChange, placeholder }) {
  return (
    <label style={T.felt}>
      {label}
      <input style={T.inn} value={value || ''} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} />
    </label>
  );
}

/** Bygger vedleggslista ut fra hva prosjektet faktisk inneholder. */
export function leveranseVedlegg(prosjekt) {
  const p = prosjekt || {};
  const vedlegg = [];
  vedlegg.push({ navn: 'Plantegning med mål', med: (p.rom || []).length > 0, detalj: (p.rom || []).length + ' rom · ' + (p.areal || 0) + ' m²' });
  vedlegg.push({ navn: '3D-visning av rommene', med: (p.rom || []).length > 0, detalj: 'Takhøyde ' + (p.takhoyde || 0) + ' m' });
  vedlegg.push({ navn: 'Teknisk fasadetegning før og etter', med: !!(p.fasade && (p.fasade.elementer || []).length), detalj: ((p.fasade && p.fasade.elementer) || []).length + ' elementer' });
  vedlegg.push({ navn: 'Takskjema med mål og vinkel', med: !!p.tak, detalj: p.tak ? (p.tak.type === 'pulttak' ? 'Pulttak' : 'Saltak') + ' ' + (p.tak.takvinkel || 0) + '°' : 'Ikke lagt inn' });
  vedlegg.push({ navn: 'Byggtegning lastet opp', med: !!(p.underlag && p.underlag.url), detalj: (p.underlag && p.underlag.navn) || 'Ingen tegning' });
  vedlegg.push({ navn: 'Fagjobber og kostnadsoverslag', med: (p.jobber || 0) > 0, detalj: (p.jobber || 0) + ' jobber · ' + kr(p.prisFra) + '–' + kr(p.prisTil) + ' kr' });
  return vedlegg;
}

export function skrivUtLeveranse(verdier, prosjekt, varsle) {
  const vindu = window.open('', '_blank');
  if (!vindu) { if (varsle) varsle('Nettleseren blokkerte utskriftsvinduet. Tillat popup og prøv igjen.'); return; }
  const v = verdier || {};
  const vedlegg = leveranseVedlegg(prosjekt);
  const rader = vedlegg.map((x) => '<tr><td>' + (x.med ? '✔' : '–') + '</td><td>' + x.navn + '</td><td>' + x.detalj + '</td></tr>').join('');
  vindu.document.write(
    '<!doctype html><html lang="no"><head><meta charset="utf-8"><title>Byggesak – ' + (v.adresse || 'leveranse') + '</title>'
    + '<style>@page{size:A4;margin:18mm}body{font-family:Helvetica,Arial,sans-serif;color:#111;font-size:12px}'
    + 'h1{font-size:18px;margin:0 0 4px}h2{font-size:13px;margin:16px 0 6px;border-bottom:1px solid #111;padding-bottom:3px}'
    + 'table{width:100%;border-collapse:collapse}td,th{border-bottom:1px solid #ccc;padding:5px 4px;text-align:left;vertical-align:top}'
    + '.rute{border:1px solid #111;padding:8px;margin-top:8px}</style></head><body>'
    + '<h1>Søknad om tiltak – vedleggsoversikt</h1>'
    + '<div>' + (v.adresse || '') + ', ' + (v.postnr || '') + ' ' + (v.sted || '') + ' · ' + (v.kommune || '') + ' kommune</div>'
    + '<div>Gnr ' + (v.gnr || '–') + ' / Bnr ' + (v.bnr || '–') + (v.snr ? ' / Snr ' + v.snr : '') + '</div>'
    + '<h2>Tiltakshaver</h2><div>' + (v.tiltakshaver || '') + ' · ' + (v.epost || '') + ' · ' + (v.telefon || '') + '</div>'
    + '<h2>Beskrivelse av tiltaket</h2><div>' + (v.beskrivelse || '') + '</div>'
    + '<h2>Vedlegg</h2><table><tr><th>Med</th><th>Vedlegg</th><th>Innhold</th></tr>' + rader + '</table>'
    + '<div class="rute">Samlet kostnadsoverslag: ' + kr(prosjekt && prosjekt.prisFra) + '–' + kr(prosjekt && prosjekt.prisTil) + ' kr. '
    + 'Alle mål er tatt fra oppmåling/byggtegning og må kontrolleres på stedet.</div>'
    + '</body></html>'
  );
  vindu.document.close();
  vindu.focus();
  setTimeout(() => vindu.print(), 350);
}

export default function KommuneLevering({ verdier, onEndre, prosjekt, onSkrivUt }) {
  const v = verdier || TOM_LEVERANSE;
  const vedlegg = leveranseVedlegg(prosjekt);
  const mangler = [];
  if (!v.adresse) mangler.push('adresse');
  if (!v.gnr || !v.bnr) mangler.push('gårds- og bruksnummer');
  if (!v.kommune) mangler.push('kommune');

  return (
    <div style={T.rot} data-tf="kommunelevering">
      <div style={T.tekst}>
        Send hele prosjektet til kommunen: 3D-rommet, plantegningen, fasade før og etter, takskjema og
        fagjobbene med totalsum — samlet i én utskriftsklar leveranse.
      </div>

      <div style={T.boks}>
        <div style={T.tittel}>Eiendom og tiltakshaver</div>
        <div style={T.grid}>
          <Felt label="Adresse" value={v.adresse} placeholder="Storgata 12" onChange={(x) => onEndre('adresse', x)} />
          <Felt label="Postnummer" value={v.postnr} placeholder="3040" onChange={(x) => onEndre('postnr', x)} />
          <Felt label="Sted" value={v.sted} placeholder="Drammen" onChange={(x) => onEndre('sted', x)} />
          <Felt label="Kommune" value={v.kommune} placeholder="Drammen" onChange={(x) => onEndre('kommune', x)} />
          <Felt label="Gårdsnummer (gnr)" value={v.gnr} placeholder="110" onChange={(x) => onEndre('gnr', x)} />
          <Felt label="Bruksnummer (bnr)" value={v.bnr} placeholder="345" onChange={(x) => onEndre('bnr', x)} />
          <Felt label="Seksjonsnummer (valgfritt)" value={v.snr} onChange={(x) => onEndre('snr', x)} />
          <Felt label="Tiltakshaver" value={v.tiltakshaver} placeholder="Ditt navn" onChange={(x) => onEndre('tiltakshaver', x)} />
          <Felt label="E-post" value={v.epost} onChange={(x) => onEndre('epost', x)} />
          <Felt label="Telefon" value={v.telefon} onChange={(x) => onEndre('telefon', x)} />
        </div>
        <label style={T.felt}>
          Kort beskrivelse av tiltaket
          <textarea style={{ ...T.inn, minHeight: 70 }} value={v.beskrivelse || ''}
            placeholder="For eksempel: Bytte av to vinduer i sørfasaden og nytt takvindu."
            onChange={(e) => onEndre('beskrivelse', e.target.value)} />
        </label>
      </div>

      <div style={T.boks}>
        <div style={T.tittel}>Vedlegg i leveransen</div>
        {vedlegg.map((x) => (
          <div key={x.navn} style={T.rad}>
            <span style={{ color: x.med ? '#1C2321' : '#8A938C' }}>{x.med ? '✔' : '–'} {x.navn}</span>
            <span style={T.smaa}>{x.detalj}</span>
          </div>
        ))}
      </div>

      <div style={T.a4} data-tf="leveranse-forhandsvisning" aria-label="Forhåndsvisning i A4">
        <div style={{ fontSize: 16, fontWeight: 800 }}>Søknad om tiltak – vedleggsoversikt</div>
        <div style={T.tekst}>{v.adresse || 'Adresse mangler'}, {v.postnr} {v.sted} · {v.kommune || 'kommune mangler'} kommune</div>
        <div style={T.tekst}>Gnr {v.gnr || '–'} / Bnr {v.bnr || '–'}{v.snr ? ' / Snr ' + v.snr : ''}</div>
        <div style={T.smaa}>{v.tiltakshaver} {v.epost ? '· ' + v.epost : ''} {v.telefon ? '· ' + v.telefon : ''}</div>
        <div style={T.tekst}>{v.beskrivelse || 'Ingen beskrivelse lagt inn ennå.'}</div>
        <div style={{ ...T.tekst, fontWeight: 700 }}>
          Kostnadsoverslag: {kr(prosjekt && prosjekt.prisFra)}–{kr(prosjekt && prosjekt.prisTil)} kr
        </div>
      </div>

      {mangler.length ? (
        <div style={T.adv}>Fyll inn {mangler.join(', ')} før du sender leveransen til kommunen.</div>
      ) : null}

      <button type="button" style={T.knapp} data-tf="skriv-ut-leveranse"
        onClick={() => (onSkrivUt ? onSkrivUt() : skrivUtLeveranse(v, prosjekt, (m) => visBeskjed(m)))}>
        Skriv ut / lagre som PDF
      </button>
    </div>
  );
}
