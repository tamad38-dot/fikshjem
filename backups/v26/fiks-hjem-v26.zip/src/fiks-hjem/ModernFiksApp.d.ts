declare const ModernFiksApp: React.ComponentType;
export default ModernFiksApp;
