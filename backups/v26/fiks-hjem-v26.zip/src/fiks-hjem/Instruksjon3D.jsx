import React, { useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, ChevronDown, Check, Wrench } from 'lucide-react';

const TEKNISK = {
  tak: ['Underlag', 'Sperrer', 'Tettsjikt', 'Lekter', 'Tekking'],
  vatrom: ['Underlag', 'Fall', 'Membran', 'Overflate', 'Kontroll'],
  ramme: ['Oppmerking', 'Bunn / topp', 'Stendere', 'Kledning', 'Kontroll'],
  flate: ['Forbered', 'Mål opp', 'Startfelt', 'Fortsett', 'Kontroll'],
  installasjon: ['Mål', 'Åpning', 'Montering', 'Tetting', 'Kontroll'],
  fag: ['Planlegg', 'Føringsvei', 'Montering', 'Prøving', 'Dokumentasjon'],
};

function finnType(art, title = '', category = '') {
  const tekst = `${art || ''} ${title} ${category}`.toLowerCase();
  if (/tak|sloyf|lekt|overlapp|snø|møne/.test(tekst)) return 'tak';
  if (/bad|våt|membran|fall|sluk|flis/.test(tekst)) return 'vatrom';
  if (/elektro|rør|ventil|varme|ildsted/.test(tekst)) return 'fag';
  if (/vindu|dør|karm|trapp|servant|toalett|kjøkken/.test(tekst)) return 'installasjon';
  if (/vegg|stender|isolasjon|terrasse|gjerde|fundament|garasje/.test(tekst)) return 'ramme';
  return 'flate';
}

function kategoriType(category = '', title = '', art = '') {
  const t = `${category} ${title} ${art}`.toLowerCase();
  if (/tak|takstein|møne/.test(t)) return 'tak';
  if (/terrasse|beis/.test(t)) return 'terrasse';
  if (/gulv|laminat|parkett/.test(t)) return 'gulv';
  if (/vindu/.test(t)) return 'vindu';
  if (/dør/.test(t)) return 'dor';
  if (/bad|våtrom|flis/.test(t)) return 'bad';
  if (/vegg|isolasjon/.test(t)) return 'vegg';
  if (/maling/.test(t)) return 'maling';
  if (/garasje|bod/.test(t)) return 'garasje';
  if (/trapp|rekkverk/.test(t)) return 'trapp';
  if (/levegg|gjerde/.test(t)) return 'gjerde';
  if (/toalett|servant|kran|rør|vann/.test(t)) return 'ror';
  if (/elektr|elbil|varmepumpe|ventil/.test(t)) return 'teknisk';
  if (/peis|ovn|ildsted/.test(t)) return 'ildsted';
  return 'flate';
}

function Scene({ kind, active }) {
  const ink='#26332f', pale='#e8ebe7', gold='#e2b44d', faint='#f4f4ef';
  const hi = active ? gold : pale;
  const common = { stroke:ink, strokeWidth:2, fill:'none', strokeLinejoin:'round', strokeLinecap:'round' };
  if (kind === 'tak') return <g {...common}><path d="M70 145L180 62l110 83"/><path d="M92 145l88-66 88 66" fill={pale}/><path d="M103 137l77-58 77 58" stroke={gold} strokeWidth="7"/><path d="M180 62v17"/><path d="M80 154h200"/></g>;
  if (kind === 'terrasse') return <g {...common}><path d="M65 140l62-38h168l-61 38z" fill={hi}/><path d="M65 140v22h169v-22M234 140l61-38v22l-61 38"/><path d="M92 123l168 0M115 109l168 0" strokeWidth="1"/><path d="M90 162v18M210 162v18"/></g>;
  if (kind === 'gulv') return <g {...common}><path d="M55 80h250v92H55z" fill={faint}/><path d="M55 126h250M105 80v92M155 80v92M205 80v92M255 80v92"/><path d="M55 149h250" stroke={gold} strokeWidth="14"/></g>;
  if (kind === 'vindu') return <g {...common}><rect x="92" y="45" width="176" height="130" fill={faint}/><rect x="110" y="61" width="140" height="98" fill={hi}/><path d="M180 61v98M110 110h140"/><path d="M82 45v130M75 45h14M75 175h14"/></g>;
  if (kind === 'dor') return <g {...common}><path d="M105 175V48h145v127"/><rect x="122" y="62" width="110" height="113" fill={hi}/><circle cx="212" cy="119" r="4" fill={ink}/><path d="M88 175h180"/></g>;
  if (kind === 'bad') return <g {...common}><path d="M65 55v120h230V55"/><path d="M65 125h230M120 55v120M175 55v120M230 55v120" strokeWidth="1"/><path d="M65 150h230" stroke={gold} strokeWidth="10"/><circle cx="180" cy="150" r="10" fill={faint}/><path d="M174 150h12M180 144v12"/></g>;
  if (kind === 'vegg') return <g {...common}><path d="M70 170V55h220v115"/><path d="M105 55v115M145 55v115M185 55v115M225 55v115M265 55v115"/><rect x="143" y="55" width="44" height="115" fill={hi} opacity=".8"/></g>;
  if (kind === 'maling') return <g {...common}><rect x="65" y="55" width="230" height="115" fill={faint}/><path d="M105 72h90v44h-90z" fill={hi}/><path d="M195 94h28v52M223 146h22"/><rect x="238" y="138" width="28" height="22" rx="2" fill={pale}/></g>;
  if (kind === 'garasje') return <g {...common}><path d="M65 95l115-55 115 55v82H65z" fill={faint}/><rect x="105" y="108" width="150" height="69" fill={hi}/><path d="M105 130h150M105 152h150"/></g>;
  if (kind === 'trapp') return <g {...common}><path d="M75 165h48v-27h48v-27h48V84h48V57h35" fill={hi}/><path d="M75 165h48v-27h48v-27h48V84h48V57h35"/><path d="M95 140L265 40"/></g>;
  if (kind === 'gjerde') return <g {...common}><path d="M65 165h230M85 55v110M145 55v110M205 55v110M265 55v110"/><path d="M70 83h220M70 132h220" stroke={gold} strokeWidth="9"/></g>;
  if (kind === 'ror') return <g {...common}><path d="M75 65h95v55h50v55h70" stroke={gold} strokeWidth="12"/><path d="M75 65h95v55h50v55h70"/><circle cx="170" cy="120" r="9" fill={faint}/><circle cx="220" cy="175" r="9" fill={faint}/></g>;
  if (kind === 'teknisk') return <g {...common}><rect x="85" y="58" width="190" height="112" rx="8" fill={faint}/><path d="M180 75l-30 47h28l-12 35 45-57h-29l18-25" fill={hi}/><path d="M105 185h150"/></g>;
  if (kind === 'ildsted') return <g {...common}><path d="M125 170V75h110v95" fill={faint}/><path d="M155 75V42h50v33"/><path d="M150 145c0-28 30-30 30-58 24 23 35 38 23 58-10 17-42 18-53 0z" fill={hi}/></g>;
  return <g {...common}><rect x="65" y="65" width="230" height="105" fill={hi}/><path d="M85 90h190M85 115h190M85 140h190"/></g>;
}

function ManualTegning({ type, index, total, title, category, art }) {
  const kind = kategoriType(category, title, art);
  return <svg viewBox="0 0 360 225" role="img" aria-label={`Arbeidstegning: ${title}`} className="tf-fiks-svg">
    <rect width="360" height="225" fill="#fbfbf7" />
    <Scene kind={kind} active={true}/>
    <circle cx="42" cy="38" r="18" fill="#e2b44d" stroke="#26332f" strokeWidth="1.5"/>
    <text x="42" y="44" textAnchor="middle" fontSize="16" fontWeight="800" fill="#26332f">{index + 1}</text>
    <text x="70" y="35" fontSize="11" fontWeight="800" fill="#26332f">{String(category || kind).toUpperCase()}</text>
    <text x="70" y="50" fontSize="9" fill="#52605b">{title}</text>
    <path d="M58 196H302M58 191v10M302 191v10" stroke="#52605b" strokeWidth="1.2"/>
    <text x="180" y="214" textAnchor="middle" fontSize="9" fill="#52605b">Steg {index + 1} av {total} · kontroller mål før neste steg</text>
  </svg>;
}

export function komplettGuideSteg(steg) {
  const base = Array.isArray(steg) ? steg : [];
  if (!base.length) return [];
  const siste = base[base.length - 1];
  if (/ferdig|sluttkontroll|dokumentasjon/i.test(`${siste.title || ''} ${siste.kort || ''}`)) return base;
  return [...base, { n: Math.max(...base.map(s => Number(s.n) || 0)) + 1, kort: 'Kontroller jobben', title: 'Ferdig resultat', sub: 'Sjekk før du avslutter', art: siste.art, bilde: siste.bilde, details: ['Kontroller mål, lodd, vater, skjøter og festepunkter.', 'Ta bilder av ferdig arbeid og skjulte lag før de dekkes.'] }];
}

export default function Instruksjon3D({ steps, activeNumber, onStepChange, category, renderExtra, renderTegning }) {
  const [openInfo, setOpenInfo] = useState(false);
  const index = Math.max(0, steps.findIndex(s => s.n === activeNumber));
  const step = steps[index] || steps[0];
  const type = useMemo(() => finnType(step?.art, step?.title, category), [step, category]);
  if (!step) return null;
  const go = n => { setOpenInfo(false); onStepChange(steps[Math.max(0, Math.min(steps.length - 1, n))].n); };
  const details = step.details || [];

  return <section className="tf-fiks-manual" data-tf="fiks-steg-for-steg">
    <header className="tf-fiks-head">
      <div className="tf-fiks-stepno">{index + 1}</div>
      <div><small>STEG {index + 1} AV {steps.length}</small><h3>{step.kort || step.title}</h3><p>{step.sub || step.title}</p></div>
    </header>

    <div className="tf-fiks-progress" aria-label={`Steg ${index + 1} av ${steps.length}`}>
      {steps.map((s,i) => <span key={s.n} className={i <= index ? 'is-on' : ''}/>) }
    </div>

    {step.bilde ? <div className="tf-fiks-photo"><img src={step.bilde} alt={step.title} loading="lazy" /></div> : renderTegning ? renderTegning(step, index) : <ManualTegning type={type} index={index} total={steps.length} title={step.title} category={category} art={step.art}/>} 

    <div className="tf-fiks-do">
      <strong>Gjør dette nå</strong>
      <p>{details[0] || 'Følg tegningen og kontroller arbeidet før neste steg.'}</p>
    </div>

    <div className="tf-fiks-tools"><Wrench size={18}/><span><strong>Du trenger</strong><small>{type === 'fag' ? 'Dette steget skal utføres av fagperson.' : 'Se verktøy- og materiallisten for prosjektet.'}</small></span></div>

    {(details.length > 1 || step.warn) && <div className="tf-fiks-more">
      <button type="button" onClick={() => setOpenInfo(v => !v)} aria-expanded={openInfo}><span>Viktig å vite</span><ChevronDown size={18} className={openInfo ? 'is-open' : ''}/></button>
      {openInfo && <div className="tf-fiks-morebody">{details.slice(1).map((d,i)=><p key={i}><Check size={14}/><span>{d}</span></p>)}{step.warn && <p className="tf-fiks-warning"><span>!</span><span>{step.warn}</span></p>}</div>}
    </div>}

    {renderExtra ? <div className="tf-fiks-extra">{renderExtra(step)}</div> : null}

    <nav className="tf-fiks-nav">
      <button type="button" onClick={() => go(index - 1)} disabled={index === 0}><ChevronLeft size={20}/><span>Forrige</span></button>
      <button type="button" className="tf-fiks-next" onClick={() => go(index + 1)} disabled={index === steps.length - 1}><span>{index === steps.length - 1 ? 'Ferdig' : 'Neste steg'}</span><ChevronRight size={20}/></button>
    </nav>
  </section>;
}
