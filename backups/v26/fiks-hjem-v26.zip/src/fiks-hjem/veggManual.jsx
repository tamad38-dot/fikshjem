import React, { useEffect, useState } from 'react';
import { K, ln, tynn, Mal, Skrue, Nr, OK, Vater } from './terrasseManual.jsx';

/* =====================================================================
   VEGG – IKEA-manual (lettvegg/innervegg av tre, ikke-bærende, gips på begge sider)
   Samme oppbygging som terrassen: tekst med dine mål + strektegning + 3D.

   Tallene kommer fra:
   - c/c 600 mellom stenderne, plateskjøter midt på en stender:
     Gyproc monteringshåndbok (senteravstand 600 alt. 450 mm).
   - Skruer langs platekant pr. 200 mm, mot mellomliggende stender pr. 300 mm,
     min. 10 mm fra kartongkledd kant, 15 mm fra skåret kant: Gyproc monteringshåndbok.
   - Gipsskrue min. 3,9 × 29 mm i tre: Norsk Byggtjeneste (produktdokumentasjon gipsplater).
   - Svill 48 × 98, bunnsvill + dobbel toppsvill: samme som Byggemoduler → Vegg
     (STENDER-tabellen i TamerFixApp.jsx, «Byggforskserien – vanlig praksis»).
   - Gipsplate 1200 mm bred, 12,5 mm.
   Ingen tall for festeavstand av svill i tre eller for lydisolasjonens tykkelse:
   de er ikke verifisert, og da står det ikke noe tall.
   ===================================================================== */

export const VEGG_VIDEO = ['', '', '', '', '', ''];

const T = 0.048, B = 0.098, CC = 0.6, PL_B = 1.2, PL_T = 0.0125;
const cm = (m) => Math.round(m * 100);
const mm = (m) => Math.round(m * 1000);

export function veggGeo({ b, h }) {
  const L = Math.max(0.3, b), H = Math.max(1, h);
  const midt = [];
  for (let i = 1; i * CC < L - 0.1; i++) midt.push(+(i * CC).toFixed(3));
  const stendere = [T / 2, ...midt, L - T / 2]; // senterlinjer, målt fra venstre ende
  const stenderL = H - 3 * T;
  const nPlaterSide = Math.ceil(L / PL_B - 1e-6);
  const sisteB = L - (nPlaterSide - 1) * PL_B;
  const kant = Math.ceil(H / 0.2) + 1, mid = Math.ceil(H / 0.3) + 1;
  const skruerPrPlate = 2 * kant + mid;
  const varsler = [];
  if (H > 2.4) varsler.push(`Takhøyden er ${cm(H)} cm. Kjøp gipsplater som er lange nok til å gå fra gulv til tak – da slipper du skjøter på tvers.`);
  return {
    L, H, stendere, nSt: stendere.length, stenderL, nPlaterSide, nPlater: nPlaterSide * 2, sisteB,
    svillLm: L * 3, nSkruer: skruerPrPlate * nPlaterSide * 2, midt, varsler,
  };
}

/* ---------- 3D-bokser (x langs veggen, y tykkelse, z høyde) ---------- */
export function veggBokser(p) {
  const g = veggGeo(p.mal); const bx = []; const y0 = ((p.mal.l || 1.2) - B) / 2;
  const add = (tag, o) => bx.push({ tag, ...o });
  add('linje', { x: 0, y: y0 - 0.006, z: 0, w: g.L, d: 0.006, h: 0.004, c: '#ff5a36' });
  add('linje', { x: 0, y: y0 + B, z: 0, w: g.L, d: 0.006, h: 0.004, c: '#ff5a36' });
  add('bunn', { x: 0, y: y0, z: 0, w: g.L, d: B, h: T, c: '#8A6A3A' });
  add('topp', { x: 0, y: y0, z: g.H - 2 * T, w: g.L, d: B, h: 2 * T, c: '#8A6A3A' });
  g.stendere.forEach((c) => add('stender', { x: c - T / 2, y: y0, z: T, w: T, d: B, h: g.stenderL, c: '#1D5F8A' }));
  for (let i = 0; i < g.stendere.length - 1; i++) {
    const a = g.stendere[i] + T / 2, e = g.stendere[i + 1] - T / 2;
    if (e - a > 0.05) add('isolasjon', { x: a + 0.005, y: y0 + 0.01, z: T + 0.01, w: e - a - 0.01, d: B - 0.02, h: g.stenderL - 0.02, c: '#f2d36b' });
  }
  for (let k = 0; k < g.nPlaterSide; k++) {
    const x = k * PL_B, w = Math.min(PL_B, g.L - x) - 0.004;
    add(k === 0 ? 'plate1' : 'plateA', { x: x + 0.002, y: y0 - PL_T, z: 0.01, w, d: PL_T, h: g.H - 0.02, c: '#f3f1ea' });
    add('plateB', { x: x + 0.002, y: y0 + B, z: 0.01, w, d: PL_T, h: g.H - 0.02, c: '#f3f1ea', foran: true });
  }
  return bx;
}

/* ---------- delene i hvert steg ---------- */
export function veggDeler(p) {
  const g = veggGeo(p.mal);
  const D = (tittel, tegning, tekst, deler, ny, rod) => ({ tittel, tegning, tekst, deler, ny, rod });
  const merker = g.midt.slice(0, 4).map(cm).join(', ') + (g.midt.length > 4 ? ' …' : '');
  return [
    [
      D('Merk veggen på gulvet', 'gulvlinje', `Veggen blir ${cm(g.L)} cm lang. Merk to parallelle streker på gulvet, ${mm(B)} mm fra hverandre – det er der svillen skal ligge. Sjekk at streken står i rett vinkel på veggen du starter fra.`, [['maalebaand', 1], ['blyant', 1], ['vinkel', 1]], ['linje']),
      D('Overfør streken til taket', 'lodd', 'Hold et lodd (eller en krysslaser) fra taket ned til streken på gulvet, i begge ender av veggen. Merk i taket. Da står veggen loddrett.', [['lodd', 1]], []),
    ],
    [
      D('Kapp svillene', 'sviller', `Kapp 3 sviller (48 × ${mm(B)}) à ${cm(g.L)} cm: én til gulvet og to til taket.`, [['svill', 3], ['sag', 1]], []),
      D('Merk stenderne c/c 60', 'merk', `Legg bunnsvillen og én toppsvill side om side. Mål fra SAMME ende på begge og merk midten av hver stender: ${merker} cm. I tillegg én stender helt ytterst i hver ende. Da havner hver plateskjøt midt på en stender.`, [['blyant', 1], ['vinkel', 1]], []),
      D('Fest svillene', 'feste', 'Skru bunnsvillen fast i gulvet langs strekene. Skru de to toppsvillene fast i taket langs merkene – rett over bunnsvillen. Sjekk først hva som ligger i gulv og tak (rør, varmekabler, strøm).', [['svill', 3]], ['bunn', 'topp']),
    ],
    [
      D('Kapp stenderne', 'kapp', `Kapp ${g.nSt} stendere (48 × ${mm(B)}) à ${cm(g.stenderL)} cm. Mål gjerne hver plass for seg – gulv og tak er sjelden helt rette.`, [['stender', g.nSt], ['sag', 1]], []),
      D('Sett inn stenderne', 'stendere', `Sett stenderne inn mellom svillene på merkene – ${g.nSt} stk. Skru dem skrått inn i svillen, fra begge sider, i toppen og i bunnen.`, [['stender', g.nSt]], ['stender']),
      D('Sjekk lodd og avstand', 'kontroll', 'Hold vateret loddrett mot hver stender. Mål c/c 60 cm mellom senterne. Én skjev stender gir en skjev plate.', [['vater', 1], ['maalebaand', 1]], []),
    ],
    [
      D('Første plate', 'plate1', 'Start i den enden du målte fra. Sett platen stående, med kanten midt på en stender. Løft den litt fra gulvet med en kloss mens du skrur – platen skal være litt kortere enn takhøyden.', [['gips', 1], ['kloss', 1]], ['plate1']),
      D('Skru platen fast', 'skrue', 'Langs platekantene: én skrue hver 20. cm. Inne på platen (midtstenderen): hver 30. cm. Minst 10 mm fra kanten (15 mm fra en kant du har kappet). Skruehodet skal så vidt senkes – ikke gjennom papiret.', [['gipsskrue', 1]], []),
      D('Resten av platene', 'plater', `Du trenger ${g.nPlaterSide} plater på denne siden. Den siste blir ${cm(g.sisteB)} cm bred – kapp den til.`, [['gips', g.nPlaterSide]], ['plateA']),
    ],
    [
      D('Strøm og rør i veggen', 'el', 'Nye stikkontakter eller brytere i veggen skal legges av en registrert elektriker. Det er ikke lov å gjøre det selv. Rør: bruk rørlegger. Dette gjøres nå – før veggen lukkes.', [], [], true),
      D('Isolasjon (for lyd)', 'isolasjon', 'Vil du dempe lyd gjennom veggen, fyll hulrommene mellom stenderne med mineralull. Hele hulrommet skal fylles, uten glipper.', [['isolasjon', 1]], ['isolasjon']),
    ],
    [
      D('Andre siden', 'andreSide', `Kle den andre siden på samme måte: ${g.nPlaterSide} plater, kant midt på stender, samme skrueavstand.`, [['gips', g.nPlaterSide], ['gipsskrue', 1]], ['plateB']),
      D('Sparkle skjøter og skruer', 'sparkel', 'Sparkle skruehodene og skjøtene. Følg anvisningen på sparkelen for antall strøk og tørketid.', [['sparkel', 1], ['bredsparkel', 1]], []),
      D('Sluttkontroll', 'ferdig', 'Kjenn over veggen: ingen skruehoder skal stikke ut. Sjekk med vater at den står loddrett.', [['vater', 1]], []),
    ],
  ];
}

/* ---------- IKEA-tegninger ---------- */
function Oppriss({ g, x0 = 40, y0 = 30, maxW = 260, maxH = 150, stender = true, plater = 0, isol = false, ok }) {
  const s = Math.min(maxW / g.L, maxH / g.H); const w = g.L * s, h = g.H * s;
  const X = (m) => x0 + m * s, Y = (m) => y0 + h - m * s;
  return (
    <g>
      <line x1={x0 - 20} y1={Y(0)} x2={X(g.L) + 20} y2={Y(0)} {...ln} /><line x1={x0 - 20} y1={Y(g.H)} x2={X(g.L) + 20} y2={Y(g.H)} {...ln} />
      <rect x={x0} y={Y(T)} width={w} height={T * s} fill="#fff" {...tynn} /><rect x={x0} y={Y(g.H)} width={w} height={2 * T * s} fill="#fff" {...tynn} />
      {stender && g.stendere.map((c, i) => <rect key={i} x={X(c - T / 2)} y={Y(g.H - 2 * T)} width={Math.max(2, T * s)} height={g.stenderL * s} fill="#fff" {...tynn} />)}
      {isol && g.stendere.slice(0, -1).map((c, i) => <path key={i} d={Array.from({ length: 8 }, (_, k) => `${k ? 'L' : 'M'}${X(c + T / 2) + 3 + (k % 2) * (Math.max(4, (g.stendere[i + 1] - c - T) * s) - 6)} ${Y(T) - 6 - k * (g.stenderL * s - 12) / 7}`).join(' ')} {...tynn} stroke="#999" />)}
      {Array.from({ length: plater }, (_, k) => { const a = k * PL_B, e = Math.min(g.L, a + PL_B); return <rect key={k} x={X(a) + 1} y={Y(g.H) + 1} width={(e - a) * s - 2} height={h - 2} fill={k === plater - 1 ? 'url(#skrav)' : '#fff'} {...ln} />; })}
      {ok !== undefined && <OK x={X(g.L) + 16} y={y0 + 10} ja={ok} />}
    </g>
  );
}

function VeggTegning({ type, g }) {
  const W = 340, H = 220; let inn = null;
  const s = Math.min(260 / g.L, 150 / g.H); const x0 = 40, y0 = 30, bunn = y0 + g.H * s;
  const X = (m) => x0 + m * s;
  switch (type) {
    case 'gulvlinje': {
      const sl = Math.min(240 / g.L, 60);
      inn = (<g>
        <line x1={30} y1={40} x2={30} y2={190} {...ln} strokeWidth={4} /><text x={36} y={36} fontSize={11} fill={K}>eksisterende vegg</text>
        <line x1={30} y1={110} x2={30 + g.L * sl} y2={110} {...ln} stroke="#d33" /><line x1={30} y1={110 + B * sl * 3} x2={30 + g.L * sl} y2={110 + B * sl * 3} {...ln} stroke="#d33" />
        <Mal x1={30} y1={110} x2={30 + g.L * sl} y2={110} t={`${cm(g.L)} cm`} side={-16} />
        <text x={40 + g.L * sl / 2} y={110 + B * sl * 3 + 22} textAnchor="middle" fontSize={12} fontWeight={800} fill={K}>{mm(B)} mm mellom strekene</text>
        <path d={`M30 ${150} h16 v-16`} {...ln} /><Nr x={300} y={40} n={1} />
      </g>);
      break;
    }
    case 'lodd':
      inn = (<g>
        <line x1={40} y1={30} x2={300} y2={30} {...ln} /><text x={46} y={24} fontSize={11} fill={K}>tak</text>
        <line x1={40} y1={195} x2={300} y2={195} {...ln} /><text x={46} y={212} fontSize={11} fill={K}>gulv</text>
        <line x1={170} y1={30} x2={170} y2={180} {...tynn} strokeDasharray="5 4" /><path d="M162 180 l8 14 l8 -14 z" fill={K} />
        <path d="M160 30 l10 -8 l10 8" {...ln} /><line x1={160} y1={195} x2={180} y2={195} {...ln} stroke="#d33" strokeWidth={4} />
        <OK x={240} y={110} ja />
      </g>);
      break;
    case 'sviller':
      inn = (<g>{[0, 1, 2].map((i) => <rect key={i} x={40} y={60 + i * 34} width={260} height={18} fill="#fff" {...ln} />)}
        <Mal x1={40} y1={60} x2={300} y2={60} t={`${cm(g.L)} cm`} side={-14} /><text x={170} y={185} textAnchor="middle" fontSize={16} fontWeight={900} fill={K}>3 ×</text><text x={170} y={205} textAnchor="middle" fontSize={11} fill={K}>48 × {mm(B)}</text></g>);
      break;
    case 'merk': {
      const sl = Math.min(260 / g.L, 120);
      inn = (<g>
        {[0, 1].map((r) => <rect key={r} x={40} y={80 + r * 22} width={g.L * sl} height={18} fill="#fff" {...ln} />)}
        {g.stendere.map((c, i) => <g key={i}><line x1={40 + c * sl} y1={72} x2={40 + c * sl} y2={128} {...ln} stroke="#d33" /></g>)}
        {g.midt.length > 0 && <Mal x1={40} y1={80} x2={40 + g.midt[0] * sl} y2={80} t="60" side={-16} />}
        {g.midt.length > 1 && <Mal x1={40} y1={124} x2={40 + g.midt[1] * sl} y2={124} t="120" side={24} />}
        <path d="M26 92 l10 8 l-10 8" {...ln} /><text x={20} y={150} fontSize={11} fontWeight={800} fill={K}>samme ende</text>
        <OK x={310} y={40} ja />
      </g>);
      break;
    }
    case 'feste':
      inn = (<g>
        <line x1={40} y1={196} x2={300} y2={196} {...ln} /><rect x={140} y={178} width={60} height={18} fill="#fff" {...ln} />
        <Skrue x={170} y={160} s={1} />
        <line x1={40} y1={24} x2={300} y2={24} {...ln} /><rect x={140} y={24} width={60} height={36} fill="#fff" {...ln} /><line x1={140} y1={42} x2={200} y2={42} {...tynn} />
        <Skrue x={170} y={88} s={1} r={180} />
        <text x={215} y={192} fontSize={11} fill={K}>bunnsvill</text><text x={215} y={46} fontSize={11} fill={K}>2 × toppsvill</text>
        <Nr x={110} y={187} n={1} /><Nr x={110} y={42} n={2} />
      </g>);
      break;
    case 'kapp':
      inn = (<g><rect x={40} y={100} width={260} height={20} fill="#fff" {...ln} /><Mal x1={40} y1={100} x2={300} y2={100} t={`${cm(g.stenderL)} cm`} side={-16} />
        <text x={170} y={160} textAnchor="middle" fontSize={16} fontWeight={900} fill={K}>{g.nSt} ×</text>
        <text x={170} y={186} textAnchor="middle" fontSize={11} fill={K}>takhøyde {cm(g.H)} − 3 × 4,8 cm svill</text></g>);
      break;
    case 'stendere':
      inn = (<g><Oppriss g={g} />{g.midt.length > 0 && <Mal x1={X(g.stendere[0])} y1={bunn} x2={X(g.midt[0])} y2={bunn} t="c/c 60" side={16} />}<Nr x={20} y={20} n={1} /></g>);
      break;
    case 'kontroll':
      inn = (<g><Oppriss g={g} ok /><Vater x={X(g.stendere[Math.min(1, g.nSt - 1)]) - 45} y={y0 + g.H * s / 2} w={90} r={90} /></g>);
      break;
    case 'plate1':
      inn = (<g><Oppriss g={g} plater={1} />
        <rect x={X(0.1)} y={bunn - 1} width={24} height={8} fill={K} /><text x={X(0.1)} y={bunn + 20} fontSize={11} fill={K}>kloss</text>
        <path d={`M${X(Math.min(PL_B, g.L))} ${bunn + 22} v-18`} {...ln} markerEnd="url(#pil)" />
        <text x={X(Math.min(PL_B, g.L))} y={bunn + 35} textAnchor="middle" fontSize={11} fontWeight={800} fill={K}>kant midt på stender</text></g>);
      break;
    case 'skrue': {
      // Én plate forfra: to kantstendere + midtstender. Skruer som prikker.
      const pw = 170, ph = 184, px = 105, py = 20, e = ph / 2.4; const kx = [px + 7, px + pw - 7], mx = px + pw / 2;
      const kant = []; for (let v = 0; v <= 2.4001; v += 0.2) kant.push(py + Math.min(ph - 4, Math.max(4, v * e)));
      const midt = []; for (let v = 0; v <= 2.4001; v += 0.3) midt.push(py + Math.min(ph - 4, Math.max(4, v * e)));
      const Klamme = ({ x, y1, y2, t, venstre }) => (
        <g><path d={`M${x} ${y1} h${venstre ? -6 : 6} V${y2} h${venstre ? 6 : -6}`} {...ln} />
          <text x={x + (venstre ? -10 : 10)} y={(y1 + y2) / 2 + 4} textAnchor={venstre ? 'end' : 'start'} fontSize={12} fontWeight={900} fill={K}>{t}</text></g>
      );
      inn = (<g><rect x={px} y={py} width={pw} height={ph} fill="#fff" {...ln} />
        <line x1={mx} y1={py} x2={mx} y2={py + ph} {...tynn} strokeDasharray="4 4" />
        {kx.map((x) => kant.map((y, k) => <circle key={x + '-' + k} cx={x} cy={y} r={2.6} fill={K} />))}
        {midt.map((y, k) => <circle key={'m' + k} cx={mx} cy={y} r={2.6} fill={K} />)}
        <Klamme x={px - 6} y1={kant[2]} y2={kant[3]} t="20 cm" venstre />
        <text x={px - 12} y={kant[3] + 18} textAnchor="end" fontSize={10} fill={K}>langs kanten</text>
        <Klamme x={mx - 8} y1={midt[3]} y2={midt[4]} t="30 cm" venstre />
        <text x={mx - 18} y={midt[4] + 16} textAnchor="end" fontSize={10} fill={K}>midt på</text>
        <text x={W / 2} y={py + ph + 14} textAnchor="middle" fontSize={11} fontWeight={800} fill={K}>min. 10 mm fra kanten</text></g>);
      break;
    }
    case 'plater':
      inn = (<g><Oppriss g={g} plater={g.nPlaterSide} stender={false} />
        <text x={X(g.L - g.sisteB / 2)} y={y0 + g.H * s / 2} textAnchor="middle" fontSize={12} fontWeight={900} fill={K}>{cm(g.sisteB)}</text></g>);
      break;
    case 'el':
      inn = (<g><path d="M170 30 L270 190 L70 190 Z" fill="#fff" {...ln} strokeWidth={4} /><text x={170} y={160} textAnchor="middle" fontSize={72} fontWeight={900} fill={K}>!</text>
        <text x={170} y={212} textAnchor="middle" fontSize={12} fontWeight={800} fill={K}>strøm = registrert elektriker</text></g>);
      break;
    case 'isolasjon':
      inn = (<g><Oppriss g={g} isol /></g>);
      break;
    case 'andreSide': {
      const sl = Math.min(260 / g.L, 120); const yy = 100;
      inn = (<g>
        <rect x={40} y={yy - 6} width={g.L * sl} height={4} fill={K} /><rect x={40} y={yy + B * 120 + 2} width={g.L * sl} height={4} fill={K} />
        {g.stendere.map((c, i) => <rect key={i} x={40 + (c - T / 2) * sl} y={yy} width={Math.max(3, T * sl)} height={B * 120} fill="#fff" {...tynn} />)}
        <text x={40} y={yy - 14} fontSize={11} fill={K}>side 1</text><text x={40} y={yy + B * 120 + 24} fontSize={11} fontWeight={800} fill={K}>side 2</text><Nr x={320} y={yy + B * 120 + 4} n={2} />
      </g>);
      break;
    }
    case 'sparkel':
      inn = (<g><rect x={40} y={50} width={130} height={140} fill="#fff" {...ln} /><rect x={170} y={50} width={130} height={140} fill="#fff" {...ln} />
        <rect x={158} y={50} width={24} height={140} fill="url(#skrav)" /><path d="M200 120 l60 -40 l14 14 l-60 40 z" fill="#fff" {...ln} /><line x1={260} y1={80} x2={290} y2={60} {...ln} strokeWidth={5} /></g>);
      break;
    default:
      inn = (<g><Oppriss g={g} plater={g.nPlaterSide} stender={false} ok /></g>);
  }
  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', display: 'block', background: '#fff' }} role="img" aria-label="Monteringstegning">
      <defs>
        <marker id="pil" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 1 L9 5 L0 9 z" fill={K} /></marker>
        <pattern id="skrav" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="6" stroke="#999" strokeWidth="1.5" /></pattern>
      </defs>
      {inn}
    </svg>
  );
}

const DEL_NAVN = {
  maalebaand: 'Målebånd', blyant: 'Blyant', vinkel: 'Vinkel', lodd: 'Lodd / krysslaser', svill: `Svill 48×${mm(B)}`, sag: 'Sag',
  stender: `Stender 48×${mm(B)}`, vater: 'Vater', gips: 'Gipsplate 12,5 mm', kloss: 'Kloss', gipsskrue: 'Gipsskruer min. 3,9×29',
  isolasjon: 'Mineralull', sparkel: 'Sparkel', bredsparkel: 'Bredsparkel',
};

function VeggAnimasjon({ p, synlig, ny, Iso }) {
  const [t, setT] = useState(0);
  useEffect(() => {
    let id; const s = performance.now();
    const tikk = (n) => { setT(((n - s) / 1000) % 3.2); id = requestAnimationFrame(tikk); };
    const redusert = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if (!redusert) id = requestAnimationFrame(tikk); else setT(2);
    return () => cancelAnimationFrame(id);
  }, [ny.join()]);
  const fall = Math.max(0, 1 - t / 1.3); const e = fall * fall; const blink = t > 1.3 && t < 2.6;
  const bx = veggBokser(p).filter((q) => synlig.has(q.tag) || ny.includes(q.tag)).map((q) => ny.includes(q.tag)
    ? { ...q, dz: e * 1.0, fall: true, c: blink || e > 0 ? '#f7b83f' : q.c } : q);
  return <Iso p={p} bokser={bx} vinkel={-30} hoyde={240} interaktiv />;
}

export function veggSynlig(alle, stegIdx, delIdx) {
  const synlig = new Set();
  alle.forEach((ds, si) => ds.forEach((x, di) => { if (si < stegIdx || (si === stegIdx && di < delIdx)) x.ny.forEach((tg) => synlig.add(tg)); }));
  if (synlig.has('plate1')) synlig.delete('linje');
  return synlig;
}

export function VeggManual({ p, stegIdx, delIdx, settDel, kryss, vend, Iso, C }) {
  const alle = veggDeler(p); const deler = alle[stegIdx]; const d = deler[Math.min(delIdx, deler.length - 1)];
  const g = veggGeo(p.mal); const video = VEGG_VIDEO[stegIdx];
  const [vis, setVis] = useState('tegning');
  useEffect(() => { if (vis === 'video' && !video) setVis('tegning'); }, [video, vis]);
  const synlig = veggSynlig(alle, stegIdx, delIdx);
  let ny = d.ny; if (!ny.length && synlig.size === 0) ny = ['linje'];
  const faner = [['tegning', 'Tegning'], ['3d', '3D'], ...(video ? [['video', 'Video']] : [])];
  const fn = { border: 0, borderRadius: 9, padding: '8px 0', fontWeight: 800, fontSize: 13, flex: 1 };
  const rod = { background: '#5a2a1f', border: '1px solid #e25b4b', borderRadius: 10, padding: 10, fontSize: 13, marginBottom: 8 };
  return (
    <div>
      {stegIdx === 0 && delIdx === 0 && <>
        <div style={rod}>⛔ Denne guiden gjelder en ny, <b>ikke-bærende</b> innervegg. Skal du rive, flytte eller endre en bærende vegg, trenger du fagkyndig – og ofte søknad til kommunen.</div>
        {g.varsler.map((v, i) => <div key={i} style={{ ...rod, background: '#4a3a12', borderColor: '#f7b83f' }}>⚠️ {v}</div>)}
      </>}
      {d.rod && <div style={rod}>⛔ {d.tekst.split('.')[0]}.</div>}
      <div style={{ display: 'flex', gap: 6, marginBottom: 8, background: '#ffffff10', padding: 4, borderRadius: 12 }}>
        {faner.map(([k, t]) => <button key={k} onClick={() => setVis(k)} style={{ ...fn, background: vis === k ? C.gold : 'transparent', color: vis === k ? C.ink : 'white' }}>{t}</button>)}
      </div>
      <div style={{ borderRadius: 12, overflow: 'hidden', background: '#fff', position: 'relative' }}>
        {vis === 'tegning' && <VeggTegning type={d.tegning} g={g} />}
        {vis === '3d' && <div style={{ background: '#FBFBF9' }}><VeggAnimasjon p={p} synlig={synlig} ny={ny} Iso={Iso} /></div>}
        {vis === 'video' && <video src={video} controls playsInline style={{ width: '100%', display: 'block', background: '#000' }} />}
        <div style={{ position: 'absolute', left: 8, top: 8, background: C.ink, color: 'white', borderRadius: 8, padding: '3px 8px', fontWeight: 900, fontSize: 13 }}>{stegIdx + 1}.{delIdx + 1}</div>
      </div>
      {d.deler.filter(([, n]) => n > 0).length > 0 && (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 8 }}>
          {d.deler.filter(([, n]) => n > 0).map(([k, n]) => <span key={k} style={{ background: '#fff', color: C.ink, borderRadius: 8, padding: '4px 8px', fontSize: 12, fontWeight: 800 }}>{n > 1 ? `${n} × ` : ''}{DEL_NAVN[k]}</span>)}
        </div>
      )}
      <div style={{ marginTop: 10, fontWeight: 800, fontSize: 17 }}>{d.tittel}</div>
      <p style={{ margin: '6px 0 0', fontSize: 15, lineHeight: 1.5, color: '#dfe8ef' }}>{d.tekst}</p>
      <div style={{ display: 'flex', gap: 6, marginTop: 12 }}>
        {deler.map((x, k) => (
          <button key={k} aria-label={`Del ${k + 1}: ${x.tittel}`} onClick={() => settDel(k)} style={{ flex: 1, height: 8, border: 0, borderRadius: 4, padding: 0, background: kryss[k] ? C.ok : k === delIdx ? C.gold : '#ffffff30' }} />
        ))}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 8, marginTop: 10 }}>
        <button disabled={delIdx === 0} onClick={() => settDel(delIdx - 1)} style={{ border: '1px solid #ffffff30', background: '#ffffff14', color: 'white', borderRadius: 12, padding: 12, fontWeight: 800, opacity: delIdx === 0 ? 0.4 : 1 }}>Forrige</button>
        <button onClick={() => { if (!kryss[delIdx]) vend(delIdx); if (delIdx + 1 < deler.length) settDel(delIdx + 1); }} style={{ border: 0, background: kryss[delIdx] ? C.ok : 'white', color: C.ink, borderRadius: 12, padding: 12, fontWeight: 900 }}>
          {kryss[delIdx] ? '✓ Gjort' : 'Gjort'}{delIdx + 1 < deler.length ? ' – neste del' : ''}
        </button>
      </div>
    </div>
  );
}
