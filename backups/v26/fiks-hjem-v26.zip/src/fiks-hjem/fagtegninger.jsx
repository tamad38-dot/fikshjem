import React, { useMemo, useState } from 'react';
import { lagFagtekst } from '@/lib/fagtekst.functions';
import { visBeskjed } from '../lib/beskjed.js';

/* ================================================================
   FAGTEGNINGER
   ----------------------------------------------------------------
   Egen side der hele prosjektet blir til ferdige fagtegninger:
   plantegning med mål, snitt med takhøyde og takvinkel, fasade og
   situasjonskart. Du skriver inn tittel, målestokk og fagtekst på
   hvert ark, og skriver alt ut som PDF til kommunen.
   ================================================================ */

const T = {
  rot: { display: 'grid', gap: 12, background: '#FBFBF9', color: '#1C2321', borderRadius: 12, padding: 12 }, // lyst papir: tekstene her er laget for lys bakgrunn (før var de mørke på mørkt kort)
  tittel: { fontSize: 14, fontWeight: 700, color: '#1C2321' },
  tekst: { fontSize: 13, lineHeight: 1.5, color: '#3A443E' },
  smaa: { fontSize: 11, color: '#8A938C', lineHeight: 1.4 },
  boks: { border: '1px solid #E3E7E2', borderRadius: 10, padding: 10, display: 'grid', gap: 8, background: '#fff' },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: 8 },
  felt: { display: 'grid', gap: 4, fontSize: 11, color: '#5C665E' },
  inn: { padding: '8px 9px', borderRadius: 8, border: '1px solid #C8D0C8', fontSize: 13, background: '#fff', width: '100%' },
  knapp: { padding: '10px 12px', borderRadius: 10, border: 'none', background: '#2F5F55', color: '#fff', fontSize: 13, fontWeight: 700, cursor: 'pointer' },
  knappSek: { padding: '8px 11px', borderRadius: 10, border: '1px solid #C8D0C8', background: '#fff', color: '#1C2321', fontSize: 12, fontWeight: 600, cursor: 'pointer' },
  rad: { display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' },
  ark: { border: '1px solid #1C2321', borderRadius: 4, background: '#fff', padding: 10, display: 'grid', gap: 6 },
  adv: { background: '#FDF3E3', border: '1px solid #E3B341', borderRadius: 10, padding: 10, fontSize: 12, color: '#6A4E10', lineHeight: 1.5 },
};

const tall = (v, f = 0) => (Number.isFinite(Number(v)) ? Number(v) : f);
const rund = (v, d = 2) => Math.round(tall(v) * 10 ** d) / 10 ** d;
const kr = (n) => Math.round(Number(n) || 0).toLocaleString('no-NO');
const idag = () => new Date().toLocaleDateString('no-NO');

export const ARKTYPER = [
  { type: 'plan', navn: 'Plantegning', maalestokk: '1:100' },
  { type: 'snitt', navn: 'Snitt A–A', maalestokk: '1:100' },
  { type: 'fasade', navn: 'Fasade', maalestokk: '1:100' },
  { type: 'situasjon', navn: 'Situasjonsplan', maalestokk: '1:500' },
];

export const standardArk = () => ARKTYPER.map((a, i) => ({
  id: 'ark-' + a.type,
  type: a.type,
  tittel: a.navn,
  maalestokk: a.maalestokk,
  nummer: 'A' + String(i + 1).padStart(2, '0'),
  notat: '',
  med: true,
}));

/* Ferdige fagtekster for enkel versjon (uten AI). {} fylles med prosjekttall. */
export const STANDARDTEKST = {
  plan: (p) => [
    'Plantegning viser eksisterende romfordeling med innvendige mål i meter.',
    'Samlet areal ' + rund(p.areal, 1) + ' m². Fri takhøyde ' + rund(p.takhoyde, 2) + ' m.',
    'Bærende vegger beholdes. Dører og vinduer er markert med D og V.',
    'Rømningsvei og dagslys i oppholdsrom i samsvar med TEK17 § 13.',
  ].join('\n'),
  snitt: (p) => [
    'Snitt A–A viser etasjehøyde og takkonstruksjon.',
    'Fri takhøyde ' + rund(p.takhoyde, 2) + ' m. Takform ' + ((p.tak && p.tak.type) || 'saltak') + ' med vinkel ' + rund((p.tak && p.tak.takvinkel) || 30, 0) + '°.',
    'Isolasjon og dampsperre utføres etter TEK17 § 14 med lufttett sjikt.',
  ].join('\n'),
  fasade: () => [
    'Fasaden viser eksisterende og nye åpninger.',
    'Blå = beholdes, grønn = ny, rød stiplet = fjernes.',
    'Kledning, farge og vindusinndeling tilpasses eksisterende bygg.',
  ].join('\n'),
  situasjon: (p, k) => [
    'Situasjonsplan for ' + ((k && k.adresse) || 'eiendommen') + ', gnr ' + ((k && k.gnr) || '–') + '/bnr ' + ((k && k.bnr) || '–') + '.',
    'Bygget er målsatt på planen. Avstand til nabogrense og vei måles på stedet.',
    'Tiltaket endrer ikke bebygd areal (BYA).',
  ].join('\n'),
};

/* ---------- tegningene ---------- */

function romBoks(rom) {
  const alle = (rom || []).flatMap((r) => r.punkter || []);
  if (!alle.length) return null;
  const xs = alle.map((p) => tall(p.x));
  const ys = alle.map((p) => tall(p.y));
  return { x0: Math.min(...xs), y0: Math.min(...ys), x1: Math.max(...xs), y1: Math.max(...ys) };
}

/* Kommunens krav tegnet rett inn på arket, i eget felt under tegningen. */
const kravListeAv = (krav) => (krav || []).filter(Boolean).slice(0, 6);
const kravHoyde = (krav) => {
  const n = kravListeAv(krav).length;
  return n ? 20 + n * 10 : 0;
};
const arkViewBox = (krav) => '0 0 360 ' + (230 + kravHoyde(krav));

function KravBoks({ krav }) {
  const liste = kravListeAv(krav);
  if (!liste.length) return null;
  const h = kravHoyde(krav) - 6;
  return (
    <g data-tf="krav-i-tegning">
      <rect x="6" y="234" width="348" height={h} fill="#FFFDF5" stroke="#B4543F" strokeWidth="1" rx="2" />
      <text x="12" y="245" fontSize="7" fontWeight="700" fill="#B4543F">KRAV FRA KOMMUNEN</text>
      {liste.map((t, i) => (
        <text key={i} x="12" y={256 + i * 10} fontSize="6.5" fill="#1C2321">
          K{i + 1}. {String(t).slice(0, 84)}
        </text>
      ))}
    </g>
  );
}

function PlanTegning({ rom, apninger, takhoyde, krav }) {
  const boks = romBoks(rom);
  if (!boks) return <div style={T.smaa}>Legg inn rom først, så tegnes planen her.</div>;
  const b = Math.max(1, boks.x1 - boks.x0);
  const d = Math.max(1, boks.y1 - boks.y0);
  const skala = Math.min(300 / b, 170 / d);
  const px = (v) => (v - boks.x0) * skala + 30;
  const py = (v) => (v - boks.y0) * skala + 22;
  return (
    <svg viewBox={arkViewBox(krav)} width="100%" role="img" aria-label="Plantegning med mål">
      <rect x="0" y="0" width="360" height={230 + kravHoyde(krav)} fill="#fff" />
      {(rom || []).map((r) => {
        const pts = (r.punkter || []).map((p) => px(p.x) + ',' + py(p.y)).join(' ');
        const cx = (r.punkter || []).reduce((s, p) => s + px(p.x), 0) / Math.max(1, (r.punkter || []).length);
        const cy = (r.punkter || []).reduce((s, p) => s + py(p.y), 0) / Math.max(1, (r.punkter || []).length);
        return (
          <g key={r.id}>
            <polygon points={pts} fill="#F2F5F1" stroke="#1C2321" strokeWidth="2" />
            <text x={cx} y={cy} textAnchor="middle" fontSize="8" fontWeight="700" fill="#1C2321">{r.navn}</text>
            {(r.punkter || []).map((p, i) => {
              const q = r.punkter[(i + 1) % r.punkter.length];
              const len = Math.hypot(tall(q.x) - tall(p.x), tall(q.y) - tall(p.y));
              if (len < 0.3) return null;
              return (
                <text key={i} x={(px(p.x) + px(q.x)) / 2} y={(py(p.y) + py(q.y)) / 2 - 3}
                  textAnchor="middle" fontSize="6.5" fill="#2F5F55">{rund(len, 2)} m</text>
              );
            })}
          </g>
        );
      })}
      {(apninger || []).map((a, i) => {
        const r = (rom || []).find((x) => x.id === a.romId);
        if (!r || !r.punkter || !r.punkter.length) return null;
        const p = r.punkter[tall(a.veggIndeks) % r.punkter.length];
        const q = r.punkter[(tall(a.veggIndeks) + 1) % r.punkter.length];
        const len = Math.hypot(tall(q.x) - tall(p.x), tall(q.y) - tall(p.y)) || 1;
        const t = Math.min(1, Math.max(0, tall(a.pos) / len));
        const x = px(tall(p.x) + (tall(q.x) - tall(p.x)) * t);
        const y = py(tall(p.y) + (tall(q.y) - tall(p.y)) * t);
        return (
          <g key={a.id || i}>
            <circle cx={x} cy={y} r="4.5" fill="#E3B341" stroke="#1C2321" strokeWidth="0.8" />
            <text x={x} y={y + 2} textAnchor="middle" fontSize="5.5" fontWeight="700">{a.type === 'Dør' ? 'D' : 'V'}</text>
          </g>
        );
      })}
      <line x1="30" y1="212" x2={30 + b * skala} y2="212" stroke="#1C2321" strokeWidth="0.8" />
      <text x={30 + (b * skala) / 2} y="222" textAnchor="middle" fontSize="7">Bygget {rund(b, 2)} m bredt · {rund(d, 2)} m dypt · takhøyde {rund(takhoyde, 2)} m</text>
      <KravBoks krav={krav} />
    </svg>
  );
}

function SnittTegning({ rom, takhoyde, tak, krav }) {
  const boks = romBoks(rom);
  const b = boks ? Math.max(1, boks.x1 - boks.x0) : tall(tak && tak.bredde, 6);
  const h = Math.max(1.8, tall(takhoyde, 2.4));
  const vinkel = Math.max(0, tall(tak && tak.takvinkel, 30));
  const monehoyde = (tak && tak.type === 'pulttak' ? b : b / 2) * Math.tan((vinkel * Math.PI) / 180);
  const total = h + monehoyde;
  const skala = Math.min(280 / b, 150 / Math.max(1, total));
  const x0 = 45;
  const gulv = 190;
  const bp = b * skala;
  const hp = h * skala;
  const mp = monehoyde * skala;
  return (
    <svg viewBox={arkViewBox(krav)} width="100%" role="img" aria-label="Snitt med takhøyde og takvinkel">
      <rect x="0" y="0" width="360" height={230 + kravHoyde(krav)} fill="#fff" />
      <rect x={x0} y={gulv - hp} width={bp} height={hp} fill="#F2F5F1" stroke="#1C2321" strokeWidth="2" />
      {tak && tak.type === 'pulttak' ? (
        <polygon points={`${x0},${gulv - hp} ${x0 + bp},${gulv - hp - mp} ${x0 + bp},${gulv - hp}`} fill="#E7EDE8" stroke="#1C2321" strokeWidth="2" />
      ) : (
        <polygon points={`${x0},${gulv - hp} ${x0 + bp / 2},${gulv - hp - mp} ${x0 + bp},${gulv - hp}`} fill="#E7EDE8" stroke="#1C2321" strokeWidth="2" />
      )}
      <line x1={x0 - 14} y1={gulv} x2={x0 - 14} y2={gulv - hp} stroke="#2F5F55" strokeWidth="0.8" />
      <text x={x0 - 18} y={gulv - hp / 2} textAnchor="middle" fontSize="7" transform={`rotate(-90 ${x0 - 18} ${gulv - hp / 2})`}>Takhøyde {rund(h, 2)} m</text>
      <line x1={x0} y1={gulv + 12} x2={x0 + bp} y2={gulv + 12} stroke="#2F5F55" strokeWidth="0.8" />
      <text x={x0 + bp / 2} y={gulv + 22} textAnchor="middle" fontSize="7">Spenn {rund(b, 2)} m</text>
      <text x={x0 + bp / 2} y={gulv - hp - mp - 6} textAnchor="middle" fontSize="7">
        {tak && tak.type === 'pulttak' ? 'Pulttak' : 'Saltak'} {rund(vinkel, 0)}° · mønehøyde {rund(total, 2)} m over gulv
      </text>
      <line x1={x0} y1={gulv} x2={x0 + bp} y2={gulv} stroke="#1C2321" strokeWidth="3" />
      <KravBoks krav={krav} />
    </svg>
  );
}

function FasadeTegningArk({ fasade, krav }) {
  const f = fasade || {};
  const b = Math.max(2, tall(f.bredde, 8));
  const h = Math.max(2, tall(f.hoyde, 5));
  const skala = Math.min(280 / b, 150 / h);
  const x0 = 40;
  const y0 = 190 - h * skala;
  const farge = { beholdes: '#5790a6', ny: '#3f8f5e', fjernes: '#b4543f' };
  return (
    <svg viewBox={arkViewBox(krav)} width="100%" role="img" aria-label="Fasadetegning">
      <rect x="0" y="0" width="360" height={230 + kravHoyde(krav)} fill="#fff" />
      <rect x={x0} y={y0} width={b * skala} height={h * skala} fill="#F6F7F4" stroke="#1C2321" strokeWidth="2" />
      {(f.elementer || []).map((e) => (
        <g key={e.id}>
          <rect x={x0 + tall(e.x) * skala} y={y0 + (h - tall(e.y) - tall(e.h)) * skala}
            width={Math.max(2, tall(e.b) * skala)} height={Math.max(2, tall(e.h) * skala)}
            fill="none" stroke={farge[e.status] || '#1C2321'} strokeWidth="2"
            strokeDasharray={e.status === 'fjernes' ? '4 3' : undefined} />
          <text x={x0 + (tall(e.x) + tall(e.b) / 2) * skala} y={y0 + (h - tall(e.y) - tall(e.h)) * skala - 3}
            textAnchor="middle" fontSize="6" fill="#1C2321">{e.type} {rund(e.b, 2)}×{rund(e.h, 2)}</text>
        </g>
      ))}
      <text x={x0 + (b * skala) / 2} y="205" textAnchor="middle" fontSize="7">Fasadebredde {rund(b, 2)} m · høyde {rund(h, 2)} m</text>
      <text x={x0} y="218" fontSize="6.5" fill="#5C665E">Blå = beholdes · grønn = ny · rød stiplet = fjernes</text>
      <KravBoks krav={krav} />
    </svg>
  );
}

function SituasjonTegning({ rom, kommunedata, krav }) {
  const boks = romBoks(rom);
  const b = boks ? Math.max(1, boks.x1 - boks.x0) : 8;
  const d = boks ? Math.max(1, boks.y1 - boks.y0) : 10;
  const skala = Math.min(150 / b, 110 / d);
  const k = kommunedata || {};
  return (
    <svg viewBox={arkViewBox(krav)} width="100%" role="img" aria-label="Situasjonsplan">
      <rect x="0" y="0" width="360" height={230 + kravHoyde(krav)} fill="#fff" />
      <rect x="30" y="25" width="300" height="170" fill="#F2F5F1" stroke="#1C2321" strokeWidth="1.5" />
      <rect x={180 - (b * skala) / 2} y={110 - (d * skala) / 2} width={b * skala} height={d * skala}
        fill="#fff" stroke="#1C2321" strokeWidth="2" />
      <text x="180" y="110" textAnchor="middle" fontSize="7.5" fontWeight="700">Bygget {rund(b, 2)} × {rund(d, 2)} m</text>
      <text x="40" y="40" fontSize="7">{k.adresse || 'Adresse ikke lagt inn'}</text>
      <text x="40" y="50" fontSize="7">Gnr {k.gnr || '–'} / Bnr {k.bnr || '–'} · {k.kommune || 'kommune'} kommune</text>
      <path d="M320 45 L320 30 L316 36 M320 30 L324 36" stroke="#1C2321" strokeWidth="1.2" fill="none" />
      <text x="320" y="55" textAnchor="middle" fontSize="6.5">N</text>
      <text x="40" y="188" fontSize="6.5" fill="#5C665E">Avstander til nabogrense måles på stedet og føres inn av søker.</text>
      <KravBoks krav={krav} />
    </svg>
  );
}

function Tegning({ ark, prosjekt, kommunedata, krav }) {
  const p = prosjekt || {};
  if (ark.type === 'plan') return <PlanTegning rom={p.rom} apninger={p.apninger} takhoyde={p.takhoyde} krav={krav} />;
  if (ark.type === 'snitt') return <SnittTegning rom={p.rom} takhoyde={p.takhoyde} tak={p.tak} krav={krav} />;
  if (ark.type === 'fasade') return <FasadeTegningArk fasade={p.fasade} krav={krav} />;
  return <SituasjonTegning rom={p.rom} kommunedata={kommunedata} krav={krav} />;
}

/* ---------- utskrift ---------- */

export function skrivUtFagtegninger(ark, prosjekt, kommunedata, varsle, krav) {
  const kravListe = (krav || []).filter(Boolean);
  const kravHtml = kravListe.length
    ? '<div class="krav"><b>Krav fra kommunen:</b><ol>'
      + kravListe.map((t) => '<li>' + String(t).replace(/</g, '&lt;') + '</li>').join('')
      + '</ol></div>'
    : '';
  if (typeof document === 'undefined') return;
  const vindu = window.open('', '_blank');
  if (!vindu) { if (varsle) varsle('Nettleseren blokkerte utskriftsvinduet. Tillat popup og prøv igjen.'); return; }
  const k = kommunedata || {};
  const p = prosjekt || {};
  const sider = (ark || []).filter((a) => a.med).map((a) => {
    const node = document.querySelector('[data-ark="' + a.id + '"]');
    const svg = node ? node.innerHTML : '';
    return '<section class="ark">'
      + '<div class="tegning">' + svg + '</div>'
      + (a.notat ? '<div class="notat"><b>Fagtekst:</b> ' + String(a.notat).replace(/</g, '&lt;').replace(/\n/g, '<br>') + '</div>' : '')
      + kravHtml
      + '<table class="tittelfelt"><tr>'
      + '<td><b>' + a.tittel + '</b><br>' + (k.adresse || 'Adresse mangler') + '</td>'
      + '<td>Gnr/Bnr: ' + (k.gnr || '–') + '/' + (k.bnr || '–') + '<br>' + (k.kommune || '') + ' kommune</td>'
      + '<td>Målestokk ' + a.maalestokk + '<br>Dato ' + idag() + '</td>'
      + '<td>Tegning ' + a.nummer + '<br>' + (k.tiltakshaver || p.navn || '') + '</td>'
      + '</tr></table></section>';
  }).join('');
  vindu.document.write(
    '<!doctype html><html lang="no"><head><meta charset="utf-8"><title>Fagtegninger – ' + (k.adresse || p.navn || 'prosjekt') + '</title>'
    + '<style>@page{size:A4 landscape;margin:10mm}'
    + 'body{font-family:Helvetica,Arial,sans-serif;color:#111;font-size:11px;margin:0}'
    + '.ark{box-sizing:border-box;height:187mm;overflow:hidden;border:2px solid #111;padding:6mm;page-break-after:always;page-break-inside:avoid;display:flex;flex-direction:column;gap:4px}'
    + '.ark:last-child{page-break-after:auto}'
    + '.tegning{flex:1 1 auto;min-height:0;display:flex;align-items:center;justify-content:center}'
    + '.tegning svg{width:100%;height:100%;max-height:130mm;object-fit:contain}'
    + '.notat{border-left:3px solid #2F5F55;padding-left:6px;line-height:1.5}'
    + '.krav{border:1px solid #B4543F;padding:4px 6px;line-height:1.4}'
    + '.krav ol{margin:2px 0 0 16px;padding:0}'
    + '.tittelfelt{width:100%;border-collapse:collapse;margin-top:auto}'
    + '.tittelfelt td{border:1px solid #111;padding:5px;width:25%;vertical-align:top}'
    + '@media print{body{margin:0} svg{filter:grayscale(1)}}</style></head><body>'
    + sider
    + '</body></html>'
  );
  vindu.document.close();
  vindu.focus();
  setTimeout(() => vindu.print(), 400);
}

/* ---------- siden ---------- */

export default function Fagtegninger({ prosjekt, kommunedata, onSkrivUt }) {
  const [ark, setArk] = useState(standardArk);
  const [modus, setModus] = useState('enkel'); // 'enkel' = ferdige tekster, 'ai' = AI-hjelp
  const [jobber, setJobber] = useState('');
  const [aiFeil, setAiFeil] = useState('');
  const [kravTekst, setKravTekst] = useState('');
  const [boligtype, setBoligtype] = useState('villa');
  const p = prosjekt || {};
  const k = kommunedata || {};
  const kravListe = useMemo(
    () => kravTekst.split('\n').map((s) => s.trim()).filter(Boolean),
    [kravTekst],
  );
  const endre = (id, felt, verdi) => setArk((liste) => liste.map((a) => (a.id === id ? { ...a, [felt]: verdi } : a)));

  const medKrav = (tekst) => (kravListe.length
    ? tekst + '\nKrav fra kommunen: ' + kravListe.map((t, i) => 'K' + (i + 1) + ' ' + t).join('. ') + '.'
    : tekst);
  const settStandard = (a) => {
    const lag = STANDARDTEKST[a.type];
    if (lag) endre(a.id, 'notat', medKrav(lag(p, k)));
  };
  const fyllAlleStandard = () => setArk((liste) => liste.map((a) => (
    STANDARDTEKST[a.type] ? { ...a, notat: medKrav(STANDARDTEKST[a.type](p, k)) } : a
  )));

  const aiForArk = async (a) => {
    setAiFeil('');
    endre(a.id, 'jobber', true);
    try {
      const svar = await lagFagtekst({
        data: {
          arkType: a.type,
          arkTittel: a.tittel,
          maalestokk: a.maalestokk,
          adresse: k.adresse || '',
          gnr: String(k.gnr || ''),
          bnr: String(k.bnr || ''),
          kommune: k.kommune || '',
          areal: tall(p.areal, 0),
          takhoyde: tall(p.takhoyde, 2.4),
          takform: (p.tak && p.tak.type) || 'saltak',
          takvinkel: tall(p.tak && p.tak.takvinkel, 30),
          rom: (p.rom || []).map((r) => r.navn || 'Rom'),
          jobber: jobber ? jobber.split(',').map((s) => s.trim()).filter(Boolean) : [],
          beskrivelse: k.beskrivelse || '',
          boligtype,
          krav: kravListe,
        },
      });
      if (svar && svar.ok) endre(a.id, 'notat', svar.tekst);
      else setAiFeil((svar && svar.feil) || 'AI-hjelpen svarte ikke.');
    } catch (e) {
      setAiFeil('AI-hjelpen er ikke tilgjengelig nå. Bruk den enkle versjonen så lenge.');
    } finally {
      endre(a.id, 'jobber', false);
    }
  };
  const mangler = useMemo(() => {
    const m = [];
    if (!(p.rom || []).length) m.push('rom fra tegningen eller oppmålingen');
    if (!k.adresse) m.push('adresse');
    if (!k.gnr || !k.bnr) m.push('gårds- og bruksnummer');
    return m;
  }, [p.rom, k.adresse, k.gnr, k.bnr]);

  return (
    <div style={T.rot} data-tf="fagtegninger">
      <div style={T.tekst}>
        Her blir prosjektet til ferdige fagtegninger: plan, snitt, fasade og situasjonsplan.
        Skriv inn tittel, målestokk og fagtekst på hvert ark, og skriv alt ut som PDF til kommunen.
      </div>

      <div style={T.boks} data-tf="fagtekst-modus">
        <div style={T.tittel}>Hvordan vil du skrive fagteksten?</div>
        <div style={T.rad}>
          <button
            type="button"
            data-tf="modus-enkel"
            aria-pressed={modus === 'enkel'}
            style={modus === 'enkel' ? T.knapp : T.knappSek}
            onClick={() => setModus('enkel')}
          >
            Enkel versjon
          </button>
          <button
            type="button"
            data-tf="modus-ai"
            aria-pressed={modus === 'ai'}
            style={modus === 'ai' ? T.knapp : T.knappSek}
            onClick={() => setModus('ai')}
          >
            🤖 Med AI-hjelp
          </button>
        </div>
        <div style={T.smaa}>
          {modus === 'enkel'
            ? 'Enkel versjon setter inn ferdige fagtekster med målene dine. Ingen internett-hjelp trengs.'
            : 'AI-hjelpen skriver fagteksten ut fra målene, rommene og tiltaket ditt. Du kan alltid rette teksten etterpå.'}
        </div>
        {modus === 'ai' ? (
          <div style={T.felt} data-tf="boligtype">
            Hva slags bolig er det?
            <div style={T.rad}>
              {[['villa', 'Villa / enebolig'], ['leilighet', 'Leilighet'], ['rekkehus', 'Rekkehus']].map(([id, navn]) => (
                <button
                  key={id}
                  type="button"
                  data-tf={'boligtype-' + id}
                  aria-pressed={boligtype === id}
                  style={boligtype === id ? T.knapp : T.knappSek}
                  onClick={() => setBoligtype(id)}
                >
                  {navn}
                </button>
              ))}
            </div>
          </div>
        ) : null}
        {modus === 'ai' ? (
          <label style={T.felt}>
            Hva skal gjøres? (skill med komma)
            <input
              style={T.inn}
              value={jobber}
              data-tf="ai-jobber"
              placeholder="nytt vindu i sørfasaden, nytt bad, etterisolering av tak"
              onChange={(e) => setJobber(e.target.value)}
            />
          </label>
        ) : null}
        <button
          type="button"
          style={T.knappSek}
          data-tf="fyll-alle-standard"
          onClick={fyllAlleStandard}
        >
          Fyll alle ark med ferdig fagtekst
        </button>
        {aiFeil ? <div style={T.adv} data-tf="ai-feil">{aiFeil}</div> : null}
      </div>

      <div style={T.boks} data-tf="kommunekrav">
        <div style={T.tittel}>Krav fra kommunen</div>
        <div style={T.smaa}>
          Skriv ett krav per linje. Kravene tegnes rett inn på alle arkene som K1, K2 … og følger med i PDF-en,
          slik at kommunen ser nøyaktig hva som skal gjøres.
        </div>
        <textarea
          style={{ ...T.inn, minHeight: 72 }}
          value={kravTekst}
          data-tf="kommunekrav-tekst"
          placeholder={'Rømningsvindu i soverom, min. 0,5 × 0,6 m\nAvstand til nabogrense min. 4 m\nParkering for to biler på egen tomt'}
          onChange={(e) => setKravTekst(e.target.value)}
        />
        <div style={T.smaa}>{kravListe.length} krav tegnes inn på arkene.</div>
      </div>



      {ark.map((a) => (
        <div key={a.id} style={T.boks}>
          <div style={T.rad}>
            <label style={{ ...T.rad, gap: 6, fontSize: 12, fontWeight: 700, color: '#1C2321' }}>
              <input type="checkbox" checked={a.med} onChange={(e) => endre(a.id, 'med', e.target.checked)} />
              {a.tittel}
            </label>
            <span style={{ ...T.smaa, marginLeft: 'auto' }}>Tegning {a.nummer}</span>
          </div>
          <div style={T.grid}>
            <label style={T.felt}>
              Tittel på arket
              <input style={T.inn} value={a.tittel} onChange={(e) => endre(a.id, 'tittel', e.target.value)} />
            </label>
            <label style={T.felt}>
              Målestokk
              <input style={T.inn} value={a.maalestokk} onChange={(e) => endre(a.id, 'maalestokk', e.target.value)} />
            </label>
            <label style={T.felt}>
              Tegningsnummer
              <input style={T.inn} value={a.nummer} onChange={(e) => endre(a.id, 'nummer', e.target.value)} />
            </label>
          </div>
          <label style={T.felt}>
            Fagtekst på tegningen
            <textarea style={{ ...T.inn, minHeight: 64 }} value={a.notat}
              placeholder="For eksempel: Bærende vegg beholdes. Nytt vindu i sørfasaden, U-verdi 0,8."
              onChange={(e) => endre(a.id, 'notat', e.target.value)} />
          </label>
          <div style={T.rad}>
            <button type="button" style={T.knappSek} data-tf={'standardtekst-' + a.type} onClick={() => settStandard(a)}>
              Sett inn ferdig fagtekst
            </button>
            {modus === 'ai' ? (
              <button
                type="button"
                style={T.knappSek}
                data-tf={'ai-tekst-' + a.type}
                disabled={!!a.jobber}
                onClick={() => aiForArk(a)}
              >
                {a.jobber ? 'AI skriver …' : '🤖 La AI skrive fagteksten'}
              </button>
            ) : null}
          </div>
          <div style={T.ark} data-ark={a.id}>
            <Tegning ark={a} prosjekt={p} kommunedata={k} krav={kravListe} />
          </div>
          <button
            type="button"
            style={T.knappSek}
            data-tf={'pdf-ark-' + a.type}
            onClick={() => skrivUtFagtegninger([{ ...a, med: true }], p, k, (m) => visBeskjed(m), kravListe)}
          >
            ⬇︎ Last ned dette arket som PDF
          </button>
          <div style={T.smaa}>
            {a.tittel} · målestokk {a.maalestokk} · {k.adresse || 'adresse mangler'} · Gnr {k.gnr || '–'}/Bnr {k.bnr || '–'} · {idag()}
          </div>
        </div>
      ))}

      <div style={T.boks}>
        <div style={T.tittel}>Prosjektet på tegningene</div>
        <div style={T.smaa}>
          {(p.rom || []).length} rom · {rund(p.areal, 1)} m² · takhøyde {rund(p.takhoyde, 2)} m ·{' '}
          {p.jobber || 0} fagjobber · totalt {kr(p.prisFra)}–{kr(p.prisTil)} kr
        </div>
      </div>

      {mangler.length ? <div style={T.adv}>Husk å fylle inn {mangler.join(', ')} før du leverer tegningene.</div> : null}

      <button type="button" style={T.knapp} data-tf="skriv-ut-fagtegninger"
        onClick={() => (onSkrivUt ? onSkrivUt(ark, kravListe) : skrivUtFagtegninger(ark, p, k, (m) => visBeskjed(m), kravListe))}>
        Skriv ut / lagre alle fagtegningene som PDF
      </button>
    </div>
  );
}
