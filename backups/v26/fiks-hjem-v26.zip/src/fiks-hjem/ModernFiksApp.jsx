import React, { useState, useEffect, useRef, lazy, Suspense } from 'react';
import {
  Home, Compass, FolderKanban, User, Camera, Box, House, CalendarDays, Wrench, Hammer,
  ChevronLeft, ChevronRight, Play, Pause, Search, CheckCircle2, Circle, Maximize,
  ShoppingCart, Share2, Save, Plus, Trash2, RotateCcw, Sun, MapPin, Ruler, Lightbulb,
} from 'lucide-react';
import deck from '../assets/fiks-hjem-category-deck.jpg';
import roof from '../assets/fiks-hjem-roof.jpg';
import wall from '../assets/fiks-hjem-category-wall.jpg';
import floor from '../assets/fiks-hjem-category-floor.jpg';
import stairs from '../assets/fiks-hjem-category-stairs.jpg';
import fence from '../assets/fiks-hjem-category-fence.jpg';
import garage from '../assets/fiks-hjem-category-garage.jpg';
import bath from '../assets/fiks-hjem-category-bathroom.jpg';
import kitchen from '../assets/fiks-hjem-category-kitchen.jpg';
import paint from '../assets/fiks-hjem-category-paint.jpg';

/* =====================================================================
   FIKS HJEM – moderne skall (v14)
   Alle skjermer fra designskissen, og alle knapper virker:
   1 Hjem · 2 Skann og mål · 3 Resultat (2D/3D/4D/AR, før/etter)
   3 Bygg steg for steg · 4 4D byggeforløp · 5 Materialer og verktøy
   6 Korte filmer · 7 AR-visning · 8 Ferdig · 9 Mine prosjekter
   Prosjekter og handleliste lagres lokalt (fungerer uten internett).
   «Byggemoduler» åpner den fulle kalkulatoren (TamerFixApp).
   ===================================================================== */

import { TerrasseManual, terrasseBokser, terrasseDeler, terrasseGeo } from './terrasseManual.jsx';
import { VeggManual, veggBokser, veggDeler, veggGeo, veggSynlig } from './veggManual.jsx';
import { GulvManual, gulvBokser, gulvDeler, gulvGeo, gulvSynlig } from './gulvManual.jsx';

const FullApp = lazy(() => import('./TamerFixApp.jsx'));

const C = { navy: '#061b2d', navy2: '#0b2941', ink: '#10202e', gold: '#f7b83f', muted: '#8aa0b3', ok: '#3fbf6f', red: '#e25b4b' };
const FILM_SEK = 40;

/* ---------- lagring (feiler stille hvis lagring er full/blokkert) ---------- */
const lese = (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } };
const skrive = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch { return false; } };

/* Byggemoduler (TamerFixApp) lagret før bare i minnet utenfor Claude-miljøet — alt forsvant når appen ble lukket.
   Her får den samme lokale lagring som resten av appen (nøkler med prefiks «fh_tf_»). Fungerer ikke lagring,
   settes ingenting, og modulene faller tilbake til minnet som før. */
const TF = 'fh_tf_';
try {
  if (typeof window !== 'undefined' && !window.TAMERFIX_STORAGE && !window.storage && window.localStorage) {
    window.TAMERFIX_STORAGE = {
      async get(k) { const v = localStorage.getItem(TF + k); if (v === null) throw new Error('not found'); return { key: k, value: v }; },
      async set(k, v) { localStorage.setItem(TF + k, v); return { key: k, value: v }; },
      async delete(k) { localStorage.removeItem(TF + k); return { key: k, deleted: true }; },
      async list() { return { keys: Object.keys(localStorage).filter((x) => x.startsWith(TF)).map((x) => x.slice(TF.length)) }; },
    };
  }
} catch { /* lagring blokkert — minnet brukes */ }
function useLagret(k, d) {
  const [v, setV] = useState(() => lese(k, d));
  const [ok, setOk] = useState(true);
  useEffect(() => { setOk(skrive(k, v)); }, [k, v]);
  return [v, setV, ok];
}
const kr = (n) => Math.round(n).toLocaleString('nb-NO') + ' kr';
const dato = (t) => new Date(t).toLocaleDateString('nb-NO', { month: 'short', year: 'numeric' });
// Vegg måles i lengde × høyde; alt annet i bredde × lengde (gulvflate).
const malTekst = (p) => (TYPER[p.type]?.form === 'vegg'
  ? `${p.mal.b} m lang × ${p.mal.h} m høy = ${(p.mal.b * p.mal.h).toFixed(1)} m² vegg`
  : `${p.mal.b} × ${p.mal.l} m = ${(p.mal.b * p.mal.l).toFixed(1)} m²`);

/* ---------- prosjekttyper: steg, materialer og verktøy ---------- */
const S = (tittel, uke, sjekk, tips) => ({ tittel, uke, sjekk, tips });
const TYPER = {
  terrasse: {
    navn: 'Terrasse', img: deck, form: 'terrasse', mal: { b: 4.2, l: 3.6, h: 0.5 },
    steg: [
      S('Forbered og merk', 1, ['Sett plugger i hjørnene', 'Sjekk at hjørnene er rette', 'Fjern gress og legg duk'], 'Kryssmål diagonalene – like lange betyr rett vinkel.'),
      S('Fundament', 1, ['Merk fundamentpunktene', 'Grav og støp fundament', 'Sett stolpesko i lodd'], 'Fundament under telefri dybde der grunnen er telefarlig.'),
      S('Bjelkelag', 2, ['Stolper og dragere', 'Legg bjelkene c/c 60', 'Fest bjelkene', 'Kontroller vater'], 'Dimensjonene er valgt fra den verifiserte bjelketabellen.'),
      S('Terrassebord', 2, ['Legg første bord', 'Skru fast bordene', 'Forskyv skjøtene', 'Kapp endene til slutt'], 'Legg kjerneveden opp for mindre oppsprekking.'),
      S('Rekkverk', 3, ['Rekkverksstolper', 'Håndlist 100 cm over gulvet', 'Spiler – maks 10 cm åpning'], 'Rekkverk kreves når fallhøyden er 0,5 m eller mer (TEK17 §12-11).'),
      S('Trapp og ferdig', 4, ['Trapp', 'Beis eller olje', 'Sluttkontroll'], 'Vent 4–8 uker før første behandling av nytt impregnert.'),
    ],
    materialer: (mal) => {
      const g = terrasseGeo(mal);
      const bordLm = g.nBord * g.b * 1.1;
      return [
        ['🪵', 'Terrassebord', '28 × 120 mm', Math.ceil(bordLm / 4.8), 'stk à 4,8 m', 4.8 * 26],
        ['🪵', 'Bjelke', g.bjelkeDim ? g.bjelkeDim.replace('x', ' × ') + ' mm' : 'se fagperson', Math.ceil((g.nBj * g.l) / 4.8), 'stk à 4,8 m', 4.8 * 42],
        ['🪵', 'Drager', '48 × 198 mm', Math.ceil((g.nDr * g.b * 1.05) / 4.8), 'stk à 4,8 m', 4.8 * 62],
        ['🔩', 'Stolpesko', 'justerbar', g.punkter, 'stk', 95],
        ...(g.utenStolpe ? [] : [['🪵', 'Stolpe', '98 × 98 mm', g.punkter, `stk à ${Math.round(g.stolpeH * 100)} cm`, 45]]),
        ['🔩', 'Terrasseskruer', '5 × 70 mm', Math.ceil((g.nBord * g.nBj * 2 * 1.05) / 250), 'pk à 250', 349],
        ['🔩', 'Vinkelbeslag', 'bjelke–drager', g.nBj * g.nDr * 2, 'stk', 12],
        ...(g.rekkverk ? [['🧱', 'Rekkverk', 'komplett', Math.ceil(g.b + 2 * g.l), 'lm', 450]] : []),
      ];
    },
    verktoy: ['Drill/skrutrekker', 'Kappsag', 'Vater (1,2 m)', 'Målebånd', 'Snor og merkespray', 'Spade', 'Vinkel'],
  },
  bad: {
    navn: 'Bad', img: bath, form: 'rom', mal: { b: 2.2, l: 1.8, h: 2.4 },
    steg: [
      S('Riving og kontroll', 1, ['Steng vannet', 'Riv gammelt', 'Sjekk underlaget', 'Fotodokumenter'], 'Våtrom: rør og el skal gjøres av fagfolk.'),
      S('Rør og el (fagfolk)', 1, ['Rørlegger: nye rør', 'Elektriker: punkter', 'Sluk på plass', 'Samsvarserklæring'], 'Ta vare på samsvarserklæringer – viktig ved salg.'),
      S('Fall og membran', 2, ['Støp fall mot sluk', 'Prim underlaget', 'Membran i 2 strøk', 'Mansjett rundt rør'], 'Fall 1:50 mot sluk innenfor dusjsonen.'),
      S('Flis', 3, ['Sett ut midtlinje', 'Flis vegg', 'Flis gulv', 'Fug'], 'Start fra midten for jevne kantfliser.'),
      S('Innredning', 4, ['Toalett', 'Servant', 'Dusjvegg', 'Silikon'], 'Silikon i alle hjørner – aldri fugemasse.'),
      S('Sluttkontroll', 4, ['Tetthetstest', 'Sjekk fall', 'Rengjør', 'Lagre dokumentasjon'], ''),
    ],
    materialer: ({ b, l, h }) => {
      const gulv = b * l, vegg = 2 * (b + l) * h;
      return [
        ['🟦', 'Membransett', 'våtrom', Math.ceil((gulv + vegg) / 10), 'sett (10 m²)', 1490],
        ['⬜', 'Gulvflis', '20 × 20', Math.ceil(gulv * 1.1 * 10) / 10, 'm²', 450],
        ['⬜', 'Veggflis', '30 × 60', Math.ceil(vegg * 1.1 * 10) / 10, 'm²', 390],
        ['🧱', 'Fliselim', '15 kg', Math.ceil((gulv + vegg) / 4), 'sekk', 289],
        ['🧴', 'Fugemasse', '5 kg', Math.ceil((gulv + vegg) / 12), 'sekk', 199],
        ['🕳️', 'Sluk', 'komplett', 1, 'stk', 1890],
      ];
    },
    verktoy: ['Flisekutter', 'Tannsparkel', 'Vater', 'Blandevisp', 'Fugebrett', 'Membranrull'],
  },
  kjokken: {
    navn: 'Kjøkken', img: kitchen, form: 'rom', mal: { b: 3.6, l: 2.8, h: 2.4 },
    steg: [
      S('Planlegg og mål', 1, ['Mål rommet', 'Tegn plasseringen', 'Bestill skap', 'Avtal elektriker'], ''),
      S('Riving', 1, ['Steng vann og strøm', 'Demonter gammelt', 'Kast avfall', 'Sjekk veggene'], ''),
      S('Rør og el (fagfolk)', 2, ['Flytte vann', 'Nye stikk', 'Lyspunkt', 'Samsvarserklæring'], ''),
      S('Skap og benk', 3, ['Underskap i vater', 'Overskap på skinne', 'Benkeplate', 'Utskjæringer'], 'Start i hjørnet og jobb utover.'),
      S('Hvitevarer og fronter', 4, ['Hvitevarer', 'Fronter og håndtak', 'Juster dørene', 'Sokkel'], ''),
      S('Ferdig', 4, ['Silikon', 'Rengjør', 'Test alt', 'Sluttkontroll'], ''),
    ],
    materialer: ({ b }) => [
      ['🗄️', 'Underskap', '60 cm', Math.ceil(b / 0.6), 'stk', 2400],
      ['🗄️', 'Overskap', '60 cm', Math.ceil(b / 0.6), 'stk', 1600],
      ['🪨', 'Benkeplate', 'laminat', Math.ceil(b * 10) / 10, 'lm', 1200],
      ['🔩', 'Skruer og beslag', 'sett', 1, 'sett', 390],
    ],
    verktoy: ['Drill', 'Vater', 'Stikksag', 'Målebånd', 'Skrutvinger'],
  },
  gulv: {
    // Flytende klikkgulv (laminat/parkett). b = rommets bredde (på tvers av bordene), l = lengde, bord = bordbredde fra pakken.
    navn: 'Gulv', img: floor, form: 'gulv', mal: { b: 4, l: 3.5, h: 2.4, bord: 0.19 },
    steg: [
      S('Forbered', 1, ['La gulvet venne seg til rommet', 'Tøm rommet og fjern listene', 'Sjekk at gulvet er plant'], 'Pakkene skal ligge uåpnet i rommet i 48 timer.'),
      S('Fuktsperre og underlag', 1, ['Fuktsperre på betong', 'Legg underlaget'], 'På betong og gulvvarme: alltid 0,2 mm fuktsperre.'),
      S('Planlegg radene', 1, ['Velg retning', 'Regn ut første og siste rad'], 'Siste rad skal ikke bli smalere enn 5 cm.'),
      S('Legg gulvet', 1, ['Første rad med kiler', 'Klikk bordene sammen', 'Forskyv skjøtene min. 30 cm', 'Siste rad'], '8–10 mm luft mot alle vegger.'),
      S('Lister og ferdig', 1, ['Rundt rør og døråpninger', 'Fjern kilene og sett på lister', 'Sluttkontroll'], 'Listene festes i veggen – ikke i gulvet.'),
    ],
    materialer: (mal) => {
      const g = gulvGeo(mal); const a = Math.ceil(g.areal * 10) / 10;
      // Ingen priser og ingen påfunnet svinnprosent: legg til svinn slik pakken anbefaler.
      return [
        ['🟫', 'Laminat/parkett (klikk)', `${a} m² netto – legg til svinn som pakken anbefaler`, a, 'm²', 0],
        ['🧻', 'Parkettunderlag', 'følg anvisningen på rullen', a, 'm²', 0],
        ['🟦', 'Fuktsperre 0,2 mm (betong/gulvvarme)', 'pluss 20 cm omlegg per skjøt', a, 'm²', 0],
        ['📏', 'Gulvlist', 'minus døråpninger', Math.ceil(g.listeLm * 10) / 10, 'lm', 0],
        ['🔺', 'Kiler 8–10 mm', 'pose', 1, 'stk', 0],
      ];
    },
    verktoy: ['Sag (kapp og på langs)', 'Slagkloss', 'Kiler', 'Målebånd', 'Vinkel', 'Rettholt 2 m', 'Blyant'],
  },
  maling: {
    navn: 'Maling', img: paint, form: 'rom', mal: { b: 4, l: 3.5, h: 2.4 },
    steg: [
      S('Forbered', 1, ['Dekk gulv og møbler', 'Sparkle hull', 'Slip', 'Vask veggene'], ''),
      S('Grunning', 1, ['Tape kanter', 'Grunn sparklede flater', 'La tørke', 'Kontroller'], ''),
      S('Maling', 1, ['Skjær inn hjørner', '1. strøk', '2. strøk', 'Fjern tapen mens det er vått'], ''),
      S('Ferdig', 1, ['Rydd', 'Vask verktøyet', 'Sjekk i dagslys', 'Flekkmal'], ''),
    ],
    materialer: ({ b, l, h }) => [
      ['🪣', 'Veggmaling', '2 strøk', Math.ceil((2 * (b + l) * h * 2) / 8), 'liter', 120],
      ['🧽', 'Sparkel', '', 1, 'boks', 129],
      ['📦', 'Maskeringstape', '', 2, 'rull', 59],
    ],
    verktoy: ['Rull og brett', 'Pensel', 'Sparkel', 'Slipekloss', 'Stige'],
  },
  garasje: {
    navn: 'Garasje', img: garage, form: 'rom', mal: { b: 6, l: 4, h: 2.6 },
    steg: [
      S('Søknad og plan', 1, ['Sjekk reguleringsplan', 'Søknad eller unntak', 'Nabovarsel ved behov', 'Tegninger'], 'Frittliggende garasje under 50 m² kan ofte bygges uten søknad – sjekk alltid kommunen.'),
      S('Grunnarbeid', 2, ['Grav ut', 'Drenering', 'Pukk og komprimer', 'Såle/plate'], ''),
      S('Vegger', 3, ['Svill', 'Stendere c/c 600', 'Vindsperre', 'Kledning'], ''),
      S('Tak', 4, ['Takstoler', 'Undertak', 'Lekter', 'Tekking'], ''),
      S('Port og ferdig', 5, ['Port', 'Dør', 'Beslag', 'Sluttkontroll'], ''),
    ],
    materialer: ({ b, l, h }) => [
      ['🪵', 'Stendere', '48 × 98', Math.ceil((2 * (b + l)) / 0.6) + 8, 'stk', 110],
      ['🪵', 'Kledning', '', Math.ceil(2 * (b + l) * h * 1.15), 'm²', 190],
      ['🏠', 'Takstoler', '', Math.ceil(b / 0.6) + 1, 'stk', 1450],
      ['🚪', 'Garasjeport', '', 1, 'stk', 14900],
    ],
    verktoy: ['Spikerpistol', 'Kappsag', 'Vater', 'Laser', 'Stillas'],
  },
  vegg: {
    // Ny, ikke-bærende innervegg av tre med gips på begge sider. b = veggens lengde, h = takhøyde, l = bare gulvflate i 3D.
    navn: 'Vegg', img: wall, form: 'vegg', mal: { b: 3, l: 1.2, h: 2.4 },
    steg: [
      S('Mål og merk', 1, ['Merk veggen på gulvet', 'Overfør streken til taket'], 'Lodd fra taket til gulvstreken i begge ender – da står veggen rett.'),
      S('Sviller', 1, ['Kapp svillene', 'Merk stenderne c/c 60', 'Fest svillene'], 'Merk bunn- og toppsvill samtidig, fra samme ende.'),
      S('Stendere', 1, ['Kapp stenderne', 'Sett inn stenderne', 'Sjekk lodd og avstand'], 'c/c 60 cm gjør at hver plateskjøt havner midt på en stender (Gyproc).'),
      S('Gips – første side', 2, ['Første plate', 'Skru platen fast', 'Resten av platene'], 'Skruer: 20 cm langs kantene, 30 cm inne på platen (Gyproc).'),
      S('Strøm og isolasjon', 2, ['Strøm og rør i veggen', 'Isolasjon (for lyd)'], 'Alt som skal inn i veggen, må inn før den lukkes.'),
      S('Andre side og ferdig', 2, ['Andre siden', 'Sparkle skjøter og skruer', 'Sluttkontroll'], ''),
    ],
    materialer: (mal) => {
      const g = veggGeo(mal);
      // Ingen priser: vi har ikke verifiserte priser for vegg. Pris 0 = ingen pris vises.
      return [
        ['🪵', 'Svill', '48 × 98 mm', Math.ceil(g.svillLm * 10) / 10, 'lm', 0],
        ['🪵', 'Stender', `48 × 98 mm, ${Math.round(g.stenderL * 100)} cm`, g.nSt, 'stk', 0],
        ['⬜', 'Gipsplate', '12,5 mm, 1200 mm bred', g.nPlater, 'stk', 0],
        ['🔩', 'Gipsskruer', 'min. 3,9 × 29 mm', g.nSkruer, 'stk (ca.)', 0],
        ['🟨', 'Mineralull (valgfritt, lyd)', 'fyll hele hulrommet', Math.ceil(g.L * g.H * 10) / 10, 'm²', 0],
      ];
    },
    verktoy: ['Drill/skrutrekker', 'Kappsag', 'Vater (1,2 m)', 'Lodd eller krysslaser', 'Målebånd', 'Vinkel', 'Gipskniv', 'Sparkel'],
  },
  tak: { navn: 'Tak', img: roof, form: 'rom', mal: { b: 8, l: 6, h: 2.4 } },
  trapp: { navn: 'Trapp', img: stairs, form: 'terrasse', mal: { b: 1.2, l: 2, h: 0.6 } },
  gjerde: { navn: 'Gjerde', img: fence, form: 'terrasse', mal: { b: 10, l: 0.3, h: 1.2 } },
};
// Typer uten egne steg får en felles mal; nøyaktig beregning ligger i Byggemoduler.
for (const t of Object.values(TYPER)) {
  if (!t.steg) {
    t.steg = [
      S('Planlegg og mål', 1, ['Mål opp', 'Sjekk regler', 'Lag materialliste', 'Kjøp inn'], 'Nøyaktig beregning: åpne Byggemoduler.'),
      S('Forbered', 1, ['Rydd', 'Merk opp', 'Verneutstyr', 'Verktøy klart'], ''),
      S('Bygg', 2, ['Konstruksjon', 'Innfesting', 'Kontroller vater', 'Overflate'], ''),
      S('Ferdig', 3, ['Detaljer', 'Rydd', 'Dokumenter', 'Sluttkontroll'], ''),
    ];
    t.materialer = ({ b, l }) => [['📐', 'Nøyaktig liste i Byggemoduler', `${b} × ${l} m`, 1, 'beregning', 0]];
    t.verktoy = ['Målebånd', 'Vater', 'Drill', 'Sag'];
  }
}

/* ---------- 3D: isometrisk SVG uten WebGL (virker i alle nettlesere og iOS) ---------- */
function scene(p, fremdrift = 1) {
  const t = TYPER[p.type]; const { b, l, h } = p.mal; const bx = [];
  const n = t.steg.length; const fase = fremdrift * n; // antall steg som er «bygd»
  const med = (i) => fase > i;
  if (t.form === 'terrasse') {
    const deler = terrasseDeler(p); const vis = new Set();
    deler.forEach((ds, i) => { if (med(i)) ds.forEach((x) => x.ny.forEach((tg) => vis.add(tg))); });
    if (vis.has('bord') || vis.has('bord1')) { vis.delete('snor'); vis.delete('punkt'); }
    if (!vis.size) vis.add('snor');
    bx.push(...terrasseBokser(p).filter((q) => vis.has(q.tag)));
  } else if (t.form === 'gulv') {
    const deler = gulvDeler(p); const n2 = Math.min(deler.length, Math.ceil(fase));
    const vis = gulvSynlig(deler, n2, 0);
    bx.push(...gulvBokser(p).filter((q) => vis.has(q.tag)));
  } else if (t.form === 'vegg') {
    const deler = veggDeler(p); const n2 = Math.min(deler.length, Math.ceil(fase));
    const vis = veggSynlig(deler, n2, 0);
    if (!vis.size) vis.add('linje');
    bx.push(...veggBokser(p).filter((q) => vis.has(q.tag)));
  } else {
    bx.push({ x: 0, y: 0, z: -0.05, w: b, d: l, h: 0.05, c: '#cfd6dc' });
    if (med(1)) { bx.push({ x: -0.1, y: 0, z: 0, w: 0.1, d: l, h, c: '#e8e4dc' }); bx.push({ x: -0.1, y: -0.1, z: 0, w: b + 0.1, d: 0.1, h, c: '#efebe3' }); }
    if (med(2)) bx.push({ x: 0, y: 0, z: 0, w: b, d: l, h: 0.02, c: p.type === 'bad' ? '#9fb3c1' : '#b98c52' });
    if (med(3)) bx.push({ x: 0, y: 0, z: 0, w: Math.min(b, 2.4), d: 0.6, h: 0.9, c: '#f2f2f2' });
    if (med(4)) bx.push({ x: b - 0.7, y: 0, z: 0, w: 0.6, d: 0.6, h: p.type === 'bad' ? 0.8 : 2, c: '#d7dde2' });
  }
  return bx;
}
const shade = (hex, f) => { const n = parseInt(hex.slice(1), 16); return `rgb(${(((n >> 16) & 255) * f) | 0},${(((n >> 8) & 255) * f) | 0},${((n & 255) * f) | 0})`; };
/* Byggerekkefølgen for delene: det som ligger OPPÅ eller FORAN tegnes etter det det ligger på.
   Samme knep som Tegning3D i Byggemoduler: ren dybdesortering bommer når en lang bjelke krysser
   en kort del, og da ser platene ut til å ligge inni bjelkene. Ukjente deler får lag 0 (ren dybde). */
const LAG = {
  snor: 0, punkt: 0, fundament: 1, sko: 2, stolpe: 3, drager: 4, bjelke: 5, bord1: 6, bord: 6, trapp: 6, stender: 7, spiler: 7, list: 8,
  linje: 0, plate1: 0, plateA: 0, bunn: 1, topp: 1, isolasjon: 1, plateB: 3,
  rom: 0, fukt: 1, underlag: 2, rad1: 3, rader: 3, siste: 3, kiler: 4,
};
const LAG_FORM = { gulv: { list: 4, stender: 7 }, vegg: { stender: 1 } };
const STREK = '#1C2321';

/* Mål i 3D som på en byggetegning: linje, tverrstrek i endene og tallet på midten. */
function malLinjer(p) {
  const f = TYPER[p.type].form; const { b, l, h } = p.mal; const r = (v) => String(Math.round(v * 100) / 100).replace('.', ',') + ' m';
  if (f === 'vegg') return [{ fra: [0, l / 2 + 0.35, 0], til: [b, l / 2 + 0.35, 0], t: r(b) }, { fra: [b + 0.3, l / 2, 0], til: [b + 0.3, l / 2, h], t: r(h) }];
  const m = [{ fra: [0, l + 0.45, 0], til: [b, l + 0.45, 0], t: r(b) }, { fra: [b + 0.45, 0, 0], til: [b + 0.45, l, 0], t: r(l) }];
  // Høyden måles i det frie hjørnet til høyre, så den verken havner bak konstruksjonen eller oppå de andre målene.
  if (f === 'terrasse' && h >= 0.2) m.push({ fra: [b + 0.45, -0.3, 0], til: [b + 0.45, -0.3, h], t: r(h) });
  return m;
}

function Iso({ p, fremdrift = 1, vinkel: v0, hoyde = 260, sol = true, bokser, interaktiv = false, maal }) {
  const form = TYPER[p.type].form;
  // Vegg sees forfra og litt på skrå (-30°); flater (terrasse, rom) ovenfra på skrå (35°).
  const [dra, setDra] = useState({ a: 0, t: 0.5, z: 1 }); const peker = useRef(null);
  const vinkel = (v0 ?? (form === 'vegg' ? -30 : 35)) + dra.a;
  const tilt = dra.t, kz = Math.sqrt(1 - tilt * tilt) / 0.866;
  const bx = bokser || scene(p, fremdrift);
  const a = (vinkel * Math.PI) / 180, ca = Math.cos(a), sa = Math.sin(a);
  const cx = p.mal.b / 2, cy = p.mal.l / 2;
  const pr = (x, y, z) => { const X = x - cx, Y = y - cy; const xr = X * ca - Y * sa, yr = X * sa + Y * ca; return [(xr - yr) * 0.866, (xr + yr) * tilt - z * kz, xr + yr + z * 0.01]; };
  const lagFor = (q) => (q.fall && (q.dz || 0) > 0.001 ? 99 : 0) + (q.foran ? 50 : 0) - (q.bak ? 50 : 0) + ((LAG_FORM[form] || {})[q.tag] ?? LAG[q.tag] ?? 0);
  const faces = [];
  for (const q of bx) {
    const z0 = q.z + (q.dz || 0);
    const X = [q.x, q.x + q.w], Y = [q.y, q.y + q.d], Z = [z0, z0 + q.h];
    const P = (i, j, k) => pr(X[i], Y[j], Z[k]);
    const F = [
      [[P(0, 0, 1), P(1, 0, 1), P(1, 1, 1), P(0, 1, 1)], 1.12], [[P(0, 0, 0), P(1, 0, 0), P(1, 1, 0), P(0, 1, 0)], 0.6],
      [[P(0, 0, 0), P(1, 0, 0), P(1, 0, 1), P(0, 0, 1)], 0.72], [[P(0, 1, 0), P(1, 1, 0), P(1, 1, 1), P(0, 1, 1)], 0.72],
      [[P(0, 0, 0), P(0, 1, 0), P(0, 1, 1), P(0, 0, 1)], 0.86], [[P(1, 0, 0), P(1, 1, 0), P(1, 1, 1), P(1, 0, 1)], 0.86],
    ];
    const lag = lagFor(q);
    for (const [pts, f] of F) faces.push({ pts, f, c: q.c, lag, dz: pts.reduce((s2, v) => s2 + v[2], 0) / 4 });
  }
  faces.sort((u, v) => u.lag - v.lag || u.dz - v.dz);
  // bakken tegnes alltid først (ikke med i dybdesorteringen)
  const m = 0.6, trapp = form === 'terrasse' ? 1.2 : 0;
  const bakke = [pr(-m, -m, 0), pr(p.mal.b + m, -m, 0), pr(p.mal.b + m, p.mal.l + m + trapp, 0), pr(-m, p.mal.l + m + trapp, 0)];
  const mal = (maal ?? hoyde >= 150) ? malLinjer(p) : [];
  let minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9;
  const faste = bx.flatMap((q) => { const o = []; for (const x of [q.x, q.x + q.w]) for (const y of [q.y, q.y + q.d]) for (const z of [q.z, q.z + q.h + (q.fall ? 1.2 : 0)]) o.push(pr(x, y, z)); return o; });
  for (const pts of [faste, bakke, mal.flatMap((mm) => [pr(...mm.fra), pr(...mm.til)])]) for (const [x, y] of pts) { minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y); }
  const pad = 0.4; const W0 = maxX - minX + 2 * pad, H0 = maxY - minY + 2 * pad; const W = W0 / dra.z, H = H0 / dra.z;
  const mx = (minX + maxX) / 2, my = (minY + maxY) / 2; const span = Math.max(W, H);
  const sw = hoyde < 100 ? span * 0.0012 : span * 0.0022;
  const ned = (e) => { if (!interaktiv) return; peker.current = { x: e.clientX, y: e.clientY, ...dra }; e.currentTarget.setPointerCapture?.(e.pointerId); };
  const flytt = (e) => { const d = peker.current; if (!d) return; setDra({ a: d.a + (e.clientX - d.x) * 0.5, t: Math.max(0.25, Math.min(0.85, d.t + (e.clientY - d.y) * 0.004)), z: d.z }); };
  const slipp = () => { peker.current = null; };
  const kn = { width: 34, height: 34, borderRadius: 10, border: '1px solid #1C232133', background: '#ffffffd9', color: STREK, fontWeight: 900, fontSize: 18, lineHeight: 1, padding: 0 };
  const svg = (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox={`${mx - W / 2} ${my - H / 2} ${W} ${H}`} style={{ width: '100%', height: hoyde, display: 'block', touchAction: interaktiv ? 'none' : 'auto', cursor: interaktiv ? 'grab' : 'default' }}
      onPointerDown={ned} onPointerMove={flytt} onPointerUp={slipp} onPointerCancel={slipp}>
      <polygon points={bakke.map((v) => v[0] + ',' + v[1]).join(' ')} fill={form === 'terrasse' ? '#9cc27a' : '#dfe3dc'} opacity={0.7} />
      {faces.map((fa, i) => <polygon key={i} points={fa.pts.map((v) => v[0] + ',' + v[1]).join(' ')} fill={shade(fa.c, sol ? fa.f : 0.9)} stroke={STREK} strokeOpacity={0.8} strokeWidth={sw} strokeLinejoin="round" />)}
      {mal.map((mm, i) => {
        const A = pr(...mm.fra), B = pr(...mm.til); const dx = B[0] - A[0], dy = B[1] - A[1]; const L = Math.hypot(dx, dy) || 1;
        const nx = (-dy / L) * span * 0.014, ny = (dx / L) * span * 0.014; const lw = span * 0.0035;
        return (<g key={'m' + i} stroke="#4A544E" strokeWidth={lw}>
          <line x1={A[0]} y1={A[1]} x2={B[0]} y2={B[1]} /><line x1={A[0] - nx} y1={A[1] - ny} x2={A[0] + nx} y2={A[1] + ny} /><line x1={B[0] - nx} y1={B[1] - ny} x2={B[0] + nx} y2={B[1] + ny} />
          <text x={(A[0] + B[0]) / 2 + nx * 2.2} y={(A[1] + B[1]) / 2 + ny * 2.2} fontSize={span * 0.045} fontWeight={700} fill="#4A544E" stroke="#FBFBF9" strokeWidth={span * 0.008} paintOrder="stroke" textAnchor="middle" dominantBaseline="middle">{mm.t}</text>
        </g>);
      })}
    </svg>
  );
  if (!interaktiv) return svg;
  const endret = dra.a !== 0 || dra.t !== 0.5 || dra.z !== 1;
  return (
    <div style={{ position: 'relative' }}>
      {svg}
      <div style={{ position: 'absolute', right: 8, bottom: 8, display: 'flex', gap: 6 }}>
        <button aria-label="Nærmere" style={kn} onClick={() => setDra((d) => ({ ...d, z: Math.min(5, d.z * 1.35) }))}>+</button>
        <button aria-label="Lenger unna" style={kn} onClick={() => setDra((d) => ({ ...d, z: Math.max(0.6, d.z / 1.35) }))}>−</button>
        {endret && <button aria-label="Rett opp" style={{ ...kn, fontSize: 15 }} onClick={() => setDra({ a: 0, t: 0.5, z: 1 })}>⟲</button>}
      </div>
      <div style={{ position: 'absolute', left: 8, bottom: 10, fontSize: 11, color: '#4A544E', background: '#ffffffc0', borderRadius: 6, padding: '2px 6px' }}>Dra for å snu</div>
    </div>
  );
}
function Plan2D({ p }) {
  if (TYPER[p.type].form === 'vegg') {
    // Vegg: oppriss forfra med stenderne c/c 60 (samme geometri som guiden).
    const g = veggGeo(p.mal); const k = Math.min(260 / g.L, 180 / g.H);
    return (
      <svg viewBox={`-78 -34 ${g.L * k + 118} ${g.H * k + 76}`} style={{ width: '100%', height: 260, background: 'repeating-linear-gradient(0deg,#fff,#fff 19px,#dce7ec 20px)', display: 'block' }}>
        <rect x={0} y={0} width={g.L * k} height={g.H * k} fill="#f3efe6" stroke="#384a58" strokeWidth={3} />
        {g.stendere.map((c, i) => <rect key={i} x={(c - 0.024) * k} y={0} width={Math.max(2, 0.048 * k)} height={g.H * k} fill="#d0a878" stroke="#8a6a44" strokeWidth={1} />)}
        <text x={(g.L * k) / 2} y={-12} textAnchor="middle" fontWeight={800} fontSize={16}>{g.L.toFixed(2)} m</text>
        <text x={-10} y={(g.H * k) / 2} textAnchor="end" fontWeight={800} fontSize={16}>{g.H.toFixed(2)} m</text>
        <text x={(g.L * k) / 2} y={g.H * k + 26} textAnchor="middle" fontSize={13} fill="#607080">{g.nSt} stendere c/c 600 · {g.nPlater} gipsplater</text>
      </svg>
    );
  }
  const { b, l } = p.mal; const s = 220 / Math.max(b, l);
  return (
    <svg viewBox={`-60 -40 ${b * s + 110} ${l * s + 80}`} style={{ width: '100%', height: 260, background: 'repeating-linear-gradient(0deg,#fff,#fff 19px,#dce7ec 20px)', display: 'block' }}>
      <rect x={0} y={0} width={b * s} height={l * s} fill="#e8c28e" stroke="#384a58" strokeWidth={3} />
      {TYPER[p.type].form === 'terrasse' && Array.from({ length: Math.ceil(b / 0.6) + 1 }, (_, i) => <line key={i} x1={Math.min(i * 0.6, b) * s} y1={0} x2={Math.min(i * 0.6, b) * s} y2={l * s} stroke="#8a6a44" strokeDasharray="4 4" />)}
      <text x={(b * s) / 2} y={-14} textAnchor="middle" fontWeight={800} fontSize={16}>{b.toFixed(2)} m</text>
      <text x={-10} y={(l * s) / 2} textAnchor="end" fontWeight={800} fontSize={16}>{l.toFixed(2)} m</text>
      <text x={(b * s) / 2} y={l * s + 28} textAnchor="middle" fontSize={13} fill="#607080">{(b * l).toFixed(1)} m²{TYPER[p.type].form === 'terrasse' ? ' · bjelker c/c 600 (stiplet)' : ''}</text>
    </svg>
  );
}

/* ---------- felles UI ---------- */
const st = {
  app: { minHeight: '100vh', background: '#020d17', fontFamily: 'Inter,system-ui,sans-serif', color: 'white' },
  phone: { maxWidth: 430, minHeight: '100vh', margin: '0 auto', background: C.navy, position: 'relative', paddingBottom: 84 },
  card: { background: C.navy2, border: '1px solid #ffffff1c', borderRadius: 14, padding: 12 },
  btn: { border: 0, borderRadius: 12, padding: '13px 15px', fontWeight: 800, cursor: 'pointer', fontSize: 15, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6 },
  gold: { background: C.gold, color: C.ink },
  ghost: { background: '#ffffff14', color: 'white', border: '1px solid #ffffff30' },
  pad: { padding: 14 },
  sky: { background: 'linear-gradient(#bfe0f5,#eaf4ea)', borderRadius: 12 },
};
const Knapp = ({ gull, stil, ...r }) => <button {...r} style={{ ...st.btn, ...(gull ? st.gold : st.ghost), ...stil }} />;
function Topp({ tittel, tilbake, hoyre }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '14px 12px 10px', position: 'sticky', top: 0, background: C.navy, zIndex: 5 }}>
      <div style={{ minWidth: 32 }}>{tilbake && <button aria-label="Tilbake" onClick={tilbake} style={{ background: 'none', border: 0, color: 'white', padding: 4 }}><ChevronLeft /></button>}</div>
      <div style={{ flex: 1, fontWeight: 800, fontSize: 18, textAlign: 'center' }}>{tittel}</div>
      <div style={{ minWidth: 32 }}>{hoyre}</div>
    </div>
  );
}
function Faner({ valg, verdi, sett }) {
  return (
    <div style={{ display: 'flex', background: '#ffffff10', borderRadius: 30, padding: 4, gap: 4 }}>
      {valg.map((v) => <button key={v} onClick={() => sett(v)} style={{ flex: 1, border: 0, borderRadius: 30, padding: '8px 4px', fontWeight: 800, background: verdi === v ? C.gold : 'transparent', color: verdi === v ? C.ink : 'white' }}>{v}</button>)}
    </div>
  );
}
function Bunn({ go, aktiv }) {
  const faner = [[Home, 'Hjem', 'home'], [Compass, 'Utforsk', 'utforsk'], [FolderKanban, 'Mine prosjekt', 'prosjekter'], [User, 'Profil', 'profil']];
  return (
    <div style={{ position: 'fixed', left: '50%', transform: 'translateX(-50%)', bottom: 0, maxWidth: 430, width: '100%', minHeight: 66, background: C.navy, display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', zIndex: 20, borderTop: '1px solid #ffffff22', paddingBottom: 'env(safe-area-inset-bottom)' }}>
      {faner.map(([I, l, v]) => <button key={v} onClick={() => go(v)} style={{ background: 'none', border: 0, color: aktiv === v ? C.gold : 'white', fontSize: 11 }}><I size={20} /><div>{l}</div></button>)}
    </div>
  );
}

/* ---------- kamera ---------- */
function useKamera(aktiv) {
  const ref = useRef(null); const [feil, setFeil] = useState('');
  useEffect(() => {
    if (!aktiv) return undefined; let strom; let avbrutt = false; setFeil('');
    if (!navigator.mediaDevices?.getUserMedia) { setFeil('Kamera støttes ikke her.'); return undefined; }
    navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false })
      .then((s) => { if (avbrutt) { s.getTracks().forEach((t) => t.stop()); return; } strom = s; if (ref.current) { ref.current.srcObject = s; ref.current.play?.().catch(() => {}); } })
      .catch(() => setFeil('Fikk ikke tilgang til kameraet. Gi tillatelse, eller bruk «Manuell».'));
    return () => { avbrutt = true; strom?.getTracks().forEach((t) => t.stop()); };
  }, [aktiv]);
  const knips = (maks = 900) => {
    const v = ref.current; if (!v || !v.videoWidth) return null;
    const k = Math.min(1, maks / v.videoWidth); const c = document.createElement('canvas');
    c.width = v.videoWidth * k; c.height = v.videoHeight * k; c.getContext('2d').drawImage(v, 0, 0, c.width, c.height);
    return { c, url: c.toDataURL('image/jpeg', 0.72) };
  };
  return { ref, feil, knips };
}
const filTilBilde = (fil) => new Promise((ok) => {
  const r = new FileReader();
  r.onload = () => { const img = new Image(); img.onload = () => { const k = Math.min(1, 900 / img.width); const c = document.createElement('canvas'); c.width = img.width * k; c.height = img.height * k; c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); ok(c.toDataURL('image/jpeg', 0.72)); }; img.src = r.result; };
  r.readAsDataURL(fil);
});

/* =============================== SKJERMER =============================== */

function Hjem({ go, nyttProsjekt, aktivt }) {
  const [sok, setSok] = useState('');
  const treff = sok ? Object.entries(TYPER).filter(([, t]) => t.navn.toLowerCase().includes(sok.toLowerCase().trim())) : [];
  const fliser = [
    [Camera, 'Skann og mål', () => (aktivt ? go('skann') : go('utforsk'))],
    [Box, 'Byggemoduler', () => go('full')],
    [Hammer, 'Oppussing & rehabilitering', () => go('full', 'rehab')],
    [Wrench, 'Fagområde', () => go('fag')],
    [House, 'Boligen min', () => go('bolig')],
    [CalendarDays, 'Vedlikehold', () => go('vedlikehold')],
  ];
  return (
    <div style={st.pad}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, justifyContent: 'center', margin: '6px 0 14px' }}>
        <House size={34} color={C.gold} /><div style={{ fontFamily: 'Georgia,serif', fontSize: 30, fontWeight: 800 }}>Fiks <span style={{ color: C.gold }}>hjem</span></div>
      </div>
      <div style={{ ...st.card, display: 'flex', gap: 8, alignItems: 'center', borderRadius: 30, padding: '10px 14px' }}>
        <Search size={18} />
        <input value={sok} onChange={(e) => setSok(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && treff[0]) nyttProsjekt(treff[0][0]); }} placeholder="Hva skal du gjøre i dag?" style={{ flex: 1, background: 'none', border: 0, color: 'white', fontSize: 16, outline: 'none' }} />
      </div>
      {sok && <div style={{ ...st.card, marginTop: 6 }}>{treff.length ? treff.map(([id, t]) => <button key={id} onClick={() => nyttProsjekt(id)} style={{ display: 'block', width: '100%', textAlign: 'left', background: 'none', border: 0, color: 'white', padding: 8, fontWeight: 700 }}>+ Start prosjekt: {t.navn}</button>) : <div style={{ color: C.muted, padding: 6 }}>Ingen treff – prøv «terrasse», «bad» eller «gulv».</div>}</div>}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 8, marginTop: 12 }}>
        {fliser.map(([I, l, f]) => <button key={l} onClick={f} style={{ ...st.card, color: 'white', minHeight: 96, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6, fontSize: 12, fontWeight: 700 }}><I size={28} color={C.gold} />{l}</button>)}
      </div>
      <button onClick={() => go('filmer')} style={{ ...st.btn, ...st.gold, width: '100%', marginTop: 12, justifyContent: 'flex-start', gap: 12, textAlign: 'left' }}>
        <div style={{ width: 40, height: 40, borderRadius: 30, background: C.navy, display: 'grid', placeItems: 'center' }}><Play size={20} color={C.gold} /></div>
        <div style={{ flex: 1 }}><div style={{ fontSize: 16 }}>Vis meg hvordan</div><div style={{ fontSize: 11, fontWeight: 500 }}>Korte filmer som viser hele prosessen</div></div><ChevronRight />
      </button>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginTop: 8 }}>
        {[[Play, 'Slik gjør du', 'Tegnefilm: døråpning og terrasse', 'tegnefilm'], [Ruler, 'Fasade fra foto', 'Foto + dine mål = fasadetegning', 'fasade']].map(([I, t, u, side]) => (
          <button key={side} onClick={() => go('verktoy', side)} style={{ ...st.card, color: 'white', display: 'flex', gap: 10, alignItems: 'center', textAlign: 'left', padding: 12 }}>
            <I size={24} color={C.gold} style={{ flex: 'none' }} />
            <div><div style={{ fontWeight: 800, fontSize: 14 }}>{t}</div><div style={{ fontSize: 11, color: C.muted }}>{u}</div></div>
          </button>
        ))}
      </div>
      <div style={{ fontWeight: 800, margin: '16px 0 8px' }}>Populære prosjekter</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 6 }}>
        {['terrasse', 'bad', 'kjokken', 'garasje'].map((id) => <button key={id} onClick={() => nyttProsjekt(id)} style={{ height: 88, border: `2px solid ${id === 'terrasse' ? C.gold : 'transparent'}`, borderRadius: 10, background: `linear-gradient(#0000,#000a),url(${TYPER[id].img}) center/cover`, color: 'white', fontWeight: 800, fontSize: 12, display: 'flex', alignItems: 'end', justifyContent: 'center', paddingBottom: 6 }}>{TYPER[id].navn}</button>)}
      </div>
      {aktivt && <button onClick={() => go('steg')} style={{ ...st.card, width: '100%', marginTop: 14, color: 'white', display: 'flex', gap: 10, alignItems: 'center', textAlign: 'left' }}>
        <img src={aktivt.foto || TYPER[aktivt.type].img} alt="" style={{ width: 54, height: 40, objectFit: 'cover', borderRadius: 8 }} />
        <div style={{ flex: 1 }}><b>Fortsett: {aktivt.navn}</b><div style={{ fontSize: 12, color: C.muted }}>Steg {aktivt.steg + 1} av {TYPER[aktivt.type].steg.length}</div></div><ChevronRight />
      </button>}
    </div>
  );
}

function Utforsk({ go, nyttProsjekt, filter }) {
  const rom = ['bad', 'kjokken', 'gulv', 'maling', 'vegg'];
  const liste = Object.entries(TYPER).filter(([id]) => (filter === 'rom' ? rom.includes(id) : true));
  return (
    <>
      <Topp tittel={filter === 'rom' ? 'Oppussing & rehab' : 'Hva vil du bygge?'} tilbake={() => go('home')} />
      <div style={{ ...st.pad, display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gap: 10 }}>
        {liste.map(([id, t]) => <button key={id} onClick={() => nyttProsjekt(id)} style={{ ...st.card, padding: 0, overflow: 'hidden', color: 'white', textAlign: 'left' }}>
          <img src={t.img} alt="" style={{ width: '100%', height: 96, objectFit: 'cover', display: 'block' }} />
          <div style={{ padding: 10, fontWeight: 800 }}>{t.navn}<div style={{ fontSize: 11, color: C.muted, fontWeight: 500 }}>{t.steg.length} steg · ca. {t.steg[t.steg.length - 1].uke} uke(r)</div></div>
        </button>)}
      </div>
    </>
  );
}

function MalFelt({ navn, v, sett, ar, enhet = 'm' }) {
  return (
    <label style={{ display: 'block', marginBottom: 10 }}>
      <div style={{ fontSize: 12, color: C.muted, marginBottom: 4 }}>{navn} ({enhet})</div>
      <div style={{ display: 'flex', gap: 6 }}>
        <input inputMode="decimal" value={v} onChange={(e) => sett(e.target.value)} style={{ flex: 1, minWidth: 0, background: '#ffffff12', border: '1px solid #ffffff33', borderRadius: 10, color: 'white', padding: 12, fontSize: 17 }} />
        {ar && <Knapp aria-label="Mål med AR" onClick={ar} stil={{ padding: '0 12px' }}><Ruler size={18} /></Knapp>}
      </div>
    </label>
  );
}

function Skann({ p, oppdater, go, vis }) {
  const [modus, setModus] = useState(p.foto ? 'Manuell' : 'Skann');
  const [b, setB] = useState(String(p.mal.b)); const [l, setL] = useState(String(p.mal.l)); const [h, setH] = useState(String(p.mal.h));
  const [bordCm, setBordCm] = useState(String(Math.round((p.mal.bord || 0.19) * 1000) / 10));
  const kam = useKamera(modus === 'Skann');
  const tall = (s2) => { const n = parseFloat(String(s2).replace(',', '.')); return Number.isFinite(n) && n > 0 ? n : null; };
  const lagre = () => {
    const m = { b: tall(b), l: tall(l), h: tall(h) ?? p.mal.h, ...(gulv ? { bord: (tall(bordCm) || 19) / 100 } : {}) };
    if (gulv && (m.bord < 0.05 || m.bord > 0.5)) { vis('Bordbredden ser feil ut – skriv den i cm, f.eks. 19,2'); return; }
    if (!m.b || !m.l) { vis('Skriv inn gyldige mål, f.eks. 4,2'); return; }
    if (m.b > 50 || m.l > 50 || m.h > 10) { vis('Målene ser for store ut – sjekk dem'); return; }
    oppdater({ mal: m, status: p.status === 'planlagt' ? 'pagaende' : p.status });
    go('resultat');
  };
  // AR-linjal finnes bare i den native appen (ARKit-plugin). I nettleser skjules knappen.
  const arNative = typeof window !== 'undefined' && typeof window.TAMERFIX_MAAL_AR === 'function';
  const maalAR = (sett) => async () => {
    try { const r = await window.TAMERFIX_MAAL_AR(); const m = Number(r?.meter ?? r?.distance ?? r); if (Number.isFinite(m) && m > 0) sett(m.toFixed(2)); } catch { vis('AR-måling avbrutt'); }
  };
  const terr = TYPER[p.type].form === 'terrasse'; const vegg = TYPER[p.type].form === 'vegg'; const gulv = TYPER[p.type].form === 'gulv';
  return (
    <>
      <Topp tittel="Skann område" tilbake={() => go('home')} />
      <div style={{ position: 'relative', background: '#000', height: 320 }}>
        {modus === 'Skann' ? <video ref={kam.ref} playsInline muted autoPlay style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          : <img src={p.foto || TYPER[p.type].img} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', opacity: 0.85 }} />}
        <svg viewBox="0 0 100 100" preserveAspectRatio="none" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
          <polygon points="22,48 78,48 94,88 6,88" fill="#3fbf6f33" stroke="white" strokeWidth={0.6} />
          {[[22, 48], [78, 48], [94, 88], [6, 88]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r={1.4} fill="white" />)}
        </svg>
        <div style={{ position: 'absolute', left: '50%', top: '38%', transform: 'translateX(-50%)', background: 'white', color: C.ink, borderRadius: 8, padding: '3px 8px', fontWeight: 800 }}>{b || '?'} m</div>
        <div style={{ position: 'absolute', left: 14, top: '64%', background: 'white', color: C.ink, borderRadius: 8, padding: '3px 8px', fontWeight: 800 }}>{(vegg ? h : l) || '?'} m</div>
        {kam.feil && modus === 'Skann' && <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', padding: 20, textAlign: 'center', background: '#000b' }}>{kam.feil}</div>}
      </div>
      <div style={st.pad}>
        <Faner valg={['Skann', 'Manuell', 'AR']} verdi={modus} sett={setModus} />
        {modus === 'Skann' && <>
          <p style={{ fontSize: 13, color: C.muted }}>Ta et bilde av området – det brukes som «før»-bilde. Skriv så inn målene under.</p>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-around' }}>
            <label style={{ cursor: 'pointer', textAlign: 'center', fontSize: 11 }}>
              <img src={p.foto || TYPER[p.type].img} alt="" style={{ width: 52, height: 52, objectFit: 'cover', borderRadius: 8, display: 'block' }} />Galleri
              <input type="file" accept="image/*" hidden onChange={async (e) => { const f = e.target.files?.[0]; if (f) { oppdater({ foto: await filTilBilde(f) }); setModus('Manuell'); vis('Bilde lagret'); } }} />
            </label>
            <button aria-label="Ta bilde" onClick={() => { const k = kam.knips(); if (k) { oppdater({ foto: k.url }); setModus('Manuell'); vis('Bilde lagret – skriv inn målene'); } else vis('Kameraet er ikke klart ennå'); }} style={{ width: 72, height: 72, borderRadius: 50, border: '5px solid white', background: '#ffffff33' }} />
            <button onClick={() => vis('Hold telefonen i brysthøyde og få med hele området.')} style={{ background: 'none', border: 0, color: 'white', fontSize: 11 }}><Lightbulb /><div>Tips</div></button>
          </div>
        </>}
        {modus === 'AR' && <div style={{ ...st.card, marginTop: 12, fontSize: 13 }}>
          {arNative ? 'AR-linjal er klar: trykk linjal-ikonet ved et mål og pek på start- og sluttpunkt.' : 'AR-måling krever Fiks hjem-appen på iPhone/iPad. I nettleseren blokkerer Safari kameraets dybdesensor, så skriv målene inn her. Du kan fortsatt se prosjektet ditt i AR under Resultat → AR.'}
        </div>}
        <div style={{ marginTop: 12 }}>
          <MalFelt navn={vegg ? 'Veggens lengde' : 'Bredde'} v={b} sett={setB} ar={arNative ? maalAR(setB) : null} />
          {!vegg && <MalFelt navn={terr ? 'Dybde' : 'Lengde'} v={l} sett={setL} ar={arNative ? maalAR(setL) : null} />}
          {gulv
            ? <MalFelt navn="Bordbredde – står på pakken" enhet="cm" v={bordCm} sett={setBordCm} />
            : <MalFelt navn={terr ? 'Høyde over bakken' : 'Takhøyde'} v={h} sett={setH} ar={arNative ? maalAR(setH) : null} />}
        </div>
        <Knapp gull stil={{ width: '100%' }} onClick={lagre}>Se resultatet →</Knapp>
      </div>
    </>
  );
}

function FoerEtter({ foer, etter }) {
  const [x, setX] = useState(50);
  return (
    <div style={{ position: 'relative', height: 260, overflow: 'hidden', borderRadius: 12, background: C.navy2 }}>
      <div style={{ position: 'absolute', inset: 0 }}>{etter}</div>
      <div style={{ position: 'absolute', inset: 0, clipPath: `inset(0 ${100 - x}% 0 0)` }}>{foer}</div>
      <div style={{ position: 'absolute', top: 0, bottom: 0, left: `${x}%`, width: 3, background: 'white' }} />
      <span style={{ position: 'absolute', top: 8, left: 8, background: '#000a', padding: '2px 8px', borderRadius: 8, fontSize: 12 }}>Før</span>
      <span style={{ position: 'absolute', top: 8, right: 8, background: '#000a', padding: '2px 8px', borderRadius: 8, fontSize: 12 }}>Etter</span>
      <input aria-label="Før/etter" type="range" min={0} max={100} value={x} onChange={(e) => setX(+e.target.value)} style={{ position: 'absolute', bottom: 8, left: '5%', width: '90%' }} />
    </div>
  );
}

function Resultat({ p, go, oppdater }) {
  const [modus, setModus] = useState('3D'); const [vinkel, setVinkel] = useState(TYPER[p.type].form === 'vegg' ? -30 : 35); const [uke, setUke] = useState(100); const [lys, setLys] = useState(true); const [fe, setFe] = useState(false);
  const drag = useRef(null);
  const steg = TYPER[p.type].steg; const n = steg.length;
  const velg = (m) => (m === 'AR' ? go('ar') : (setModus(m), setFe(false)));
  const vis3d = (fr) => (
    <div onPointerDown={(e) => { drag.current = { x: e.clientX, v: vinkel }; }} onPointerMove={(e) => { if (drag.current) setVinkel(drag.current.v + (e.clientX - drag.current.x) * 0.6); }} onPointerUp={() => { drag.current = null; }} onPointerLeave={() => { drag.current = null; }}
      style={{ ...st.sky, touchAction: 'none', background: lys ? st.sky.background : 'linear-gradient(#0d2233,#1c3b2c)' }}>
      <Iso p={p} vinkel={vinkel} fremdrift={fr} sol={lys} />
    </div>
  );
  const bilde = (src) => <img src={src} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />;
  return (
    <>
      <Topp tittel="Ferdig resultat" tilbake={() => go('skann')} />
      <div style={st.pad}>
        <Faner valg={['2D', '3D', '4D', 'AR']} verdi={modus} sett={velg} />
        <div style={{ marginTop: 12, position: 'relative' }}>
          {fe ? <FoerEtter foer={bilde(p.foto || TYPER[p.type].img)} etter={p.etterFoto ? bilde(p.etterFoto) : <div style={{ ...st.sky, height: '100%' }}><Iso p={p} vinkel={vinkel} /></div>} />
            : modus === '2D' ? <div style={{ borderRadius: 12, overflow: 'hidden' }}><Plan2D p={p} /></div>
            : modus === '4D' ? <>
              {vis3d(uke / 100)}
              <div style={{ fontSize: 13, marginTop: 8 }}>Uke {Math.max(1, Math.ceil((uke / 100) * steg[n - 1].uke))}: <b>{steg[Math.min(n - 1, Math.floor((uke / 100) * n))].tittel}</b></div>
              <input aria-label="Tidslinje" type="range" min={0} max={100} value={uke} onChange={(e) => setUke(+e.target.value)} style={{ width: '100%' }} />
            </>
            : vis3d(1)}
          {modus === '3D' && !fe && <div style={{ position: 'absolute', right: 8, top: 8, display: 'flex', flexDirection: 'column', gap: 6 }}>
            <button aria-label="Roter" onClick={() => setVinkel(vinkel + 45)} style={{ ...st.btn, padding: 8, background: '#061b2dcc', color: 'white' }}><RotateCcw size={18} /></button>
            <button aria-label="Lys" onClick={() => setLys(!lys)} style={{ ...st.btn, padding: 8, background: '#061b2dcc', color: 'white' }}><Sun size={18} /></button>
          </div>}
        </div>
        {modus === '3D' && !fe && <div style={{ fontSize: 12, color: C.muted, marginTop: 6 }}>Dra for å rotere · {malTekst(p)}</div>}
        <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
          <Knapp onClick={() => setFe(!fe)} stil={{ flex: 1 }}>⇆ {fe ? 'Skjul før/etter' : 'Før/etter'}</Knapp>
          <Knapp onClick={() => go('film')} stil={{ flex: 1 }}><Play size={14} /> Se film</Knapp>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginTop: 8 }}>
          <Knapp onClick={() => go('materialer')}>🛒 Materialer</Knapp><Knapp onClick={() => go('forlop')}>📅 4D forløp</Knapp>
        </div>
        <Knapp gull stil={{ width: '100%', marginTop: 12 }} onClick={() => { if (p.status === 'planlagt') oppdater({ status: 'pagaende' }); go('steg'); }}>Start byggeguide</Knapp>
      </div>
    </>
  );
}

/* Animert «film»: prosjektet ditt bygges opp i 3D over 40 sek, med tekst for hver del. */
function FilmSpiller({ p, stegIdx, kompakt, onFerdig }) {
  const [t, setT] = useState(0); const [spiller, setSpiller] = useState(false); const boks = useRef(null);
  const tRef = useRef(0); tRef.current = t;
  const ferdigRef = useRef(onFerdig); ferdigRef.current = onFerdig;
  useEffect(() => { setT(0); setSpiller(false); }, [stegIdx]);
  useEffect(() => {
    if (!spiller) return undefined;
    const start = performance.now() - tRef.current * 1000; let id;
    const tikk = (na) => { const ny = (na - start) / 1000; if (ny >= FILM_SEK) { setT(FILM_SEK); setSpiller(false); ferdigRef.current?.(); return; } setT(ny); id = requestAnimationFrame(tikk); };
    id = requestAnimationFrame(tikk);
    return () => cancelAnimationFrame(id);
  }, [spiller]);
  const steg = TYPER[p.type].steg; const n = steg.length; const s = steg[stegIdx];
  const del = Math.min(s.sjekk.length - 1, Math.floor((t / FILM_SEK) * s.sjekk.length));
  const mmss = (x) => `00:${String(Math.floor(x)).padStart(2, '0')}`;
  return (
    <div ref={boks} style={{ background: '#000', borderRadius: kompakt ? 12 : 0, overflow: 'hidden', position: 'relative' }}>
      <div style={{ background: st.sky.background }}><Iso p={p} fremdrift={(stegIdx + t / FILM_SEK) / n} vinkel={TYPER[p.type].form === 'vegg' ? -50 + t * 1.5 : 20 + t * 2} hoyde={kompakt ? 190 : 240} /></div>
      <div style={{ position: 'absolute', left: 8, top: 8, background: '#000b', borderRadius: 8, padding: '4px 8px', fontSize: 12, fontWeight: 700 }}>{stegIdx + 1}/{n} · {s.sjekk[del]}</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px', background: C.navy2 }}>
        <button aria-label={spiller ? 'Pause' : 'Spill'} onClick={() => { if (t >= FILM_SEK) setT(0); setSpiller(!spiller); }} style={{ background: 'none', border: 0, color: 'white' }}>{spiller ? <Pause size={20} /> : <Play size={20} />}</button>
        <div style={{ flex: 1, height: 5, background: '#ffffff30', borderRadius: 5 }}><div style={{ width: `${(t / FILM_SEK) * 100}%`, height: '100%', background: C.gold, borderRadius: 5 }} /></div>
        <span style={{ fontSize: 12, fontVariantNumeric: 'tabular-nums' }}>{mmss(t)} / 00:{FILM_SEK}</span>
        {!kompakt && <button aria-label="Fullskjerm" onClick={() => boks.current?.requestFullscreen?.()?.catch?.(() => {})} style={{ background: 'none', border: 0, color: 'white' }}><Maximize size={18} /></button>}
      </div>
    </div>
  );
}

function Steg({ p, oppdater, go, vis }) {
  const steg = TYPER[p.type].steg; const i = Math.min(p.steg, steg.length - 1); const s = steg[i];
  const kryss = p.sjekk?.[i] || [];
  const vend = (k) => { const ny = { ...(p.sjekk || {}) }; const a = [...(ny[i] || [])]; a[k] = !a[k]; ny[i] = a; oppdater({ sjekk: ny }); };
  const alle = s.sjekk.every((_, k) => kryss[k]);
  const form = TYPER[p.type].form; const manual = form === 'terrasse' || form === 'vegg' || form === 'gulv';
  const [delIdx, setDelIdx] = useState(0);
  useEffect(() => { setDelIdx(0); }, [i]);
  const neste = () => {
    if (!alle && !window.confirm('Ikke alle punkter er huket av. Gå videre likevel?')) return;
    if (i + 1 >= steg.length) { oppdater({ steg: steg.length, status: 'ferdig', ferdigDato: Date.now() }); go('ferdig'); }
    else { oppdater({ steg: i + 1, status: 'pagaende' }); vis(`Steg ${i + 1} fullført ✓`); window.scrollTo(0, 0); }
  };
  return (
    <>
      <Topp tittel="Bygg steg for steg" tilbake={() => (i > 0 ? oppdater({ steg: i - 1 }) : go('resultat'))} hoyre={<button onClick={() => go('forlop')} style={{ background: 'none', border: 0, color: C.gold, fontSize: 13, fontWeight: 800 }}>4D</button>} />
      <div style={st.pad}>
        <div style={{ display: 'flex', alignItems: 'end', justifyContent: 'space-between', marginBottom: 8 }}>
          <div><div style={{ color: C.gold, fontWeight: 900, fontSize: 20 }}>{i + 1}/{steg.length}</div><div style={{ fontWeight: 800, fontSize: 18 }}>{s.tittel}</div></div>
          <span style={{ background: C.gold, color: C.ink, borderRadius: 8, padding: '4px 8px', fontWeight: 800, fontSize: 12 }}>Uke {s.uke}</span>
        </div>
        {manual
          ? (form === 'gulv'
            ? <GulvManual p={p} stegIdx={i} delIdx={delIdx} settDel={setDelIdx} kryss={kryss} vend={vend} Iso={Iso} C={C} />
            : form === 'vegg'
            ? <VeggManual p={p} stegIdx={i} delIdx={delIdx} settDel={setDelIdx} kryss={kryss} vend={vend} Iso={Iso} C={C} />
            : <TerrasseManual p={p} stegIdx={i} delIdx={delIdx} settDel={setDelIdx} kryss={kryss} vend={vend} Iso={Iso} C={C} />)
          : <FilmSpiller p={p} stegIdx={i} kompakt />}
        {!manual && <div style={{ ...st.card, marginTop: 10 }}>
          {s.sjekk.map((x, k) => <button key={k} onClick={() => vend(k)} style={{ display: 'flex', gap: 10, alignItems: 'center', width: '100%', background: 'none', border: 0, color: 'white', padding: '8px 0', fontSize: 15, textAlign: 'left' }}>
            {kryss[k] ? <CheckCircle2 color={C.ok} /> : <Circle color={C.muted} />}<span style={{ textDecoration: kryss[k] ? 'line-through' : 'none', opacity: kryss[k] ? 0.7 : 1 }}>{x}</span>
          </button>)}
        </div>}
        {s.tips && <div style={{ ...st.card, marginTop: 10, background: '#1c3a55', fontSize: 13 }}>💡 {s.tips}</div>}
        <Knapp gull stil={{ width: '100%', marginTop: 12 }} onClick={neste}>{i + 1 >= steg.length ? 'Fullfør prosjektet ✓' : 'Neste steg →'}</Knapp>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginTop: 8 }}><Knapp onClick={() => go('materialer')}>Materialer</Knapp><Knapp onClick={() => go('film')}>Alle filmer</Knapp></div>
      </div>
    </>
  );
}

function Forlop({ p, go, oppdater }) {
  const steg = TYPER[p.type].steg; const ferdigP = p.status === 'ferdig';
  return (
    <>
      <Topp tittel="4D – Byggeforløp" tilbake={() => go(ferdigP ? 'ferdig' : 'steg')} />
      <div style={st.pad}>
        <div style={{ fontSize: 13, color: C.muted, textAlign: 'center', marginTop: -6 }}>Se hele prosessen over tid.</div>
        <div style={{ ...st.sky, marginTop: 8 }}><Iso p={p} fremdrift={ferdigP ? 1 : (p.steg + 0.5) / steg.length} hoyde={220} /></div>
        <div style={{ ...st.card, marginTop: 10 }}>
          {steg.map((s, i) => <button key={i} onClick={() => { oppdater({ steg: i, ...(ferdigP ? { status: 'pagaende' } : {}) }); go('steg'); }} style={{ display: 'flex', gap: 10, alignItems: 'center', width: '100%', background: i === p.steg && !ferdigP ? '#ffffff12' : 'none', border: 0, borderRadius: 8, color: 'white', padding: '8px 6px', textAlign: 'left' }}>
            {ferdigP || i < p.steg ? <CheckCircle2 color={C.ok} /> : <Circle color={i === p.steg ? C.gold : C.muted} />}
            <span style={{ flex: 1 }}>{i + 1}. {s.tittel}</span><span style={{ fontSize: 12, color: C.muted }}>Uke {s.uke}</span>
          </button>)}
        </div>
      </div>
    </>
  );
}

function Materialer({ p, go, leggTil }) {
  const [fane, setFane] = useState('Materialliste');
  const t = TYPER[p.type]; const liste = t.materialer(p.mal);
  const sum = liste.reduce((s2, m) => s2 + m[3] * m[5], 0);
  const legg = () => leggTil(fane === 'Materialliste'
    ? liste.filter((m) => m[3] > 0 && m[4] !== 'beregning').map(([, n, d, a, e, pris]) => ({ navn: `${n} ${d}`.trim(), antall: a, enhet: e, pris, prosjekt: p.navn }))
    : t.verktoy.map((v) => ({ navn: v, antall: 1, enhet: 'stk', pris: 0, prosjekt: p.navn })));
  return (
    <>
      <Topp tittel="Materialer og verktøy" tilbake={() => go('resultat')} />
      <div style={st.pad}>
        <Faner valg={['Materialliste', 'Verktøy']} verdi={fane} sett={setFane} />
        <div style={{ background: 'white', color: C.ink, borderRadius: 14, marginTop: 12, overflow: 'hidden' }}>
          {fane === 'Materialliste' ? liste.map(([ik, n, d, a, e, pris], k) => <div key={k} style={{ display: 'flex', gap: 10, alignItems: 'center', padding: 12, borderBottom: '1px solid #e6ebef' }}>
            <div style={{ fontSize: 26, width: 36, textAlign: 'center' }}>{ik}</div>
            <div style={{ flex: 1 }}><b>{n}</b><div style={{ fontSize: 12, color: '#607080' }}>{d}</div></div>
            <div style={{ textAlign: 'right' }}><b>{a} {e}</b>{pris > 0 && <div style={{ fontSize: 11, color: '#607080' }}>{kr(a * pris)}</div>}</div>
          </div>)
            : t.verktoy.map((v) => <div key={v} style={{ padding: 12, borderBottom: '1px solid #e6ebef' }}>🔧 {v}</div>)}
          {fane === 'Materialliste' && sum > 0 && <div style={{ padding: 12, display: 'flex', justifyContent: 'space-between', fontWeight: 900 }}><span>Sum (veiledende)</span><span>{kr(sum)}</span></div>}
        </div>
        <p style={{ fontSize: 11, color: C.muted }}>Mengdene er beregnet fra målene dine ({malTekst(p)}){TYPER[p.type].form === 'vegg' ? '. Priser vises ikke – vi har ikke kontrollerte priser for vegg.' : ' med svinn. Prisene er veiledende.'} Kontroller spennvidder og dimensjoner i Byggemoduler før du kapper.</p>
        <Knapp gull stil={{ width: '100%' }} onClick={legg}>Legg i handleliste</Knapp>
        <Knapp stil={{ width: '100%', marginTop: 8 }} onClick={() => go('full')}>Nøyaktig beregning i Byggemoduler →</Knapp>
      </div>
    </>
  );
}

const DEMO = { id: 'demo', type: 'terrasse', mal: TYPER.terrasse.mal, navn: 'Terrasse', steg: 0 };
function Filmer({ p, go }) {
  const prosjekt = p || DEMO;
  const steg = TYPER[prosjekt.type].steg;
  const [i, setI] = useState(Math.min(prosjekt.steg || 0, steg.length - 1));
  return (
    <>
      <Topp tittel={`Kort film (${FILM_SEK} sek)`} tilbake={() => go(p ? 'steg' : 'home')} />
      <FilmSpiller p={prosjekt} stegIdx={i} onFerdig={() => { if (i + 1 < steg.length) setTimeout(() => setI((x) => x + 1), 800); }} />
      <div style={st.pad}>
        <div style={{ ...st.card, display: 'flex', gap: 10, alignItems: 'center' }}>
          <img src={TYPER[prosjekt.type].img} alt="" style={{ width: 48, height: 36, objectFit: 'cover', borderRadius: 6 }} />
          <div><b>{steg[i].tittel}</b><div style={{ fontSize: 12, color: C.muted }}>{prosjekt.navn} · {FILM_SEK} sek · animert 3D</div></div>
        </div>
        <div style={{ fontWeight: 800, margin: '12px 0 6px' }}>Alle steg i denne filmen</div>
        <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 6 }}>
          {steg.map((s, k) => <button key={k} onClick={() => setI(k)} style={{ flex: '0 0 100px', border: `2px solid ${k === i ? C.gold : 'transparent'}`, borderRadius: 10, padding: 0, background: st.sky.background, overflow: 'hidden' }}>
            <Iso p={prosjekt} fremdrift={(k + 1) / steg.length} hoyde={64} /><div style={{ background: C.navy2, color: 'white', fontSize: 11, padding: 3 }}>{k + 1}. {s.tittel}</div>
          </button>)}
        </div>
        <p style={{ fontSize: 11, color: C.muted }}>Filmene er animasjoner av ditt eget prosjekt med dine mål, og spilles av uten internett.{!p && ' Start et prosjekt for å se det med dine mål.'}</p>
      </div>
    </>
  );
}

function AR({ p, go, oppdater, vis }) {
  const kam = useKamera(true);
  const [pos, setPos] = useState({ x: 50, y: 62 }); const [skala, setSkala] = useState(60); const [vinkel, setVinkel] = useState(TYPER[p.type].form === 'vegg' ? -30 : 35); const [plassert, setPlassert] = useState(false);
  const modell = useRef(null); const flate = useRef(null); const drag = useRef(null);
  const ned = (e) => { if (!plassert) drag.current = { x: e.clientX, y: e.clientY, p: pos, r: flate.current.getBoundingClientRect() }; };
  const flytt = (e) => { const d = drag.current; if (d) setPos({ x: d.p.x + ((e.clientX - d.x) / d.r.width) * 100, y: d.p.y + ((e.clientY - d.y) / d.r.height) * 100 }); };
  const taBilde = async () => {
    const f = flate.current.getBoundingClientRect();
    const c = document.createElement('canvas'); c.width = 900; c.height = Math.round((900 * f.height) / f.width); const g = c.getContext('2d');
    const v = kam.ref.current;
    if (v && v.videoWidth && !kam.feil) { // «cover»-beskjæring som i visningen
      const sk = Math.max(c.width / v.videoWidth, c.height / v.videoHeight);
      g.drawImage(v, (c.width - v.videoWidth * sk) / 2, (c.height - v.videoHeight * sk) / 2, v.videoWidth * sk, v.videoHeight * sk);
    } else { g.fillStyle = '#556'; g.fillRect(0, 0, c.width, c.height); }
    const svg = modell.current?.querySelector('svg');
    if (svg) {
      const img = new Image(); img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(new XMLSerializer().serializeToString(svg));
      await new Promise((r) => { img.onload = r; img.onerror = r; });
      const r = svg.getBoundingClientRect(); const k = c.width / f.width;
      g.drawImage(img, (r.left - f.left) * k, (r.top - f.top) * k, r.width * k, r.height * k);
    }
    oppdater({ etterFoto: c.toDataURL('image/jpeg', 0.72) }); vis('Bilde lagret som «etter» ✓');
  };
  return (
    <>
      <Topp tittel="AR – Se i ditt eget miljø" tilbake={() => go('resultat')} />
      <div ref={flate} onPointerDown={ned} onPointerMove={flytt} onPointerUp={() => { drag.current = null; }} style={{ position: 'relative', height: 420, background: '#000', touchAction: 'none', overflow: 'hidden' }}>
        <video ref={kam.ref} playsInline muted autoPlay style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        {kam.feil && <img src={p.foto || TYPER[p.type].img} alt="" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }} />}
        <div ref={modell} style={{ position: 'absolute', left: `${pos.x}%`, top: `${pos.y}%`, width: `${skala}%`, transform: 'translate(-50%,-50%)', filter: plassert ? 'none' : 'drop-shadow(0 0 6px #fff)', opacity: plassert ? 1 : 0.85 }}>
          <Iso p={p} vinkel={vinkel} hoyde={skala * 3} />
        </div>
        {kam.feil && <div style={{ position: 'absolute', top: 8, left: 8, right: 8, background: '#000b', padding: 8, borderRadius: 8, fontSize: 12 }}>Kamera utilgjengelig – viser prosjektbildet ditt i stedet.</div>}
      </div>
      <div style={st.pad}>
        <label style={{ fontSize: 12, color: C.muted, display: 'block' }}>Størrelse<input type="range" min={20} max={100} value={skala} onChange={(e) => setSkala(+e.target.value)} style={{ width: '100%' }} /></label>
        <label style={{ fontSize: 12, color: C.muted, display: 'block' }}>Roter<input type="range" min={0} max={360} value={vinkel} onChange={(e) => setVinkel(+e.target.value)} style={{ width: '100%' }} /></label>
        <div style={{ display: 'flex', gap: 8, marginTop: 6 }}>
          <Knapp gull stil={{ flex: 2 }} onClick={() => { setPlassert(!plassert); vis(plassert ? 'Flytt modellen med fingeren' : 'Plassert ✓'); }}>{plassert ? 'Flytt igjen' : 'Plasser i ditt hjem'}</Knapp>
          <Knapp stil={{ flex: 1 }} onClick={taBilde}><Camera size={16} /> Bilde</Knapp>
        </div>
        <p style={{ fontSize: 11, color: C.muted }}>Dra modellen dit den skal stå, og juster størrelse og vinkel. «Bilde» lagrer det som etter-bilde i før/etter.</p>
      </div>
    </>
  );
}

function Ferdig({ p, go, vis }) {
  const del = async () => {
    const tekst = `Ferdig med ${p.navn.toLowerCase()} (${malTekst(p)}) – planlagt med Fiks hjem!`;
    try {
      if (navigator.share) {
        const bilde = p.etterFoto || p.foto;
        if (bilde && navigator.canShare) {
          const blob = await (await fetch(bilde)).blob(); const fil = new File([blob], 'fiks-hjem.jpg', { type: 'image/jpeg' });
          if (navigator.canShare({ files: [fil] })) { await navigator.share({ text: tekst, files: [fil] }); return; }
        }
        await navigator.share({ title: 'Fiks hjem', text: tekst }); return;
      }
      await navigator.clipboard.writeText(tekst); vis('Tekst kopiert – lim inn hvor du vil');
    } catch { /* bruker avbrøt deling */ }
  };
  return (
    <>
      <Topp tittel="Ferdig resultat" tilbake={() => go('forlop')} />
      {p.etterFoto ? <img src={p.etterFoto} alt="" style={{ width: '100%', height: 300, objectFit: 'cover', display: 'block' }} /> : <div style={{ background: 'linear-gradient(#f5c98a,#eaf4ea)' }}><Iso p={p} hoyde={300} /></div>}
      <div style={st.pad}>
        <div style={{ ...st.card, display: 'flex', gap: 12, alignItems: 'center' }}><CheckCircle2 size={42} color={C.ok} /><div><div style={{ color: C.ok, fontWeight: 900, fontSize: 18 }}>Prosjektet er ferdig!</div><div>Nyt resultatet – {p.navn.toLowerCase()}.</div></div></div>
        <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
          <Knapp stil={{ flex: 1 }} onClick={() => { vis('Prosjektet er lagret'); go('prosjekter'); }}><Save size={16} /> Lagre prosjekt</Knapp>
          <Knapp gull stil={{ flex: 1 }} onClick={del}><Share2 size={16} /> Del resultat</Knapp>
        </div>
        {!p.etterFoto && <Knapp stil={{ width: '100%', marginTop: 8 }} onClick={() => go('ar')}>📷 Ta etter-bilde</Knapp>}
      </div>
    </>
  );
}

function Prosjekter({ prosjekter, apne, slett, nytt }) {
  const [fane, setFane] = useState('Alle');
  const liste = prosjekter.filter((p) => fane === 'Alle' || (fane === 'Pågående' ? p.status !== 'ferdig' : p.status === 'ferdig')).sort((a, b) => b.endret - a.endret);
  const pst = (p) => Math.round((p.steg / TYPER[p.type].steg.length) * 100);
  return (
    <>
      <Topp tittel="Mine prosjekter" />
      <div style={st.pad}>
        <Faner valg={['Alle', 'Pågående', 'Ferdig']} verdi={fane} sett={setFane} />
        <div style={{ background: 'white', color: C.ink, borderRadius: 14, marginTop: 12, overflow: 'hidden' }}>
          {!liste.length && <div style={{ padding: 20, textAlign: 'center', color: '#607080' }}>Ingen prosjekter her ennå.</div>}
          {liste.map((p) => <div key={p.id} style={{ display: 'flex', gap: 6, alignItems: 'center', padding: 10, borderBottom: '1px solid #e6ebef' }}>
            <button onClick={() => apne(p.id)} style={{ display: 'flex', gap: 10, alignItems: 'center', flex: 1, background: 'none', border: 0, textAlign: 'left', color: C.ink, padding: 0 }}>
              <img src={p.etterFoto || p.foto || TYPER[p.type].img} alt="" style={{ width: 66, height: 50, objectFit: 'cover', borderRadius: 8 }} />
              <div style={{ flex: 1 }}><b>{p.navn}</b><div style={{ fontSize: 12, color: p.status === 'ferdig' ? '#1e8a4c' : p.status === 'pagaende' ? '#c98a00' : '#607080' }}>{p.status === 'ferdig' ? `Ferdig • ${dato(p.ferdigDato || p.endret)}` : p.status === 'pagaende' ? `Pågående • ${pst(p)}%` : 'Planlagt'}</div></div>
              <ChevronRight size={18} />
            </button>
            <button aria-label="Slett" onClick={() => { if (window.confirm(`Slette «${p.navn}»?`)) slett(p.id); }} style={{ background: 'none', border: 0, color: '#b0bcc6', padding: 6 }}><Trash2 size={18} /></button>
          </div>)}
        </div>
        <Knapp gull stil={{ width: '100%', marginTop: 12 }} onClick={nytt}><Plus size={16} /> Nytt prosjekt</Knapp>
      </div>
    </>
  );
}

function Profil({ handleliste, setHandleliste, vis, lagringOk, go }) {
  const sum = handleliste.reduce((s2, v) => s2 + v.antall * v.pris, 0);
  const del = async () => {
    const tekst = 'Handleliste – Fiks hjem\n' + handleliste.map((v) => `• ${v.navn}: ${v.antall} ${v.enhet}`).join('\n');
    try { if (navigator.share) await navigator.share({ text: tekst }); else { await navigator.clipboard.writeText(tekst); vis('Kopiert'); } } catch { /* avbrutt */ }
  };
  return (
    <>
      <Topp tittel="Profil og handleliste" />
      <div style={st.pad}>
        <div style={{ ...st.card, display: 'flex', gap: 10, alignItems: 'center' }}><ShoppingCart color={C.gold} /><b style={{ flex: 1 }}>Handleliste ({handleliste.length})</b>{handleliste.length > 0 && <button onClick={() => { if (window.confirm('Tømme handlelisten?')) setHandleliste([]); }} style={{ background: 'none', border: 0, color: C.red, fontWeight: 700 }}>Tøm</button>}</div>
        <div style={{ background: 'white', color: C.ink, borderRadius: 14, marginTop: 8, overflow: 'hidden' }}>
          {!handleliste.length && <div style={{ padding: 16, color: '#607080' }}>Tom. Legg til fra «Materialer og verktøy».</div>}
          {handleliste.map((v, k) => <div key={k} style={{ display: 'flex', alignItems: 'center', padding: 10, borderBottom: '1px solid #e6ebef', gap: 8 }}>
            <input type="checkbox" aria-label="Kjøpt" checked={!!v.kjopt} onChange={() => setHandleliste(handleliste.map((x, j) => (j === k ? { ...x, kjopt: !x.kjopt } : x)))} />
            <div style={{ flex: 1, textDecoration: v.kjopt ? 'line-through' : 'none' }}><b>{v.navn}</b><div style={{ fontSize: 11, color: '#607080' }}>{v.prosjekt}</div></div>
            <span style={{ fontSize: 13 }}>{v.antall} {v.enhet}</span>
            <button aria-label="Fjern" onClick={() => setHandleliste(handleliste.filter((_, j) => j !== k))} style={{ background: 'none', border: 0, color: '#b0bcc6' }}><Trash2 size={16} /></button>
          </div>)}
          {sum > 0 && <div style={{ padding: 10, fontWeight: 900, display: 'flex', justifyContent: 'space-between' }}><span>Sum (veiledende)</span><span>{kr(sum)}</span></div>}
        </div>
        {handleliste.length > 0 && <Knapp gull stil={{ width: '100%', marginTop: 10 }} onClick={del}><Share2 size={16} /> Del handleliste</Knapp>}
        <div style={{ ...st.card, marginTop: 14, fontSize: 13, lineHeight: 1.7 }}>
          📶 Fungerer uten internett – alt lagres på denne enheten.<br />
          {lagringOk ? '✅ Lagring OK' : '⚠️ Lagringen er full – slett gamle prosjekter med bilder.'}<br />
          ☁️ Synkronisering i skyen er ikke aktivert.
        </div>
        <Knapp stil={{ width: '100%', marginTop: 10 }} onClick={() => go('full', 'profile')}>Innstillinger og personvern ›</Knapp>
      </div>
    </>
  );
}

function Fag({ go }) {
  const fag = [['⚡', 'Elektriker', 'Fast el-installasjon må gjøres av registrert virksomhet.'], ['🚰', 'Rørlegger', 'Våtrom og nye rør: bruk fagfolk.'], ['🔨', 'Snekker', 'Terrasse, tak, bindingsverk.'], ['🖌️', 'Maler', 'Maling, tapet, fasade.'], ['▦', 'Flislegger', 'Bad, flis, membran.'], ['⬛', 'Betong', 'Støp, fundament.'], ['🚜', 'Grunnarbeid', 'Drenering, tomt.']];
  return (
    <><Topp tittel="Fagområde" tilbake={() => go('home')} /><div style={st.pad}>
      {fag.map(([i, n, d]) => <a key={n} href="https://mittanbud.no" target="_blank" rel="noreferrer" style={{ ...st.card, display: 'flex', gap: 12, alignItems: 'center', marginBottom: 8, color: 'white', textDecoration: 'none' }}><span style={{ fontSize: 28 }}>{i}</span><div style={{ flex: 1 }}><b>{n}</b><div style={{ fontSize: 12, color: C.muted }}>{d}</div></div><ChevronRight /></a>)}
      <p style={{ fontSize: 11, color: C.muted }}>Trykk for å finne fagfolk på Mittanbud.</p>
    </div></>
  );
}
function Bolig({ go, vis }) {
  const [bolig, setBolig] = useLagret('fh_bolig', { adresse: '', gnr: '', bnr: '', bygget: '' });
  const gps = () => {
    if (!navigator.geolocation) { vis('GPS støttes ikke'); return; }
    navigator.geolocation.getCurrentPosition((q) => { setBolig((b) => ({ ...b, pos: [q.coords.latitude.toFixed(5), q.coords.longitude.toFixed(5)] })); vis('Posisjon lagret'); }, () => vis('Fikk ikke posisjon'));
  };
  const felt = [['adresse', 'Adresse'], ['gnr', 'Gårdsnummer'], ['bnr', 'Bruksnummer'], ['bygget', 'Byggeår']];
  return (
    <><Topp tittel="Boligen min" tilbake={() => go('home')} /><div style={st.pad}>
      {felt.map(([k, n]) => <label key={k} style={{ display: 'block', marginBottom: 10 }}><div style={{ fontSize: 12, color: C.muted }}>{n}</div><input value={bolig[k] || ''} onChange={(e) => setBolig({ ...bolig, [k]: e.target.value })} style={{ width: '100%', boxSizing: 'border-box', background: '#ffffff12', border: '1px solid #ffffff33', borderRadius: 10, color: 'white', padding: 12, fontSize: 16 }} /></label>)}
      <Knapp stil={{ width: '100%' }} onClick={gps}><MapPin size={16} /> Finn posisjon med GPS</Knapp>
      <Knapp gull stil={{ width: '100%', marginTop: 10 }} onClick={() => go('full', 'bolig')}>Byggeår – hvilke krav gjelder for huset ›</Knapp>
      {bolig.pos && <a href={`https://www.norgeskart.no/#!?zoom=17&lat=${bolig.pos[0]}&lon=${bolig.pos[1]}`} target="_blank" rel="noreferrer" style={{ display: 'block', color: C.gold, marginTop: 10 }}>Åpne i Norgeskart ({bolig.pos.join(', ')})</a>}
    </div></>
  );
}
function Vedlikehold({ go }) {
  const oppg = [['Tøm takrenner og nedløp', 'Høst'], ['Sjekk ildsted og skorstein', 'Høst'], ['Steng og tøm utekranen', 'Før frost'], ['Sjekk silikon på bad', 'Årlig'], ['Rens sluk', 'Hver 3. måned'], ['Vask fasade', 'Vår'], ['Beis/olje terrasse', 'Vår/sommer'], ['Test røykvarslere', 'Årlig (1. des)']];
  const [gjort, setGjort] = useLagret('fh_vedlikehold', {});
  const aar = new Date().getFullYear();
  return (
    <><Topp tittel="Vedlikehold" tilbake={() => go('home')} /><div style={st.pad}>
      {oppg.map(([n, n2]) => { const k = `${aar}:${n}`; return <button key={n} onClick={() => setGjort({ ...gjort, [k]: !gjort[k] })} style={{ ...st.card, width: '100%', display: 'flex', gap: 10, alignItems: 'center', marginBottom: 8, color: 'white', textAlign: 'left' }}>{gjort[k] ? <CheckCircle2 color={C.ok} /> : <Circle color={C.muted} />}<div style={{ flex: 1 }}><b>{n}</b><div style={{ fontSize: 12, color: C.muted }}>{n2}</div></div></button>; })}
      <p style={{ fontSize: 11, color: C.muted }}>Avhukingen nullstilles hvert år.</p>
    </div></>
  );
}

/* =============================== APP =============================== */
/* Egne verktøy som ligger som selvstendige sider i public/verktoy (virker uten nett). */
const VERKTOY = {
  tegnefilm: { tittel: 'Slik gjør du', fil: 'verktoy/slik-gjor-du.html' },
  fasade: { tittel: 'Fasade fra foto', fil: 'verktoy/fasade-fra-foto.html' },
};
function Verktoy({ side, go }) {
  const v = VERKTOY[side] || VERKTOY.tegnefilm;
  return (
    <>
      <Topp tittel={v.tittel} tilbake={() => go('home')} />
      <iframe title={v.tittel} src={import.meta.env.BASE_URL + v.fil} style={{ display: 'block', width: '100%', height: 'calc(100vh - 140px - env(safe-area-inset-bottom))', border: 0, background: C.navy }} />
    </>
  );
}

export default function ModernFiksApp() {
  const [prosjekter, setProsjekter, lagringOk] = useLagret('fh_prosjekter', []);
  const [handleliste, setHandleliste] = useLagret('fh_handleliste', []);
  const [aktivId, setAktivId] = useLagret('fh_aktiv', null);
  const [view, setView] = useState('home'); const [arg, setArg] = useState(null);
  const [toast, setToast] = useState(''); const toastT = useRef(0);
  const vis = (t) => { setToast(t); clearTimeout(toastT.current); toastT.current = setTimeout(() => setToast(''), 2200); };
  const go = (v, a = null) => { setView(v); setArg(a); window.scrollTo(0, 0); };
  const p = prosjekter.find((x) => x.id === aktivId);
  const oppdater = (del) => setProsjekter((ps) => ps.map((x) => (x.id === aktivId ? { ...x, ...del, endret: Date.now() } : x)));
  const nyttProsjekt = (type) => {
    const t = TYPER[type]; const id = 'p' + Date.now();
    const nr = prosjekter.filter((x) => x.type === type).length;
    setProsjekter((ps) => [...ps, { id, type, navn: t.navn + (nr ? ` ${nr + 1}` : ''), mal: { ...t.mal }, steg: 0, sjekk: {}, status: 'planlagt', opprettet: Date.now(), endret: Date.now() }]);
    setAktivId(id); go('skann');
  };
  // Samme vare (navn + enhet, ikke kjøpt) slås sammen i stedet for å bli en dublett.
  // Kalles fra innstillingene i Byggemoduler: «Nullstill» (alt=false) og «Slett alt om meg» (alt=true).
  const slettSkall = (alt) => {
    setProsjekter([]); setHandleliste([]); setAktivId(null);
    try { localStorage.removeItem('fh_vedlikehold'); if (alt) localStorage.removeItem('fh_bolig'); } catch { /* ingen lagring */ }
  };
  const leggTil = (rader) => {
    setHandleliste((h) => {
      const ny = [...h];
      rader.forEach((r) => {
        const i = ny.findIndex((x) => !x.kjopt && x.navn === r.navn && x.enhet === r.enhet);
        if (i >= 0) ny[i] = { ...ny[i], antall: (Number(ny[i].antall) || 0) + (Number(r.antall) || 0) };
        else ny.push(r);
      });
      return ny;
    });
    vis(`${rader.length} ${rader.length === 1 ? 'vare' : 'varer'} lagt i handlelisten ✓`);
  };

  if (view === 'full') {
    return (
      <div>
        <Suspense fallback={<div style={{ ...st.app, display: 'grid', placeItems: 'center' }}>Laster byggemoduler…</div>}><FullApp key={arg || 'bygg'} innebygd start={arg || 'bygg'} onHjem={() => go('home')} onApneJobb={(type) => nyttProsjekt(type)} onLeggTil={leggTil} onHandleliste={() => go('profil')}
          skallTall={{ prosjekter: prosjekter.length, handleliste: handleliste.length }} onSlettSkall={slettSkall} /></Suspense>
        <Bunn go={go} aktiv={arg === 'profile' ? 'profil' : 'home'} />
        {toast && <div role="status" style={{ position: 'fixed', bottom: 82, left: '50%', transform: 'translateX(-50%)', background: C.ok, color: 'white', padding: '10px 16px', borderRadius: 20, fontWeight: 700, zIndex: 60, maxWidth: 380, textAlign: 'center' }}>{toast}</div>}
      </div>
    );
  }
  const trengerProsjekt = ['skann', 'resultat', 'steg', 'forlop', 'materialer', 'ar', 'ferdig', 'film'];
  let innhold;
  if (trengerProsjekt.includes(view) && !p) innhold = <Utforsk go={go} nyttProsjekt={nyttProsjekt} />;
  else switch (view) {
    case 'utforsk': innhold = <Utforsk go={go} nyttProsjekt={nyttProsjekt} filter={arg} />; break;
    case 'skann': innhold = <Skann key={p.id} p={p} oppdater={oppdater} go={go} vis={vis} />; break;
    case 'resultat': innhold = <Resultat p={p} oppdater={oppdater} go={go} />; break;
    case 'steg': innhold = <Steg p={p} oppdater={oppdater} go={go} vis={vis} />; break;
    case 'forlop': innhold = <Forlop p={p} oppdater={oppdater} go={go} />; break;
    case 'materialer': innhold = <Materialer p={p} go={go} leggTil={leggTil} />; break;
    case 'film': innhold = <Filmer key={'f' + p.id} p={p} go={go} />; break;
    case 'filmer': innhold = <Filmer key="demo" p={p && p.status !== 'ferdig' ? p : null} go={go} />; break;
    case 'ar': innhold = <AR p={p} oppdater={oppdater} go={go} vis={vis} />; break;
    case 'ferdig': innhold = <Ferdig p={p} go={go} vis={vis} />; break;
    case 'prosjekter': innhold = <Prosjekter prosjekter={prosjekter} nytt={() => go('utforsk')}
      apne={(id) => { const q = prosjekter.find((x) => x.id === id); setAktivId(id); go(q.status === 'ferdig' ? 'ferdig' : q.status === 'planlagt' ? 'skann' : 'steg'); }}
      slett={(id) => { setProsjekter((ps) => ps.filter((x) => x.id !== id)); if (id === aktivId) setAktivId(null); }} />; break;
    case 'profil': innhold = <Profil handleliste={handleliste} setHandleliste={setHandleliste} vis={vis} lagringOk={lagringOk} go={go} />; break;
    case 'fag': innhold = <Fag go={go} />; break;
    case 'bolig': innhold = <Bolig go={go} vis={vis} />; break;
    case 'vedlikehold': innhold = <Vedlikehold go={go} />; break;
    case 'verktoy': innhold = <Verktoy side={arg} go={go} />; break;
    default: innhold = <Hjem go={go} nyttProsjekt={nyttProsjekt} aktivt={p && p.status !== 'ferdig' ? p : null} />;
  }
  return (
    <div style={st.app}>
      <div style={st.phone}>
        {innhold}
        {toast && <div role="status" style={{ position: 'fixed', bottom: 82, left: '50%', transform: 'translateX(-50%)', background: C.ok, color: 'white', padding: '10px 16px', borderRadius: 20, fontWeight: 700, zIndex: 50, maxWidth: 380, textAlign: 'center' }}>{toast}</div>}
        <Bunn go={go} aktiv={view} />
      </div>
    </div>
  );
}
