import React, { useRef, useState } from 'react';

/* ================================================================
   HELE BYGGTEGNINGEN
   ----------------------------------------------------------------
   Last opp tegningen, sett målestokken ved å klikke to punkter du vet
   avstanden mellom, og tegn rommene rett oppå tegningen. Da bygges
   3D-rommet direkte fra tegningen — ikke bare fra tastede mål.
   ================================================================ */

const T = {
  rot: { display: 'grid', gap: 10, background: '#FBFBF9', color: '#1C2321', borderRadius: 12, padding: 12 }, // lyst papir: tekstene her er laget for lys bakgrunn (før var de mørke på mørkt kort)
  tittel: { fontSize: 14, fontWeight: 700, color: '#1C2321' },
  tekst: { fontSize: 13, lineHeight: 1.5, color: '#3A443E' },
  smaa: { fontSize: 11, color: '#8A938C', lineHeight: 1.4 },
  flate: { border: '1px solid #DDE2DC', borderRadius: 12, overflow: 'hidden', background: '#F6F7F4', position: 'relative' },
  knapp: { padding: '9px 12px', borderRadius: 10, border: 'none', background: '#2F5F55', color: '#fff', fontSize: 13, fontWeight: 700, cursor: 'pointer' },
  knappSek: { padding: '9px 12px', borderRadius: 10, border: '1px solid #C8D0C8', background: '#fff', color: '#1C2321', fontSize: 13, fontWeight: 600, cursor: 'pointer' },
  rad: { display: 'flex', gap: 8, flexWrap: 'wrap' },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))', gap: 8 },
  felt: { display: 'grid', gap: 4, fontSize: 11, color: '#5C665E' },
  inn: { padding: '8px 9px', borderRadius: 8, border: '1px solid #C8D0C8', fontSize: 13, background: '#fff', width: '100%' },
  boks: { border: '1px solid #E3E7E2', borderRadius: 10, padding: 10, display: 'grid', gap: 8, background: '#fff' },
  merke: { fontSize: 11, fontWeight: 700, color: '#2F5F55' },
};

const tall = (v, f = 0) => (Number.isFinite(Number(v)) ? Number(v) : f);
const rund = (v, d = 2) => Math.round(tall(v) * 10 ** d) / 10 ** d;
const nyId = () => 'bt-' + Math.random().toString(36).slice(2, 9);

/* Fagjobbene som kan regnes rett ut av arealet i tegningen. Id-ene er de
   samme som prisjobbene i 3D-rommet, sa totalsummen blir den samme. */
export const JOBBVALG = [
  { id: 'gulvbelegg', navn: 'Gulvbelegg' },
  { id: 'gulvvarme', navn: 'Gulvvarme' },
  { id: 'avretting', navn: 'Avretting' },
  { id: 'maling', navn: 'Maling av vegger' },
  { id: 'gips', navn: 'Gips og sparkling' },
  { id: 'fliser', navn: 'Flislegging' },
];

function Felt({ label, value, onChange, step = '0.1', type = 'number' }) {
  return (
    <label style={T.felt}>
      {label}
      <input style={T.inn} type={type} inputMode={type === 'number' ? 'decimal' : undefined} step={step}
        value={value} onChange={(e) => onChange(e.target.value)} />
    </label>
  );
}

/**
 * Tegner opp hele bygget fra en opplastet tegning.
 * onBygg({ rom, apninger, takhoyde, tak, underlag }) sender resultatet videre
 * til 3D-rommet.
 */
export default function Byggtegning({ onBygg }) {
  const [bilde, setBilde] = useState(null); // { url, navn, w, h }
  const [modus, setModus] = useState('kalibrer'); // kalibrer | tegn
  const [kalP, setKalP] = useState([]); // to punkter i tegningens piksler
  const [kalMeter, setKalMeter] = useState('5');
  const [skala, setSkala] = useState(0); // meter per piksel
  const [utkast, setUtkast] = useState([]);
  const [rom, setRom] = useState([]);
  const [apninger, setApninger] = useState([]);
  const [takhoyde, setTakhoyde] = useState('2.4');
  const [takform, setTakform] = useState('saltak');
  const [takvinkel, setTakvinkel] = useState('30');
  const [manNavn, setManNavn] = useState('');
  const [manBredde, setManBredde] = useState('4');
  const [manLengde, setManLengde] = useState('3');
  const [jobbValg, setJobbValg] = useState(['gulvbelegg', 'maling', 'gips']);
  const svgRef = useRef(null);


  const lastOpp = (fil) => {
    if (!fil) return;
    const leser = new FileReader();
    leser.onload = () => {
      const url = String(leser.result || '');
      const img = new Image();
      img.onload = () => setBilde({ url, navn: fil.name, w: img.width || 1000, h: img.height || 750 });
      img.onerror = () => setBilde({ url, navn: fil.name, w: 1000, h: 750 });
      img.src = url;
    };
    leser.readAsDataURL(fil);
  };

  const tilPiksel = (e) => {
    const svg = svgRef.current;
    if (!svg || !svg.createSVGPoint) return null;
    const pt = svg.createSVGPoint();
    pt.x = e.clientX; pt.y = e.clientY;
    const ctm = svg.getScreenCTM();
    if (!ctm) return null;
    const p = pt.matrixTransform(ctm.inverse());
    return { x: p.x, y: p.y };
  };

  const trykk = (e) => {
    const p = tilPiksel(e);
    if (!p) return;
    if (modus === 'kalibrer') {
      setKalP((liste) => (liste.length >= 2 ? [p] : [...liste, p]));
      return;
    }
    if (!skala) return;
    if (utkast.length >= 3) {
      const d = Math.hypot(p.x - utkast[0].x, p.y - utkast[0].y);
      if (d < Math.max(12, bilde.w * 0.02)) { lukkRom(); return; }
    }
    setUtkast((u) => [...u, p]);
  };

  const settMaalestokk = () => {
    if (kalP.length < 2) return;
    const px = Math.hypot(kalP[1].x - kalP[0].x, kalP[1].y - kalP[0].y);
    const m = tall(kalMeter);
    if (px < 1 || m <= 0) return;
    setSkala(m / px);
    setModus('tegn');
  };

  const lukkRom = () => {
    if (utkast.length < 3 || !skala) return;
    const punkter = utkast.map((p) => ({ x: rund(p.x * skala), y: rund(p.y * skala) }));
    setRom((liste) => [...liste, { id: nyId(), navn: 'Rom ' + (liste.length + 1), punkter }]);
    setUtkast([]);
  };

  /* Mål fra tegningen kan ogsa tastes inn direkte: mange tegninger har
     malene skrevet pa, og da slipper du a klikke hjornene. */
  const leggTilMaaltRom = () => {
    const b = Math.max(0.5, tall(manBredde, 0));
    const l = Math.max(0.5, tall(manLengde, 0));
    if (b < 0.5 || l < 0.5) return;
    const forskyv = rom.length * 0.0;
    setRom((liste) => [...liste, {
      id: nyId(),
      navn: manNavn.trim() || 'Rom ' + (liste.length + 1),
      punkter: [
        { x: forskyv, y: 0 }, { x: rund(forskyv + b), y: 0 },
        { x: rund(forskyv + b), y: rund(l) }, { x: forskyv, y: rund(l) },
      ],
    }]);
    setManNavn('');
  };

  const velgJobb = (id) =>
    setJobbValg((liste) => (liste.includes(id) ? liste.filter((x) => x !== id) : [...liste, id]));


  const veggerIRom = (r) => r.punkter.map((p, i) => {
    const q = r.punkter[(i + 1) % r.punkter.length];
    return { i, lengde: rund(Math.hypot(q.x - p.x, q.y - p.y)) };
  });

  const leggTilApning = (romId, type) => {
    setApninger((liste) => [...liste, {
      id: nyId(), romId, type, veggIndeks: 0, pos: 0.5,
      b: type === 'Dør' ? 0.9 : 1.2, h: type === 'Dør' ? 2.1 : 1.2, brystning: type === 'Dør' ? 0 : 0.9,
    }]);
  };
  const endreApning = (id, felt, verdi) =>
    setApninger((liste) => liste.map((a) => (a.id === id ? { ...a, [felt]: felt === 'type' ? verdi : tall(verdi) } : a)));
  const fjernApning = (id) => setApninger((liste) => liste.filter((a) => a.id !== id));

  const bygg = () => {
    if (!rom.length || !onBygg) return;
    onBygg({
      rom: rom.map((r) => ({ ...r, punkter: r.punkter.map((p) => ({ ...p })) })),
      apninger: apninger.map((a) => ({ ...a })),
      takhoyde: Math.max(1.8, tall(takhoyde, 2.4)),
      tak: { type: takform, bredde: rund(bygningsMaal().bredde), lengde: rund(bygningsMaal().dybde), takvinkel: tall(takvinkel, 30), snolast: 3.5, svinn: 12 },
      underlag: bilde && skala ? {
        url: bilde.url, navn: bilde.navn, bredde: rund(bilde.w * skala),
        forhold: bilde.h / Math.max(1, bilde.w), x: 0, y: 0, opacity: 0.55,
      } : null,
      prisjobber: [...jobbValg],

    });
  };

  const bygningsMaal = () => {
    const alle = rom.flatMap((r) => r.punkter);
    if (!alle.length) return { bredde: 6, dybde: 9 };
    const xs = alle.map((p) => p.x); const ys = alle.map((p) => p.y);
    return { bredde: Math.max(1, Math.max(...xs) - Math.min(...xs)), dybde: Math.max(1, Math.max(...ys) - Math.min(...ys)) };
  };

  const maal = bygningsMaal();
  const strek = Math.max(1.5, (bilde ? bilde.w : 800) / 400);

  return (
    <div style={T.rot} data-tf="byggtegning-modul">
      <div style={T.tekst}>
        Last opp hele byggtegningen din — plan, fasade eller snitt. Sett målestokken ved å klikke to punkter
        du vet avstanden mellom, tegn rommene rett på tegningen, og bygg 3D-rommet med ett trykk.
      </div>
      {/* Norsk knapp i stedet for nettleserens egen «Choose File / No file chosen». */}
      <label style={{ ...T.knapp, textAlign: 'center', display: 'block' }}>
        📄 Last opp byggtegningen
        <input type="file" accept="image/*" style={{ display: 'none' }} aria-label="Last opp hele byggtegningen"
          onChange={(e) => { lastOpp(e.target.files && e.target.files[0]); e.target.value = ''; }} />
      </label>

      <div style={T.boks} data-tf="byggtegning-maal">
        <div style={T.tittel}>Legg inn mål fra tegningen</div>
        <div style={T.smaa}>Står målene allerede på tegningen? Skriv dem inn her, så bygges rommet uten klikking.</div>
        <div style={T.grid}>
          <label style={T.felt}>
            Rommets navn
            <input style={T.inn} value={manNavn} placeholder="Stue" onChange={(e) => setManNavn(e.target.value)} />
          </label>
          <Felt label="Bredde (m)" value={manBredde} onChange={setManBredde} />
          <Felt label="Lengde (m)" value={manLengde} onChange={setManLengde} />
        </div>
        <button type="button" style={T.knappSek} data-tf="legg-til-maalt-rom" onClick={leggTilMaaltRom}>
          Legg rommet inn fra målene
        </button>
      </div>


      {bilde ? (
        <>
          <div style={T.rad}>
            <button type="button" style={modus === 'kalibrer' ? T.knapp : T.knappSek}
              onClick={() => { setModus('kalibrer'); setKalP([]); }}>1 · Sett målestokk</button>
            <button type="button" style={modus === 'tegn' ? T.knapp : T.knappSek}
              onClick={() => skala && setModus('tegn')}>2 · Tegn rom</button>
          </div>

          {modus === 'kalibrer' ? (
            <div style={T.boks}>
              <div style={T.smaa}>Klikk to punkter på tegningen (for eksempel et kjent veggløp), og skriv inn hvor langt det er i virkeligheten.</div>
              <div style={T.grid}>
                <Felt label="Virkelig avstand (m)" value={kalMeter} onChange={setKalMeter} />
              </div>
              <button type="button" style={T.knapp} disabled={kalP.length < 2} onClick={settMaalestokk}>
                {kalP.length < 2 ? 'Klikk ' + (2 - kalP.length) + ' punkt til' : 'Bruk denne målestokken'}
              </button>
            </div>
          ) : (
            <div style={T.boks}>
              <div style={T.smaa}>Klikk hjørnene i rommet. Klikk på det første punktet igjen for å lukke rommet — veggene følger automatisk.</div>
              <div style={T.rad}>
                <button type="button" style={T.knappSek} onClick={() => setUtkast([])}>Nullstill punktene</button>
                <button type="button" style={T.knapp} disabled={utkast.length < 3} onClick={lukkRom}>Lukk rommet</button>
              </div>
            </div>
          )}

          <div style={T.flate}>
            <svg ref={svgRef} viewBox={'0 0 ' + bilde.w + ' ' + bilde.h} style={{ width: '100%', display: 'block', touchAction: 'manipulation' }}
              onPointerDown={trykk} role="application" aria-label="Byggtegning å tegne rom på">
              <image href={bilde.url} x="0" y="0" width={bilde.w} height={bilde.h} />
              {kalP.length ? (
                <g>
                  {kalP.map((p, i) => <circle key={i} cx={p.x} cy={p.y} r={strek * 3} fill="#E3B341" stroke="#1C2321" strokeWidth={strek * 0.6} />)}
                  {kalP.length === 2 ? <line x1={kalP[0].x} y1={kalP[0].y} x2={kalP[1].x} y2={kalP[1].y} stroke="#E3B341" strokeWidth={strek} /> : null}
                </g>
              ) : null}
              {rom.map((r) => (
                <polygon key={r.id} points={r.punkter.map((p) => (p.x / (skala || 1)) + ',' + (p.y / (skala || 1))).join(' ')}
                  fill="rgba(47,95,85,0.22)" stroke="#2F5F55" strokeWidth={strek * 1.4} />
              ))}
              {utkast.length ? (
                <polyline points={utkast.map((p) => p.x + ',' + p.y).join(' ')} fill="none" stroke="#2F5F55" strokeWidth={strek * 1.4} strokeDasharray={strek * 4} />
              ) : null}
              {utkast.map((p, i) => <circle key={i} cx={p.x} cy={p.y} r={strek * 2.6} fill="#fff" stroke="#2F5F55" strokeWidth={strek} />)}
            </svg>
          </div>
          {skala ? <div style={T.merke}>Målestokk satt: 1 piksel = {rund(skala, 4)} m · tegningen er {rund(bilde.w * skala)} m bred</div> : null}
        </>
      ) : null}

      {rom.length ? (
        <div style={T.boks} data-tf="byggtegning-rom">
          <div style={T.tittel}>Rom fra tegningen</div>
          {rom.map((r) => (
            <div key={r.id} style={{ display: 'grid', gap: 6, borderTop: '1px solid #EDF0EC', paddingTop: 8 }}>
              <div style={T.rad}>
                <input style={{ ...T.inn, flex: 1, minWidth: 120 }} value={r.navn}
                  aria-label="Navn på rommet"
                  onChange={(e) => setRom((liste) => liste.map((x) => (x.id === r.id ? { ...x, navn: e.target.value } : x)))} />
                <button type="button" style={T.knappSek} onClick={() => { setRom((liste) => liste.filter((x) => x.id !== r.id)); setApninger((liste) => liste.filter((a) => a.romId !== r.id)); }}>Fjern</button>
              </div>
              <div style={T.smaa}>
                {r.punkter.length} hjørner · vegger: {veggerIRom(r).map((v) => v.lengde + ' m').join(' · ')}
              </div>
              <div style={T.rad}>
                <button type="button" style={T.knappSek} onClick={() => leggTilApning(r.id, 'Vindu')}>+ Vindu</button>
                <button type="button" style={T.knappSek} onClick={() => leggTilApning(r.id, 'Dør')}>+ Dør</button>
              </div>
              {apninger.filter((a) => a.romId === r.id).map((a) => (
                <div key={a.id} style={{ ...T.grid, alignItems: 'end', borderTop: '1px dashed #E3E7E2', paddingTop: 6 }}>
                  <label style={T.felt}>
                    {a.type} på vegg
                    <select style={T.inn} value={a.veggIndeks} onChange={(e) => endreApning(a.id, 'veggIndeks', e.target.value)}>
                      {veggerIRom(r).map((v) => <option key={v.i} value={v.i}>Vegg {v.i + 1} · {v.lengde} m</option>)}
                    </select>
                  </label>
                  <Felt label="Fra hjørnet (m)" value={a.pos} onChange={(v) => endreApning(a.id, 'pos', v)} />
                  <Felt label="Bredde (m)" value={a.b} onChange={(v) => endreApning(a.id, 'b', v)} />
                  <Felt label="Høyde (m)" value={a.h} onChange={(v) => endreApning(a.id, 'h', v)} />
                  <Felt label="Brystning (m)" value={a.brystning} onChange={(v) => endreApning(a.id, 'brystning', v)} />
                  <button type="button" style={T.knappSek} onClick={() => fjernApning(a.id)}>Fjern</button>
                </div>
              ))}
            </div>
          ))}
        </div>
      ) : null}

      <div style={T.boks}>
        <div style={T.tittel}>Takhøyde og takform</div>
        <div style={T.grid}>
          <Felt label="Takhøyde (m)" value={takhoyde} onChange={setTakhoyde} />
          <label style={T.felt}>
            Takform
            <select style={T.inn} value={takform} onChange={(e) => setTakform(e.target.value)}>
              <option value="saltak">Saltak</option>
              <option value="pulttak">Pulttak</option>
            </select>
          </label>
          <Felt label="Takvinkel (grader)" value={takvinkel} step="1" onChange={setTakvinkel} />
        </div>
        <div style={T.smaa}>Bygget måler {rund(maal.bredde)} × {rund(maal.dybde)} m etter tegningen.</div>
      </div>

      <div style={T.boks} data-tf="byggtegning-fagjobber">
        <div style={T.tittel}>Fagjobber som skal regnes med</div>
        <div style={T.smaa}>Jobbene regnes ut fra arealet i tegningen og legges inn i totalsummen i 3D.</div>
        <div style={T.grid}>
          {JOBBVALG.map((j) => (
            <label key={j.id} style={{ ...T.felt, flexDirection: 'row', display: 'flex', gap: 6, alignItems: 'center', fontSize: 12, color: '#1C2321' }}>
              <input type="checkbox" checked={jobbValg.includes(j.id)} onChange={() => velgJobb(j.id)} />
              {j.navn}
            </label>
          ))}
        </div>
      </div>


      <button type="button" style={{ ...T.knapp, opacity: rom.length ? 1 : 0.5 }} disabled={!rom.length}
        data-tf="bygg-3d-fra-tegning" onClick={bygg}>
        Bygg 3D-rommet fra tegningen
      </button>
      {!rom.length ? <div style={T.smaa}>Last opp tegningen, sett målestokk og tegn minst ett rom.</div> : null}
    </div>
  );
}
