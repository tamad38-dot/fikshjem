import React from 'react';
import fasadeSkannFoto from '../assets/fiks-hjem-facade-scan.jpg';

/* ================================================================
   FASADE — TEKNISK TEGNING FØR OG ETTER
   ----------------------------------------------------------------
   Du skanner fasaden med LiDAR (eller tar et bilde og fyller inn bredde
   og høyde), plasserer vinduer og dører, og merker hva som fjernes eller
   kommer nytt. Appen tegner da to målsatte fasadeoppriss i målestokk
   1:100 — eksisterende og ny — med tittelfelt, klare til utskrift og
   levering til byggesaksavdelingen i kommunen.

   Tegningen er et arbeidsdokument. Målene er dine egne; kommunen kan
   kreve ansvarlig søker for søknadspliktige tiltak.
   ================================================================ */

export const TOM_FASADE = {
  navn: 'Fasade mot sør',
  adresse: '',
  gnr: '',
  bnr: '',
  kommune: '',
  tiltak: 'Nytt vindu i fasaden',
  bredde: 8,
  hoyde: 5.4,
  raft: 2.7,
  foto: null,
  elementer: [],
};

export const FASADE_ELEMENTTYPER = ['Vindu', 'Dør', 'Takvindu'];
export const FASADE_STATUS = [
  { v: 'beholdes', t: 'Beholdes' },
  { v: 'fjernes', t: 'Fjernes / mures igjen' },
  { v: 'ny', t: 'Nytt' },
];

const n = (v, f = 0) => (Number.isFinite(Number(String(v).replace(',', '.'))) ? Number(String(v).replace(',', '.')) : f);
const esc = (v) => String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

/** Bygger fasadeopprisset som en SVG-streng, slik at samme tegning kan
    vises i appen og skrives ut uten å tegnes to ganger. */
export function fasadeSvg(fasade, variant) {
  const bredde = Math.max(1, n(fasade.bredde, 8));
  const hoyde = Math.max(1, n(fasade.hoyde, 5));
  const raft = Math.min(hoyde, Math.max(0.5, n(fasade.raft, hoyde * 0.6)));
  const M = 46; // marg i tegneenheter
  const skala = 60; // 1 m = 60 enheter
  const w = bredde * skala;
  const h = hoyde * skala;
  const vb = `0 0 ${w + M * 2} ${h + M * 2}`;
  const x0 = M;
  const y0 = M;
  const yBunn = y0 + h;
  const yRaft = yBunn - raft * skala;
  const linje = 'stroke="#1C2321" fill="none" stroke-width="2"';
  const tynn = 'stroke="#5C665E" fill="none" stroke-width="1"';

  const elementer = (fasade.elementer || []).filter((e) =>
    variant === 'for' ? e.status !== 'ny' : e.status !== 'fjernes');

  const tegnElement = (e, indeks) => {
    const eb = Math.max(0.1, n(e.b, 1)) * skala;
    const eh = Math.max(0.1, n(e.h, 1)) * skala;
    const ex = x0 + Math.max(0, n(e.x, 0)) * skala;
    const ey = yBunn - (Math.max(0, n(e.y, 0)) * skala + eh);
    const fjernes = variant === 'for' && e.status === 'fjernes';
    const nytt = variant === 'etter' && e.status === 'ny';
    const farge = fjernes ? '#B4553F' : nytt ? '#2F5F55' : '#1C2321';
    const dash = fjernes ? ' stroke-dasharray="7 5"' : '';
    const nr = indeks + 1;
    const malY = Math.min(yBunn - 5, ey + eh + 13);
    return (
      `<rect x="${ex}" y="${ey}" width="${eb}" height="${eh}" fill="${nytt ? '#E7F0EC' : '#F2F5F1'}" stroke="${farge}" stroke-width="2"${dash} />` +
      `<line x1="${ex + 5}" y1="${ey + 5}" x2="${ex + eb - 5}" y2="${ey + eh - 5}" ${tynn} />` +
      `<line x1="${ex + eb - 5}" y1="${ey + 5}" x2="${ex + 5}" y2="${ey + eh - 5}" ${tynn} />` +
      `<circle cx="${ex + 12}" cy="${ey + 12}" r="9" fill="#E3B341" stroke="#1C2321" stroke-width="1" />` +
      `<text x="${ex + 12}" y="${ey + 15}" text-anchor="middle" font-size="9" font-weight="700" fill="#1C2321">${nr}</text>` +
      `<text x="${ex + eb / 2}" y="${ey - 7}" text-anchor="middle" font-size="12" fill="${farge}">` +
      `${nr}. ${esc(e.type)} ${n(e.b, 1).toFixed(2)}×${n(e.h, 1).toFixed(2)}${fjernes ? ' (fjernes)' : nytt ? ' (nytt)' : ''}</text>` +
      `<line x1="${ex}" y1="${malY}" x2="${ex + eb}" y2="${malY}" stroke="#5C665E" stroke-width="1" />` +
      `<line x1="${ex}" y1="${malY - 4}" x2="${ex}" y2="${malY + 4}" stroke="#5C665E" stroke-width="1" />` +
      `<line x1="${ex + eb}" y1="${malY - 4}" x2="${ex + eb}" y2="${malY + 4}" stroke="#5C665E" stroke-width="1" />`
    );
  };

  return (
    `<svg viewBox="${vb}" xmlns="http://www.w3.org/2000/svg" width="100%" role="img" ` +
    `aria-label="Fasadeoppriss ${variant === 'for' ? 'eksisterende' : 'ny'}" style="background:#fff">` +
    `<rect x="${x0}" y="${y0}" width="${w}" height="${h}" fill="#FBFBF8" ${linje} />` +
    `<line x1="${x0}" y1="${yRaft}" x2="${x0 + w}" y2="${yRaft}" ${tynn} stroke-dasharray="6 4" />` +
    `<polyline points="${x0},${yRaft} ${x0 + w / 2},${y0} ${x0 + w},${yRaft}" ${linje} />` +
    elementer.map(tegnElement).join('') +
    `<line x1="${x0}" y1="${yBunn + 22}" x2="${x0 + w}" y2="${yBunn + 22}" ${tynn} />` +
    `<text x="${x0 + w / 2}" y="${yBunn + 38}" text-anchor="middle" font-size="14" fill="#1C2321">${bredde.toFixed(2)} m</text>` +
    `<line x1="${x0 - 22}" y1="${y0}" x2="${x0 - 22}" y2="${yBunn}" ${tynn} />` +
    `<text x="${x0 - 28}" y="${y0 + h / 2}" text-anchor="end" font-size="14" fill="#1C2321">${hoyde.toFixed(2)} m</text>` +
    `<text x="${x0 + 6}" y="${yRaft - 6}" font-size="12" fill="#5C665E">Raft ${raft.toFixed(2)} m · kote ±0,00 ved bakken</text>` +
    `<text x="${x0}" y="${y0 - 14}" font-size="15" font-weight="700" fill="#1C2321">` +
    `${variant === 'for' ? 'Eksisterende fasade' : 'Ny fasade'}</text>` +
    `</svg>`
  );
}

/** Komplett utskriftsdokument med begge tegningene og tittelfelt. */
export function fasadeUtskriftHtml(fasade) {
  const dato = new Date().toLocaleDateString('no-NO');
  const rad = (m, v) => `<tr><td>${esc(m)}</td><td>${esc(v || '—')}</td></tr>`;
  const elementTabell = (fasade.elementer || []).map((e, i) =>
    `<tr><td>${i + 1}</td><td>${esc(e.type)}</td><td>${esc(FASADE_STATUS.find((s) => s.v === e.status)?.t || e.status)}</td>` +
    `<td>${n(e.b, 1).toFixed(2)} × ${n(e.h, 1).toFixed(2)} m</td><td>${n(e.x, 0).toFixed(2)} m</td><td>${n(e.y, 0).toFixed(2)} m</td></tr>`
  ).join('');
  return (
    '<!doctype html><html lang="no"><head><meta charset="utf-8">' +
    `<title>Fasadetegning ${esc(fasade.navn || '')}</title><style>` +
    'body{font:13px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;color:#1C2321;margin:24px;}' +
    'h1{font-size:19px;margin:0 0 2px;} .meta{color:#8A938C;font-size:12px;margin-bottom:16px;}' +
    '.ark{border:1px solid #1C2321;padding:14px;margin-bottom:18px;break-inside:avoid;}' +
    'table{border-collapse:collapse;width:100%;max-width:520px;margin-top:10px;}' +
    'td{border:1px solid #C8D0C8;padding:5px 8px;} td:first-child{color:#5C665E;width:38%;}' +
    '@media print{body{margin:0;padding:12mm;} .ark{border:2pt solid #000;} svg{filter:grayscale(1);}}' +
    '</style></head><body>' +
    `<h1>Fasadetegning — ${esc(fasade.navn || 'fasade')}</h1>` +
    `<div class="meta">Målestokk 1:100 ved utskrift i A4 · ${esc(dato)}</div>` +
    `<div class="ark">${fasadeSvg(fasade, 'for')}</div>` +
    `<div class="ark">${fasadeSvg(fasade, 'etter')}</div>` +
    '<h2 style="font-size:15px;margin:0">Elementliste</h2>' +
    '<table><thead><tr><td>Nr.</td><td>Type</td><td>Status</td><td>B × H</td><td>Fra venstre</td><td>Over bakken</td></tr></thead><tbody>' +
    (elementTabell || '<tr><td colspan="6">Ingen vinduer eller dører er registrert.</td></tr>') + '</tbody></table>' +
    '<h2 style="font-size:15px;margin:0">Tittelfelt</h2>' +
    '<table>' +
    rad('Tiltak', fasade.tiltak) +
    rad('Adresse', fasade.adresse) +
    rad('Gnr/Bnr', [fasade.gnr, fasade.bnr].filter(Boolean).join('/')) +
    rad('Kommune', fasade.kommune) +
    rad('Fasadebredde', n(fasade.bredde, 0).toFixed(2) + ' m') +
    rad('Fasadehøyde (møne)', n(fasade.hoyde, 0).toFixed(2) + ' m') +
    rad('Raftehøyde', n(fasade.raft, 0).toFixed(2) + ' m') +
    rad('Dato', dato) +
    '</table>' +
    '<p style="margin-top:16px;font-size:11px;color:#8A938C;max-width:520px">' +
    'Slik leses tegningen: Nummeret i sirkelen viser til elementlisten. Stiplet omriss i eksisterende fasade betyr at elementet fjernes. ' +
    'Alle mål er i meter. Tegningen er laget av eier med målene som er lagt inn i appen, og er et arbeidsdokument til byggesaken. ' +
    'Søknadspliktige tiltak kan kreve ansvarlig søker. Kontroller målene før innsending.' +
    '</p></body></html>'
  );
}

/** Åpner systemets utskrift med fasadetegningene. */
export function skrivUtFasade(fasade, delRapport, melding) {
  const html = fasadeUtskriftHtml(fasade);
  if (typeof delRapport === 'function') { delRapport(html); return true; }
  if (typeof document === 'undefined') return false;
  try {
    const ramme = document.createElement('iframe');
    ramme.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
    document.body.appendChild(ramme);
    const doc = ramme.contentDocument;
    doc.open(); doc.write(html); doc.close();
    ramme.contentWindow.focus();
    ramme.contentWindow.print();
    setTimeout(() => ramme.remove(), 1500);
    return true;
  } catch (e) {
    if (melding) melding('Utskrift er ikke tilgjengelig i dette vinduet. I den ferdige appen åpner knappen systemets utskrift, der du også kan lagre som PDF.');
    return false;
  }
}

const T = {
  ark: { border: '1px solid #DDE2DC', borderRadius: 12, padding: 10, background: '#fff', overflow: 'hidden' },
  smaa: { fontSize: 11, color: '#8A938C', lineHeight: 1.45 },
  navn: { fontSize: 13, fontWeight: 700, color: '#1C2321' },
  rad: { border: '1px solid #EDF0EC', borderRadius: 10, padding: 8, display: 'grid', gap: 6, background: '#FBFBF8' },
  felt: { display: 'grid', gap: 3, fontSize: 11, color: '#5C665E' },
  input: { padding: '7px 8px', borderRadius: 8, border: '1px solid #C8D0C8', fontSize: 13, background: '#fff', width: '100%', boxSizing: 'border-box' },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))', gap: 8 },
  knapp: { padding: '9px 12px', borderRadius: 10, border: 'none', background: '#2F5F55', color: '#fff', fontSize: 13, fontWeight: 700, cursor: 'pointer' },
  knappSek: { padding: '9px 12px', borderRadius: 10, border: '1px solid #C8D0C8', background: '#fff', color: '#1C2321', fontSize: 13, fontWeight: 600, cursor: 'pointer' },
  foto: { width: '100%', maxHeight: 180, objectFit: 'cover', borderRadius: 10, display: 'block' },
};

function Felt({ label, value, onChange, type = 'text', step }) {
  // Tallfelt: tekstfelt med talltastatur og eget visningsfelt, så «5,4» kan skrives
  // ferdig selv om forelderen gjør verdien om til tall for hvert tastetrykk.
  const tallFelt = type === 'number';
  const vis0 = (v) => (v == null ? '' : String(v).replace('.', ','));
  const [vis, setVis] = React.useState(() => vis0(value));
  React.useEffect(() => {
    if (!tallFelt) return;
    setVis((g) => (n(g, NaN) === n(value, NaN) || (g === '' && (value === '' || value == null)) ? g : vis0(value)));
  }, [value, tallFelt]);
  return (
    <label style={T.felt}>
      <span>{label}</span>
      <input style={T.input} type={tallFelt ? 'text' : type} inputMode={tallFelt ? 'decimal' : undefined} autoComplete="off"
        value={tallFelt ? vis : (value == null ? '' : value)}
        onChange={(e) => {
          if (!tallFelt) { onChange(e.target.value); return; }
          const raa = e.target.value.replace(/[^0-9,.]/g, '');
          setVis(raa);
          onChange(raa.replace(',', '.'));
        }} />
    </label>
  );
}

export function FasadeTegning({ fasade, onEndre, onElement, onLeggTil, onFjernElement, onFoto, onSkann, skannTilgjengelig, skannBusy, onSkrivUt }) {
  const synligeElementer = (fasade.elementer || []);
  return (
    // Lyst papir: tekstene her er laget for lys bakgrunn (før var de mørke på mørkt kort).
    <div style={{ display: 'grid', gap: 12, background: '#FBFBF9', color: '#1C2321', borderRadius: 12, padding: 12 }} data-tf="fasade-tegning">
      <div style={T.smaa}>
        Ta et bilde av fasaden med mobilen, fyll inn bredde og høyde, og legg inn vinduene og dørene.
        Appen tegner både eksisterende og ny fasade med mål og tittelfelt, klar til utskrift for kommunen.
      </div>
      <img src={fasade.foto || fasadeSkannFoto} alt="Fasaden som skal tegnes" loading="lazy" style={T.foto} />
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        {skannTilgjengelig ? (
          <button type="button" style={{ ...T.knapp, opacity: skannBusy ? 0.6 : 1 }} disabled={skannBusy} onClick={onSkann}>
            {skannBusy ? 'Skanner…' : 'Skann fasaden med LiDAR'}
          </button>
        ) : null}
        <label style={{ ...T.knappSek, display: 'inline-block' }}>
          📷 Ta bilde av fasaden
          <input type="file" accept="image/*" capture="environment" style={{ display: 'none' }}
            onChange={(e) => { onFoto(e.target.files && e.target.files[0]); e.target.value = ''; }} />
        </label>
      </div>

      <div style={T.grid}>
        <Felt label="Navn på fasaden" value={fasade.navn} onChange={(v) => onEndre('navn', v)} />
        <Felt label="Tiltak" value={fasade.tiltak} onChange={(v) => onEndre('tiltak', v)} />
        <Felt label="Adresse" value={fasade.adresse} onChange={(v) => onEndre('adresse', v)} />
        <Felt label="Kommune" value={fasade.kommune} onChange={(v) => onEndre('kommune', v)} />
        <Felt label="Gnr" value={fasade.gnr} onChange={(v) => onEndre('gnr', v)} />
        <Felt label="Bnr" value={fasade.bnr} onChange={(v) => onEndre('bnr', v)} />
        <Felt label="Fasadebredde (m)" type="number" step="0.1" value={fasade.bredde} onChange={(v) => onEndre('bredde', v)} />
        <Felt label="Høyde til møne (m)" type="number" step="0.1" value={fasade.hoyde} onChange={(v) => onEndre('hoyde', v)} />
        <Felt label="Raftehøyde (m)" type="number" step="0.1" value={fasade.raft} onChange={(v) => onEndre('raft', v)} />
      </div>

      <div style={{ display: 'grid', gap: 8 }}>
        <div style={T.navn}>Vinduer og dører i fasaden</div>
        {synligeElementer.map((e, indeks) => (
          <div key={e.id} style={T.rad}>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <span style={{ width: 24, height: 24, flex: '0 0 auto', display: 'grid', placeItems: 'center', borderRadius: '50%', background: '#E3B341', color: '#1C2321', fontSize: 11, fontWeight: 800 }}>{indeks + 1}</span>
              <select style={{ ...T.input, flex: 1 }} value={e.type} aria-label="Type"
                onChange={(ev) => onElement(e.id, 'type', ev.target.value)}>
                {FASADE_ELEMENTTYPER.map((t) => <option key={t} value={t}>{t}</option>)}
              </select>
              <select style={{ ...T.input, flex: 1 }} value={e.status} aria-label="Status"
                onChange={(ev) => onElement(e.id, 'status', ev.target.value)}>
                {FASADE_STATUS.map((s) => <option key={s.v} value={s.v}>{s.t}</option>)}
              </select>
              <button type="button" style={T.knappSek} onClick={() => onFjernElement(e.id)} aria-label="Slett elementet">×</button>
            </div>
            <div style={T.grid}>
              <Felt label="Bredde (m)" type="number" step="0.1" value={e.b} onChange={(v) => onElement(e.id, 'b', v)} />
              <Felt label="Høyde (m)" type="number" step="0.1" value={e.h} onChange={(v) => onElement(e.id, 'h', v)} />
              <Felt label="Fra venstre (m)" type="number" step="0.1" value={e.x} onChange={(v) => onElement(e.id, 'x', v)} />
              <Felt label="Over bakken (m)" type="number" step="0.1" value={e.y} onChange={(v) => onElement(e.id, 'y', v)} />
            </div>
          </div>
        ))}
        <button type="button" style={T.knappSek} onClick={onLeggTil}>+ Legg til vindu eller dør</button>
      </div>

      <div style={T.ark} dangerouslySetInnerHTML={{ __html: fasadeSvg(fasade, 'for') }} />
      <div style={T.ark} dangerouslySetInnerHTML={{ __html: fasadeSvg(fasade, 'etter') }} />

      <div style={{ ...T.ark, display: 'grid', gap: 7 }} aria-label="Tegnforklaring">
        <div style={T.navn}>Slik leser du tegningen</div>
        <div style={T.smaa}>Nummeret på tegningen er det samme som nummeret i listen over. B × H betyr bredde × høyde.</div>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', fontSize: 11, color: '#1C2321' }}>
          <span><b style={{ color: '#1C2321' }}>Heltrukket:</b> beholdes</span>
          <span><b style={{ color: '#B4553F' }}>Stiplet rød:</b> fjernes</span>
          <span><b style={{ color: '#2F5F55' }}>Grønn:</b> nytt</span>
        </div>
        <div style={T.smaa}>Kontroller fasadebredde, mønehøyde, raftehøyde og alle avstander før utskrift.</div>
      </div>

      <button type="button" style={T.knapp} onClick={onSkrivUt}>Skriv ut fasadetegningen (PDF)</button>
      <div style={T.smaa}>
        Tegningen skrives ut i målestokk 1:100 på A4 med tittelfelt for adresse, gnr/bnr, kommune og dato.
        Søknadspliktige endringer kan kreve ansvarlig søker — sjekk med kommunen før innsending.
      </div>
    </div>
  );
}
