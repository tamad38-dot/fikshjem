import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Canvas, useThree } from '@react-three/fiber';
import { Environment, Html, Lightformer, Line, OrbitControls, useTexture } from '@react-three/drei';
import * as THREE from 'three';
import { FERDIGMODULER, ModulTegning } from './ferdigmoduler';
import roofTilesPhoto from '../assets/fiks-hjem-roof-tiles-texture.jpg';
import roofBattensPhoto from '../assets/fiks-hjem-roof-battens-texture.jpg';

const COLORS = {
  background: '#e8e5dc',
  floor: '#c9d6cb',
  floorSelected: '#b4c9b8',
  wall: '#ddd7ca',
  wallEdge: '#5b5a54',
  measure: '#2f5f55',
  selected: '#d4af37',
  opening: '#5790a6',
  door: '#9b5949',
  timber: '#9b7248',
  module: '#657b68',
};

const MODULE_DEFAULTS = {
  vegg: { navn: 'Vegg', bredde: 2.4, hoyde: 2.4, dybde: 0.1 },
  gulv: { navn: 'Gulv', bredde: 2, hoyde: 0.08, dybde: 2 },
  trapp: { navn: 'Trapp', bredde: 0.9, hoyde: 1.2, dybde: 2.2 },
  terrasse: { navn: 'Terrasse', bredde: 2.5, hoyde: 0.18, dybde: 2.5 },
  pergola: { navn: 'Pergola', bredde: 2.5, hoyde: 2.4, dybde: 2.5 },
  fasade: { navn: 'Fasade', bredde: 2.4, hoyde: 2.4, dybde: 0.12 },
  tak: { navn: 'Tak', bredde: 2.4, hoyde: 0.35, dybde: 2.4 },
  dor: { navn: 'Dør', bredde: 0.9, hoyde: 2.1, dybde: 0.08 },
  vindu: { navn: 'Vindu', bredde: 1.2, hoyde: 1.2, dybde: 0.08 },
};

const round = (n, d = 2) => Math.round(n * 10 ** d) / 10 ** d;
const number = (v, fallback = 0) => {
  const n = Number(String(v).replace(',', '.'));
  return Number.isFinite(n) ? n : fallback;
};

function createMaterialTexture(kind) {
  if (typeof document === 'undefined') return null;
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;
  ctx.fillStyle = kind === 'floor' ? '#c7b18f' : '#e7e3da';
  ctx.fillRect(0, 0, 256, 256);
  if (kind === 'floor') {
    for (let y = 0; y < 256; y += 32) {
      ctx.strokeStyle = '#8f795e';
      ctx.globalAlpha = 0.34;
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(256, y); ctx.stroke();
      for (let x = (y / 32) % 2 ? -54 : 0; x < 256; x += 92) {
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + 32); ctx.stroke();
      }
    }
  } else {
    for (let i = 0; i < 180; i += 1) {
      const v = 215 + (i % 4) * 5;
      ctx.fillStyle = `rgb(${v},${v},${v - 3})`;
      ctx.globalAlpha = 0.22;
      ctx.fillRect((i * 47) % 256, (i * 83) % 256, 1, 1);
    }
  }
  ctx.globalAlpha = 1;
  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(kind === 'floor' ? 3 : 2, kind === 'floor' ? 3 : 2);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function roomBounds(points) {
  const xs = points.map((p) => p.x);
  const zs = points.map((p) => p.y);
  const minX = Math.min(...xs);
  const maxX = Math.max(...xs);
  const minZ = Math.min(...zs);
  const maxZ = Math.max(...zs);
  return {
    minX, maxX, minZ, maxZ,
    width: maxX - minX,
    depth: maxZ - minZ,
    center: [(minX + maxX) / 2, (minZ + maxZ) / 2],
  };
}

function Floor({ room, selected, onSelect, onMove }) {
  const geometry = useMemo(() => {
    const shape = new THREE.Shape();
    room.punkter.forEach((p, index) => {
      if (index === 0) shape.moveTo(p.x, -p.y);
      else shape.lineTo(p.x, -p.y);
    });
    shape.closePath();
    const geo = new THREE.ShapeGeometry(shape);
    geo.rotateX(-Math.PI / 2);
    return geo;
  }, [room.punkter]);
  const texture = useMemo(() => createMaterialTexture('floor'), []);

  useEffect(() => () => { geometry.dispose(); texture?.dispose(); }, [geometry, texture]);

  return (
    <mesh
      geometry={geometry}
      receiveShadow
      position-y={0.006}
      onClick={(event) => { event.stopPropagation(); onSelect(room.id); }}
      onPointerMove={(event) => onMove(event.point)}
    >
      <meshStandardMaterial
        color={selected ? COLORS.floorSelected : COLORS.floor}
        map={texture || undefined}
        roughness={0.76}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}

/* Brukerens egen byggtegning legges flatt på bakken under rommene, skalert
   etter oppgitt bredde i meter. Da kan tegningen leses sammen med 3D-rommet. */
function BlueprintPlane({ blueprint }) {
  const [texture, setTexture] = useState(null);
  useEffect(() => {
    if (!blueprint || !blueprint.url) { setTexture(null); return undefined; }
    let alive = true;
    let loaded = null;
    new THREE.TextureLoader().load(blueprint.url, (tex) => {
      if (!alive) { tex.dispose(); return; }
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = 4;
      loaded = tex;
      setTexture(tex);
    });
    return () => { alive = false; if (loaded) loaded.dispose(); };
  }, [blueprint && blueprint.url]);

  if (!blueprint || !texture) return null;
  const width = Math.max(0.5, number(blueprint.bredde, 10));
  const image = texture.image || {};
  const ratio = image.height && image.width ? image.height / image.width : 0.75;
  const depth = width * ratio;
  return (
    <mesh
      rotation-x={-Math.PI / 2}
      position={[number(blueprint.x, 0) + width / 2, 0.001, number(blueprint.y, 0) + depth / 2]}
    >
      <planeGeometry args={[width, depth]} />
      <meshBasicMaterial map={texture} transparent opacity={Math.min(1, Math.max(0.1, number(blueprint.opacity, 0.85)))} toneMapped={false} />
    </mesh>
  );
}

function Walls({ room, height, openings }) {
  const wallTexture = useMemo(() => createMaterialTexture('wall'), []);
  useEffect(() => () => wallTexture?.dispose(), [wallTexture]);
  return room.punkter.map((a, index) => {
    const b = room.punkter[(index + 1) % room.punkter.length];
    const length = Math.hypot(b.x - a.x, b.y - a.y);
    const angle = Math.atan2(b.y - a.y, b.x - a.x);
    const wallOpenings = openings.filter(
      (opening) => opening.romId === room.id && Number(opening.veggIndeks || 0) === index,
    );
    return (
      <group key={`${room.id}-wall-${index}`}>
        <mesh
          position={[(a.x + b.x) / 2, height / 2, (a.y + b.y) / 2]}
          rotation-y={-angle}
          castShadow
          receiveShadow
        >
          <boxGeometry args={[length, height, 0.075]} />
          <meshStandardMaterial color={COLORS.wall} map={wallTexture || undefined} transparent opacity={0.36} roughness={0.9} depthWrite={false} />
        </mesh>
        {wallOpenings.map((opening) => {
          const width = Math.min(number(opening.b, 1), length);
          const openingHeight = Math.min(number(opening.h, 1), height);
          const start = Math.max(0, Math.min(length - width, number(opening.pos, 0)));
          const sill = opening.type === 'Dor' ? 0 : Math.max(0, number(opening.sh, 0.9));
          const ux = (b.x - a.x) / (length || 1);
          const uz = (b.y - a.y) / (length || 1);
          const along = start + width / 2;
          return (
            <mesh
              key={opening.id}
              position={[a.x + ux * along, sill + openingHeight / 2, a.y + uz * along]}
              rotation-y={-angle}
            >
              <boxGeometry args={[width, openingHeight, 0.09]} />
              <meshStandardMaterial
                color={opening.type === 'Dor' ? COLORS.door : COLORS.opening}
                transparent
                opacity={0.82}
              />
            </mesh>
          );
        })}
      </group>
    );
  });
}

function DimensionLine({ from, to, label, offset = [0, 0, 0] }) {
  const a = [from[0] + offset[0], from[1] + offset[1], from[2] + offset[2]];
  const b = [to[0] + offset[0], to[1] + offset[1], to[2] + offset[2]];
  const midpoint = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2];
  return (
    <group>
      <Line points={[a, b]} color={COLORS.measure} lineWidth={1.7} />
      <Line points={[[a[0], a[1] - 0.06, a[2]], [a[0], a[1] + 0.06, a[2]]]} color={COLORS.measure} lineWidth={1.7} />
      <Line points={[[b[0], b[1] - 0.06, b[2]], [b[0], b[1] + 0.06, b[2]]]} color={COLORS.measure} lineWidth={1.7} />
      <Html position={midpoint} center distanceFactor={8} zIndexRange={[20, 0]}>
        <span className="tf-room-measure">{label}</span>
      </Html>
    </group>
  );
}

function RoomDimensions({ room, height }) {
  const bounds = roomBounds(room.punkter);
  return (
    <group>
      <DimensionLine
        from={[bounds.minX, 0.12, bounds.maxZ + 0.3]}
        to={[bounds.maxX, 0.12, bounds.maxZ + 0.3]}
        label={`B ${round(bounds.width)} m`}
      />
      <DimensionLine
        from={[bounds.maxX + 0.3, 0.12, bounds.minZ]}
        to={[bounds.maxX + 0.3, 0.12, bounds.maxZ]}
        label={`L ${round(bounds.depth)} m`}
      />
      <DimensionLine
        from={[bounds.minX - 0.25, 0, bounds.minZ]}
        to={[bounds.minX - 0.25, height, bounds.minZ]}
        label={`H ${round(height)} m`}
      />
    </group>
  );
}

function Stair({ placement, selected }) {
  const steps = 7;
  return (
    <group>
      {Array.from({ length: steps }).map((_, index) => {
        const depth = placement.dybde / steps;
        const h = (placement.hoyde * (index + 1)) / steps;
        return (
          <mesh key={index} position={[0, h / 2, -placement.dybde / 2 + depth * (index + 0.5)]} castShadow>
            <boxGeometry args={[placement.bredde, h, depth * 0.94]} />
            <meshStandardMaterial color={selected ? COLORS.selected : COLORS.timber} roughness={0.8} />
          </mesh>
        );
      })}
    </group>
  );
}

function Pergola({ placement, selected }) {
  const color = selected ? COLORS.selected : COLORS.timber;
  const posts = [
    [-placement.bredde / 2, -placement.dybde / 2],
    [placement.bredde / 2, -placement.dybde / 2],
    [-placement.bredde / 2, placement.dybde / 2],
    [placement.bredde / 2, placement.dybde / 2],
  ];
  return (
    <group>
      {posts.map(([x, z], index) => (
        <mesh key={index} position={[x, placement.hoyde / 2, z]} castShadow>
          <boxGeometry args={[0.1, placement.hoyde, 0.1]} />
          <meshStandardMaterial color={color} />
        </mesh>
      ))}
      <mesh position={[0, placement.hoyde, -placement.dybde / 2]} castShadow>
        <boxGeometry args={[placement.bredde + 0.12, 0.12, 0.12]} />
        <meshStandardMaterial color={color} />
      </mesh>
      <mesh position={[0, placement.hoyde, placement.dybde / 2]} castShadow>
        <boxGeometry args={[placement.bredde + 0.12, 0.12, 0.12]} />
        <meshStandardMaterial color={color} />
      </mesh>
    </group>
  );
}

function ProjectRoof({ roof, rooms, wallHeight }) {
  const [tileTextureSource, battensTextureSource] = useTexture([roofTilesPhoto, roofBattensPhoto]);
  const textures = useMemo(() => {
    const tiles = tileTextureSource.clone();
    const battens = battensTextureSource.clone();
    [tiles, battens].forEach((texture) => {
      texture.colorSpace = THREE.SRGBColorSpace;
      texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
      texture.repeat.set(2.4, 1.35);
      texture.anisotropy = 4;
      texture.needsUpdate = true;
    });
    return { tiles, battens };
  }, [tileTextureSource, battensTextureSource]);

  useEffect(() => () => {
    textures.tiles.dispose();
    textures.battens.dispose();
  }, [textures]);

  const allPoints = rooms.flatMap((room) => room.punkter || []);
  if (!roof || allPoints.length === 0) return null;
  const bounds = roomBounds(allPoints);
  /* Taket skal alltid sitte på huset: geometrien følger grunnflaten til rommene.
     Tallene i takskjemaet (lengde/bredde) brukes til areal og pris, ikke til
     å tegne et tak som svever ved siden av bygget. */
  const length = Math.max(0.5, bounds.width);
  const span = Math.max(0.5, bounds.depth);
  const angle = THREE.MathUtils.degToRad(Math.max(1, Math.min(60, number(roof.takvinkel, 30))));
  const isPitched = roof.type !== 'pulttak';
  const run = isPitched ? span / 2 : span;
  const rise = Math.tan(angle) * run;
  const slope = Math.hypot(run, rise);
  const eave = Math.max(0.5, number(wallHeight, 2.4));
  const ridge = eave + rise;
  const centerX = bounds.center[0];
  const centerZ = bounds.center[1];
  const overhang = 0.22;
  const tileLength = length + overhang * 2;

  const RoofPlane = ({ z, rotation }) => (
    <group position={[centerX, eave + rise / 2, centerZ + z]} rotation-x={rotation}>
      <mesh castShadow receiveShadow>
        <boxGeometry args={[tileLength, 0.075, slope + overhang]} />
        <meshStandardMaterial map={textures.tiles} color="#e3e0da" roughness={0.86} />
      </mesh>
      <mesh position={[0, -0.052, 0]} rotation-x={-Math.PI / 2}>
        <planeGeometry args={[tileLength, slope + overhang]} />
        <meshStandardMaterial map={textures.battens} color="#eee8dd" roughness={0.9} side={THREE.DoubleSide} />
      </mesh>
    </group>
  );

  return (
    <group>
      {isPitched ? (
        <>
          <RoofPlane z={-span / 4} rotation={-angle} />
          <RoofPlane z={span / 4} rotation={angle} />
          <mesh position={[centerX, ridge, centerZ]} castShadow>
            <boxGeometry args={[tileLength + 0.08, 0.11, 0.14]} />
            <meshStandardMaterial map={textures.tiles} color="#d9d6d0" roughness={0.84} />
          </mesh>
        </>
      ) : (
        <RoofPlane z={0} rotation={angle} />
      )}
      <DimensionLine
        from={[bounds.minX - 0.48, 0, bounds.minZ]}
        to={[bounds.minX - 0.48, eave, bounds.minZ]}
        label={`Takhøyde ${round(eave)} m`}
      />
      <DimensionLine
        from={[bounds.minX - 0.72, 0, centerZ]}
        to={[bounds.minX - 0.72, ridge, centerZ]}
        label={`${isPitched ? 'Møne' : 'Topphøyde'} ${round(ridge)} m`}
      />
      <Html position={[centerX, ridge + 0.28, centerZ]} center distanceFactor={9} zIndexRange={[18, 0]}>
        <span className="tf-room-label tf-roof-shape-label">
          {isPitched ? 'Saltak' : 'Pulttak'} · {round(THREE.MathUtils.radToDeg(angle), 1)}°
        </span>
      </Html>
    </group>
  );
}

function ModuleObject({ placement, selected, onSelect, onDragStart }) {
  const color = selected ? COLORS.selected : COLORS.module;
  const y = placement.y + placement.hoyde / 2;
  const commonProps = {
    onPointerDown: (event) => {
      event.stopPropagation();
      event.target.setPointerCapture?.(event.pointerId);
      onSelect(placement.id);
      onDragStart(placement.id);
    },
    onPointerUp: (event) => {
      event.stopPropagation();
      event.target.releasePointerCapture?.(event.pointerId);
      onDragStart(null);
    },
  };
  return (
    <group
      position={[placement.x, placement.y, placement.z]}
      rotation-y={(placement.rotasjon * Math.PI) / 180}
      {...commonProps}
    >
      {placement.type === 'trapp' ? <Stair placement={placement} selected={selected} /> : null}
      {placement.type === 'pergola' ? <Pergola placement={placement} selected={selected} /> : null}
      {!['trapp', 'pergola', 'tak'].includes(placement.type) ? (
        <mesh position={[0, y - placement.y, 0]} castShadow receiveShadow>
          <boxGeometry args={[placement.bredde, placement.hoyde, placement.dybde]} />
          <meshStandardMaterial
            color={placement.type === 'vindu' ? COLORS.opening : placement.type === 'dor' ? COLORS.door : color}
            roughness={0.75}
            transparent={placement.type === 'vindu'}
            opacity={placement.type === 'vindu' ? 0.78 : 1}
          />
        </mesh>
      ) : null}
      <Html position={[0, placement.hoyde + 0.18, 0]} center distanceFactor={8} zIndexRange={[15, 0]}>
        <span className={selected ? 'tf-room-label tf-room-label-selected' : 'tf-room-label'}>
          {placement.navn}
        </span>
      </Html>
    </group>
  );
}

/* FASADEN I 3D: elementene fra den tekniske fasadetegningen vises rett på
   ytterveggen, slik at "før" og "etter" kan sammenlignes i rommet - ikke
   bare på et separat bilde. */
const FACADE_COLORS = { beholdes: '#5790a6', ny: '#3f8f5e', fjernes: '#b4543f' };

function FacadeWall({ fasade, rooms, view }) {
  const points = rooms.flatMap((room) => room.punkter || []);
  if (!points.length) return null;
  const bounds = roomBounds(points);
  const width = Math.max(1, number(fasade.bredde, bounds.width));
  const wallHeight = Math.max(1, number(fasade.hoyde, 3));
  const x0 = bounds.center[0] - width / 2;
  const z = bounds.minZ - 0.35;
  const elements = (fasade.elementer || []).filter((e) => (view === 'for' ? e.status !== 'ny' : e.status !== 'fjernes'));
  return (
    <group position={[0, 0, z]}>
      <mesh position={[bounds.center[0], wallHeight / 2, 0]} receiveShadow>
        <boxGeometry args={[width, wallHeight, 0.12]} />
        <meshStandardMaterial color="#e2ddd0" roughness={0.9} />
      </mesh>
      {elements.map((e) => {
        const b = Math.max(0.2, number(e.b, 1));
        const h = Math.max(0.2, number(e.h, 1));
        const color = FACADE_COLORS[e.status] || FACADE_COLORS.beholdes;
        return (
          <group key={e.id} position={[x0 + number(e.x, 0) + b / 2, number(e.y, 0) + h / 2, 0.09]}>
            <mesh>
              <boxGeometry args={[b, h, 0.08]} />
              <meshStandardMaterial color={color} transparent opacity={e.status === 'fjernes' ? 0.45 : 0.9} roughness={0.6} />
            </mesh>
            <Html position={[0, h / 2 + 0.16, 0]} center distanceFactor={9} zIndexRange={[15, 0]}>
              <span className="tf-room-label">{e.type} · {e.status}</span>
            </Html>
          </group>
        );
      })}
    </group>
  );
}

function CameraFit({ points, height }) {
  const { camera } = useThree();
  useEffect(() => {
    if (!points.length) return;
    const bounds = roomBounds(points);
    const size = Math.max(bounds.width, bounds.depth, height, 2);
    camera.position.set(bounds.center[0] + size * 1.15, height + size * 0.85, bounds.center[1] + size * 1.15);
    camera.lookAt(bounds.center[0], height * 0.4, bounds.center[1]);
    camera.updateProjectionMatrix();
  }, [camera, points, height]);
  return null;
}

function Scene({ rooms, selectedRoomId, height, openings, placements, roof, blueprint, fasade, fasadeVisning, selectedId, onSelect, onMove }) {
  const selectedRoom = rooms.find((room) => room.id === selectedRoomId) || rooms[0];
  const dragging = useRef(null);
  const roofSpan = rooms.length ? roomBounds(rooms.flatMap((room) => room.punkter || [])).depth : 0;
  const roofRise = roof
    ? Math.tan(THREE.MathUtils.degToRad(number(roof.takvinkel, 30))) * roofSpan / (roof.type === 'pulttak' ? 1 : 2)
    : 0;
  const sceneHeight = height + roofRise;
  return (
    <>
      <color attach="background" args={[COLORS.background]} />
      <fog attach="fog" args={[COLORS.background, 18, 42]} />
      <hemisphereLight args={['#faf7ef', '#758073', 1.05]} />
      <directionalLight position={[6, 10, 8]} intensity={1.8} castShadow shadow-mapSize-width={1024} shadow-mapSize-height={1024} />
      <Environment resolution={128}>
        <Lightformer intensity={2.2} position={[0, 7, 2]} scale={[10, 10, 1]} />
        <Lightformer intensity={1.1} color="#b8d5ce" position={[-6, 2, 0]} rotation-y={Math.PI / 2} scale={[8, 3, 1]} />
      </Environment>
      {rooms.map((room) => (
        <group key={room.id}>
          <Floor
            room={room}
            selected={room.id === selectedRoom?.id}
            onSelect={() => onSelect(null)}
            onMove={(point) => {
              if (dragging.current) onMove(dragging.current, { x: point.x, z: point.z });
            }}
          />
          <Walls room={room} height={height} openings={openings} />
        </group>
      ))}
      {selectedRoom ? (
        <gridHelper
          args={[Math.ceil(Math.max(roomBounds(selectedRoom.punkter).width, roomBounds(selectedRoom.punkter).depth) + 2), Math.ceil(Math.max(roomBounds(selectedRoom.punkter).width, roomBounds(selectedRoom.punkter).depth) + 2), '#8ca198', '#c6cfca']}
          position={[roomBounds(selectedRoom.punkter).center[0], 0.012, roomBounds(selectedRoom.punkter).center[1]]}
        />
      ) : null}
      {selectedRoom ? <RoomDimensions room={selectedRoom} height={height} /> : null}
      {blueprint && blueprint.url ? <BlueprintPlane blueprint={blueprint} /> : null}
      {fasade && (fasade.elementer || []).length ? <FacadeWall fasade={fasade} rooms={rooms} view={fasadeVisning} /> : null}
      {roof ? <ProjectRoof roof={roof} rooms={rooms} wallHeight={height} /> : null}
      {placements.filter((placement) => !(roof && placement.type === 'tak')).map((placement) => (
        <ModuleObject
          key={placement.id}
          placement={placement}
          selected={placement.id === selectedId}
          onSelect={onSelect}
          onDragStart={(id) => { dragging.current = id; }}
        />
      ))}
      {selectedRoom ? <CameraFit points={rooms.flatMap((room) => room.punkter || [])} height={sceneHeight} /> : null}
      <OrbitControls
        makeDefault
        enableDamping
        dampingFactor={0.08}
        minDistance={1.5}
        maxDistance={35}
        maxPolarAngle={Math.PI / 2.02}
        target={selectedRoom ? [roomBounds(selectedRoom.punkter).center[0], height * 0.45, roomBounds(selectedRoom.punkter).center[1]] : [0, 1, 0]}
      />
    </>
  );
}

function Field({ label, value, onChange, step = 0.1 }) {
  return (
    <label className="tf-room-field">
      <span>{label}</span>
      <input type="number" inputMode="decimal" step={step} value={value} onChange={(event) => onChange(number(event.target.value))} />
    </label>
  );
}

export default function RomViewer3D({ rooms, selectedRoomId, height, openings, placements, roof, blueprint, fasade, onPlacementsChange, costSummary }) {
  const [selectedId, setSelectedId] = useState(null);
  const [fasadeVisning, setFasadeVisning] = useState('etter');
  const selectedRoom = rooms.find((room) => room.id === selectedRoomId) || rooms[0];
  const selected = placements.find((placement) => placement.id === selectedId) || null;

  const update = (id, patch) => {
    onPlacementsChange(placements.map((placement) => placement.id === id ? { ...placement, ...patch } : placement));
  };
  const add = (type) => {
    const defaults = MODULE_DEFAULTS[type];
    if (!defaults || !selectedRoom) return;
    const bounds = roomBounds(selectedRoom.punkter);
    const placement = {
      id: `pl-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      type,
      romId: selectedRoom.id,
      x: round(bounds.center[0]), y: 0, z: round(bounds.center[1]), rotasjon: 0,
      ...defaults,
    };
    onPlacementsChange([...placements, placement]);
    setSelectedId(placement.id);
  };

  const placeOnWall = (wallIndex, distance = 0) => {
    if (!selected || !selectedRoom || wallIndex === '') return;
    const index = Math.max(0, Math.min(selectedRoom.punkter.length - 1, Number(wallIndex)));
    const a = selectedRoom.punkter[index];
    const b = selectedRoom.punkter[(index + 1) % selectedRoom.punkter.length];
    const length = Math.hypot(b.x - a.x, b.y - a.y) || 1;
    const width = Math.min(Math.max(0.05, number(selected.bredde, 0.05)), length);
    const maxStart = Math.max(0, length - width);
    const start = Math.max(0, Math.min(maxStart, number(distance, 0)));
    const along = start + width / 2;
    const ux = (b.x - a.x) / length;
    const uz = (b.y - a.y) / length;
    update(selected.id, {
      veggIndeks: index,
      fraHjorne: round(start),
      bredde: round(width),
      x: round(a.x + ux * along),
      z: round(a.y + uz * along),
      rotasjon: round((-Math.atan2(b.y - a.y, b.x - a.x) * 180) / Math.PI, 1),
    });
  };

  return (
    <div className="tf-room-viewer">
      <div className="tf-room-canvas" aria-label="Interaktiv 3D-visning av rommet">
        <Canvas shadows dpr={[1, 1.5]} camera={{ fov: 48, near: 0.05, far: 100 }}>
          <React.Suspense fallback={null}>
            <Scene
              rooms={rooms}
              selectedRoomId={selectedRoomId}
              height={height}
              openings={openings}
              placements={placements}
              roof={roof}
              blueprint={blueprint}
              fasade={fasade}
              fasadeVisning={fasadeVisning}
              selectedId={selectedId}
              onSelect={setSelectedId}
              onMove={(id, point) => update(id, { x: round(point.x), z: round(point.z) })}
            />
          </React.Suspense>
        </Canvas>
        {costSummary && costSummary.jobs > 0 ? (
          <div className="tf-room-price" data-tf="3d-totalpris" aria-live="polite">
            <span>{costSummary.roomName || 'Prosjekt'}</span>
            <strong>{costSummary.fra.toLocaleString('no-NO')}–{costSummary.til.toLocaleString('no-NO')} kr</strong>
            <small>{costSummary.rooms || 1} rom · {costSummary.area || 0} m² · {costSummary.jobs} {costSummary.jobs === 1 ? 'jobb' : 'jobber'}</small>
            {costSummary.rateFrom ? (
              <small>
                {costSummary.rateName}: {costSummary.rateFrom.toLocaleString('no-NO')}–
                {costSummary.rateTo.toLocaleString('no-NO')} kr/m²
              </small>
            ) : null}
            {(costSummary.lines || []).length ? (
              <ul className="tf-room-price-lines" data-tf="3d-prislinjer">
                {costSummary.lines.slice(0, 7).map((line, i) => (
                  <li key={line.navn + i}>
                    <span>{line.navn}</span>
                    <b>{Math.round(line.fra).toLocaleString('no-NO')}–{Math.round(line.til).toLocaleString('no-NO')} kr</b>
                  </li>
                ))}
                {costSummary.lines.length > 7 ? <li><span>+ {costSummary.lines.length - 7} flere poster</span></li> : null}
              </ul>
            ) : null}
            {costSummary.roofArea ? <small>Tak {costSummary.roofArea} m² · {costSummary.antall} beregnede enheter</small> : <small>{costSummary.antall} beregnede moduler</small>}
            {roof ? <small>{roof.type === 'pulttak' ? 'Pulttak' : 'Saltak'} {number(roof.takvinkel, 0)}° · takhøyde {round(height)} m</small> : null}
          </div>
        ) : null}
        {fasade && (fasade.elementer || []).length ? (
          <div className="tf-room-facade-toggle" data-tf="fasade-for-etter">
            <button type="button" aria-pressed={fasadeVisning === 'for'}
              className={fasadeVisning === 'for' ? 'is-active' : ''}
              onClick={() => setFasadeVisning('for')}>Før</button>
            <button type="button" aria-pressed={fasadeVisning === 'etter'}
              className={fasadeVisning === 'etter' ? 'is-active' : ''}
              onClick={() => setFasadeVisning('etter')}>Etter</button>
          </div>
        ) : null}
        <div className="tf-room-hint">Dra for å snu · knip for å zoome · dra en modul over gulvet</div>
      </div>

      <div className="tf-room-palette" aria-label="Moduler som kan plasseres">
        {Object.entries(MODULE_DEFAULTS).map(([type, defaults]) => (
          <button key={type} type="button" onClick={() => add(type)}>+ {defaults.navn}</button>
        ))}
      </div>

      {selected ? (
        <div className="tf-room-editor">
          <div className="tf-room-editor-head">
            <strong>{selected.navn}</strong>
            <button type="button" onClick={() => {
              onPlacementsChange(placements.filter((placement) => placement.id !== selected.id));
              setSelectedId(null);
            }}>Fjern</button>
          </div>
          <div className="tf-room-wall-fields">
            <label className="tf-room-field">
              <span>Fest til vegg</span>
              <select
                value={selected.veggIndeks ?? ''}
                onChange={(event) => {
                  if (event.target.value === '') update(selected.id, { veggIndeks: undefined });
                  else placeOnWall(event.target.value, selected.fraHjorne || 0);
                }}
              >
                <option value="">Fri plassering</option>
                {selectedRoom.punkter.map((point, index) => {
                  const next = selectedRoom.punkter[(index + 1) % selectedRoom.punkter.length];
                  return <option key={index} value={index}>Vegg {index + 1} · {round(Math.hypot(next.x - point.x, next.y - point.y))} m</option>;
                })}
              </select>
            </label>
            {selected.veggIndeks !== undefined ? (
              <Field
                label="Fra hjørnet (m)"
                value={selected.fraHjorne || 0}
                onChange={(fraHjorne) => placeOnWall(selected.veggIndeks, fraHjorne)}
              />
            ) : null}
          </div>
          <div className="tf-room-fields">
            <Field label="X (m)" value={selected.x} onChange={(x) => update(selected.id, { x })} />
            <Field label="Z (m)" value={selected.z} onChange={(z) => update(selected.id, { z })} />
            <Field label="Høyde fra gulv" value={selected.y} onChange={(y) => update(selected.id, { y: Math.max(0, y) })} />
            <Field label="Rotasjon °" value={selected.rotasjon} step={5} onChange={(rotasjon) => update(selected.id, { rotasjon })} />
            <Field label="Bredde (m)" value={selected.bredde} onChange={(bredde) => update(selected.id, { bredde: Math.max(0.05, bredde) })} />
            <Field label="Høyde (m)" value={selected.hoyde} onChange={(hoyde) => update(selected.id, { hoyde: Math.max(0.05, hoyde) })} />
            <Field label="Dybde (m)" value={selected.dybde} onChange={(dybde) => update(selected.id, { dybde: Math.max(0.05, dybde) })} />
            <Field label="Pris fra (kr)" step={500} value={selected.prisFra || 0} onChange={(prisFra) => update(selected.id, { prisFra: Math.max(0, Math.round(prisFra)) })} />
            <Field label="Pris til (kr)" step={500} value={selected.prisTil || 0} onChange={(prisTil) => update(selected.id, { prisTil: Math.max(0, Math.round(prisTil)) })} />
          </div>
          <div className="tf-room-swap" data-tf="modul-bytte">
            <label className="tf-room-field">
              <span>Bytt modul fra biblioteket</span>
              <select
                value={selected.modulId || ''}
                onChange={(event) => {
                  const modul = FERDIGMODULER.find((m) => m.id === event.target.value);
                  if (!modul) return;
                  update(selected.id, {
                    modulId: modul.id, type: modul.type, navn: modul.navn,
                    bredde: modul.bredde, hoyde: modul.hoyde, dybde: modul.dybde,
                    y: modul.y || 0, prisFra: modul.prisFra, prisTil: modul.prisTil,
                  });
                }}
              >
                <option value="">Velg modul …</option>
                {FERDIGMODULER.map((m) => <option key={m.id} value={m.id}>{m.navn}</option>)}
              </select>
            </label>
            {selected.modulId ? (
              <button type="button" onClick={() => {
                const modul = FERDIGMODULER.find((m) => m.id === selected.modulId);
                if (!modul) return;
                update(selected.id, {
                  bredde: modul.bredde, hoyde: modul.hoyde, dybde: modul.dybde,
                  y: modul.y || 0, prisFra: modul.prisFra, prisTil: modul.prisTil,
                });
              }}>Tilbakestill til standardmål</button>
            ) : null}
          </div>
          {selected.modulId ? (
            <div className="tf-room-drawing" data-tf="modul-fagtegning">
              <ModulTegning
                modul={{
                  ...(FERDIGMODULER.find((m) => m.id === selected.modulId) || {}),
                  navn: selected.navn,
                  bredde: Math.max(0.05, number(selected.bredde, 1)),
                  hoyde: Math.max(0.05, number(selected.hoyde, 1)),
                  dybde: Math.max(0.05, number(selected.dybde, 0.1)),
                }}
              />
              <small>{(number(selected.prisFra, 0)).toLocaleString('no-NO')}–{(number(selected.prisTil, 0)).toLocaleString('no-NO')} kr</small>
            </div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}