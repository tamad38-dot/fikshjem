declare const TamerFixApp: React.ComponentType<Record<string, unknown>>;
export default TamerFixApp;
