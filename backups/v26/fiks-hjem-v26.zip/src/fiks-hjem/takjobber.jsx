import React from 'react';
import stigeFoto from '../assets/fiks-hjem-roof-ladder-snowguard.jpg';
import listeFoto from '../assets/fiks-hjem-roof-trim.jpg';
import steinFoto from '../assets/fiks-hjem-roof-step-tiles.jpg';
import takvinduFoto from '../assets/fiks-hjem-roof-skylight.jpg';

/* ================================================================
   TAKJOBBER
   Takstige og snøfanger (taksporing), taklister og beslag, takstein og
   takvinduer. Mengden regnes ut fra takmålene i prosjektet, prisen er et
   veiledende intervall for material + montering, og jobben vises som en
   modul oppe på taket i 3D.
   ================================================================ */

export const TAKJOBBER = [
  {
    id: 'taksporing', navn: 'Takstige og snøfanger', foto: stigeFoto, enhet: 'lm',
    prisFra: 900, prisTil: 1900, type: 'takstige',
    beskrivelse: 'Sikker vei opp til pipa og snøfanger langs raftet. Krav ved pipe og over inngang.',
    mengde: (t) => Math.max(1, t.skraaLengde + t.lengde),
    boks: (t) => ({ bredde: Math.max(0.6, t.lengde * 0.9), hoyde: 0.12, dybde: 0.45 }),
  },
  {
    id: 'taklister', navn: 'Taklister, vindskier og beslag', foto: listeFoto, enhet: 'lm',
    prisFra: 450, prisTil: 1100, type: 'taklist',
    beskrivelse: 'Vindskier, vannbord og beslag langs gavl og raft. Holder vann og vind ute av tekkingen.',
    mengde: (t) => Math.max(1, t.skraaLengde * 4 + t.lengde * 2),
    boks: (t) => ({ bredde: Math.max(0.6, t.lengde), hoyde: 0.1, dybde: 0.2 }),
  },
  {
    id: 'takstein', navn: 'Takstein med lekter og undertak', foto: steinFoto, enhet: 'm²',
    prisFra: 1100, prisTil: 2600, type: 'takstein',
    beskrivelse: 'Betongtakstein, sløyfer, lekter og undertak lagt på hele takflaten, inkludert svinn.',
    mengde: (t) => Math.max(1, t.flate),
    boks: (t) => ({ bredde: Math.max(0.6, t.lengde * 0.6), hoyde: 0.14, dybde: Math.max(0.6, t.skraaLengde * 0.5) }),
  },
  {
    id: 'takvindu', navn: 'Takvindu montert i tekkingen', foto: takvinduFoto, enhet: 'stk',
    prisFra: 12000, prisTil: 27000, type: 'takvindu',
    beskrivelse: 'Takvindu med inndekning og innvendig lysnisje. Prisen gjelder per vindu ferdig montert.',
    mengde: () => 1, perStk: true,
    boks: () => ({ bredde: 0.78, hoyde: 0.12, dybde: 1.18 }),
  },
];

/** Takmål utledet fra takprosjektet: skrå lengde, takflate og raftlengde. */
export function takMaal(tak) {
  const n = (v, f = 0) => (Number.isFinite(Number(v)) ? Number(v) : f);
  const vinkel = (n(tak && tak.takvinkel, 30) * Math.PI) / 180;
  const bredde = n(tak && tak.bredde, 6);
  const lengde = n(tak && tak.lengde, 9);
  const pulttak = tak && tak.type === 'pulttak';
  const halvSpenn = pulttak ? bredde : bredde / 2;
  const skraaLengde = halvSpenn / Math.max(0.2, Math.cos(vinkel));
  const flate = (pulttak ? 1 : 2) * lengde * skraaLengde;
  const svinn = n(tak && tak.svinn, 0) / 100;
  return {
    bredde, lengde, skraaLengde: Math.round(skraaLengde * 100) / 100,
    flate: Math.round(flate * (1 + svinn) * 100) / 100,
  };
}

/** Beregner mengde og prisintervall for hver valgte takjobb. */
export function beregnTakjobber(tak, valgte) {
  const maal = takMaal(tak);
  return (valgte || []).map((valg) => {
    const jobb = TAKJOBBER.find((j) => j.id === valg.id);
    if (!jobb) return null;
    const antall = Math.max(1, Number(valg.antall) || 1);
    const mengde = Math.round(jobb.mengde(maal) * antall * 100) / 100;
    return {
      ...jobb,
      antall,
      mengde,
      prisFraTotal: Math.round(mengde * jobb.prisFra),
      prisTilTotal: Math.round(mengde * jobb.prisTil),
    };
  }).filter(Boolean);
}

const kr = (n) => Math.round(n).toLocaleString('no-NO');

const T = {
  rutenett: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: 10 },
  kort: { border: '1px solid #DDE2DC', borderRadius: 12, overflow: 'hidden', background: '#fff', display: 'grid', gap: 6 },
  foto: { width: '100%', height: 104, objectFit: 'cover', display: 'block' },
  inn: { padding: '0 10px 10px', display: 'grid', gap: 6 },
  navn: { fontSize: 13, fontWeight: 700, color: '#1C2321', lineHeight: 1.3 },
  smaa: { fontSize: 11, color: '#8A938C', lineHeight: 1.4 },
  pris: { fontSize: 12, fontWeight: 600, color: '#2F5F55' },
  knapp: { width: '100%', padding: '8px 10px', borderRadius: 10, border: 'none', background: '#2F5F55', color: '#fff', fontSize: 12, fontWeight: 700, cursor: 'pointer' },
  knappAv: { width: '100%', padding: '8px 10px', borderRadius: 10, border: '1px solid #C8D0C8', background: '#fff', color: '#1C2321', fontSize: 12, fontWeight: 600, cursor: 'pointer' },
};

export function TakjobbListe({ tak, valgte, onVelg, onFjern, onAntall }) {
  const maal = takMaal(tak);
  return (
    <div style={T.rutenett} data-tf="takjobber">
      {TAKJOBBER.map((jobb) => {
        const valgt = (valgte || []).find((v) => v.id === jobb.id);
        const antall = valgt ? Math.max(1, Number(valgt.antall) || 1) : 1;
        const mengde = Math.round(jobb.mengde(maal) * antall * 100) / 100;
        return (
          <div key={jobb.id} style={{ ...T.kort, borderColor: valgt ? '#2F5F55' : '#DDE2DC' }}>
            <img src={jobb.foto} alt={jobb.navn} loading="lazy" width={1024} height={1024} style={T.foto} />
            <div style={T.inn}>
              <div style={T.navn}>{jobb.navn}</div>
              <div style={T.smaa}>{jobb.beskrivelse}</div>
              <div style={T.smaa}>{mengde} {jobb.enhet} · {kr(jobb.prisFra)}–{kr(jobb.prisTil)} kr per {jobb.enhet}</div>
              <div style={T.pris}>{kr(mengde * jobb.prisFra)}–{kr(mengde * jobb.prisTil)} kr</div>
              {valgt && jobb.perStk ? (
                <label style={{ ...T.smaa, display: 'grid', gap: 4 }}>
                  Antall
                  <input type="number" min="1" step="1" value={antall}
                    onChange={(e) => onAntall(jobb.id, Math.max(1, Math.round(Number(e.target.value) || 1)))}
                    style={{ padding: '6px 8px', borderRadius: 8, border: '1px solid #C8D0C8', fontSize: 12 }} />
                </label>
              ) : null}
              {valgt
                ? <button type="button" style={T.knappAv} onClick={() => onFjern(jobb.id)}>Fjern fra 3D</button>
                : <button type="button" style={T.knapp} onClick={() => onVelg(jobb)}>Legg på taket i 3D</button>}
            </div>
          </div>
        );
      })}
    </div>
  );
}
