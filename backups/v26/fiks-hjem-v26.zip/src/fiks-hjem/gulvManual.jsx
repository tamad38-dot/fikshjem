import React, { useEffect, useState } from 'react';
import { K, ln, tynn, Mal, Nr, OK } from './terrasseManual.jsx';

/* =====================================================================
   GULV – IKEA-manual for flytende laminat/parkett (klikk)
   Samme oppbygging som terrasse og vegg: tekst med dine mål + strektegning + 3D.

   Tallene kommer fra:
   - 8–10 mm luft mot vegg og faste installasjoner, ikke fyll med silikon:
     leggeanvisning laminat (Norsk Byggtjeneste/NOBB), Pergo (NOBB), Fargerike, IFI.
   - Siste rad ikke smalere enn 5 cm – ellers kappes første rad: leggeanvisning laminat (NOBB).
   - Endeforskyvning min. 30 cm, ingen bord kortere enn 30 cm: leggeanvisning (NOBB), Byggmakker.
   - Maks 10 × 10 m uten ekspansjonsfuge: leggeanvisning laminat (NOBB).
   - Planhet ±3 mm på 2 m, ±2 mm på 1 m: IFI.
   - Akklimatiser 48 t i uåpnet pakke i rommet: Pergo monteringsanvisning (NOBB).
   - Fuktsperre 0,2 mm aldringsbestandig PE, min. 200 mm omlegg eller tapede skjøter,
     alltid på betong på grunn, betongdekke og gulvvarme; under parkettunderlaget:
     Byggforsk (sitert), Kährs, IFI.
   - Gulvvarme: overflaten maks 27 °C: Fargerike.
   Hvilken side (not eller fjær) som skal mot veggen varierer mellom produsentene – derfor
   står det «se pakken». Bordbredden er brukerens eget mål (står på pakken).
   ===================================================================== */

export const GULV_VIDEO = ['', '', '', '', ''];

const FUGE = 0.01; // 10 mm mot hver vegg (8–10 mm)
const cm = (m) => Math.round(m * 100);
const cm1 = (m) => (Math.round(m * 1000) / 10).toLocaleString('nb-NO');

export function gulvGeo({ b, l, bord }) {
  const B = Math.max(0.5, b), L = Math.max(0.5, l), bw = Math.min(0.5, Math.max(0.05, bord || 0.19));
  const W = B - 2 * FUGE; // flaten bordene dekker på tvers
  let nRader = Math.ceil(W / bw - 1e-6);
  let forste = bw, siste = W - (nRader - 1) * bw, kappForste = false;
  if (siste < 0.05 && nRader > 1) { kappForste = true; const rest = W - (nRader - 2) * bw; forste = rest / 2; siste = rest / 2; }
  const areal = B * L;
  const varsler = [];
  if (B > 10 || L > 10) varsler.push('Rommet er over 10 m på én led. Da trenger gulvet en ekspansjonsfuge – se leggeanvisningen for ditt gulv.');
  return { B, L, bw, W, nRader, forste, siste, kappForste, areal, listeLm: 2 * (B + L), varsler };
}

/* ---------- 3D (x = bredde, y = lengde, bordene går langs y) ---------- */
export function gulvBokser(p) {
  const g = gulvGeo(p.mal); const bx = [];
  const add = (tag, o) => bx.push({ tag, ...o });
  add('rom', { x: -0.1, y: -0.1, z: 0, w: g.B + 0.2, d: 0.1, h: 0.35, c: '#e8e4dc' });
  add('rom', { x: -0.1, y: 0, z: 0, w: 0.1, d: g.L, h: 0.35, c: '#efebe3' });
  add('fukt', { x: 0, y: 0, z: 0, w: g.B, d: g.L, h: 0.003, c: '#8fb7d6', bak: true });
  add('underlag', { x: 0, y: 0, z: 0.004, w: g.B, d: g.L, h: 0.004, c: '#d6d9dc', bak: true });
  const z = 0.009, t = 0.009, seg = 1.28; let x = FUGE;
  for (let r = 0; r < g.nRader; r++) {
    const w = r === 0 ? g.forste : r === g.nRader - 1 ? g.siste : g.bw;
    const tag = r === 0 ? 'rad1' : r === g.nRader - 1 ? 'siste' : 'rader';
    let y = FUGE, forsk = ((r * 0.43) % seg); if (forsk > 0 && forsk < 0.3) forsk += 0.3;
    const deler = []; let a = 0; if (forsk > 0.05) { deler.push([y, forsk]); a = forsk; }
    while (a < g.L - 2 * FUGE - 0.001) { const lgd = Math.min(seg, g.L - 2 * FUGE - a); deler.push([y + a, lgd]); a += lgd; }
    deler.forEach(([yy, lgd], k) => add(tag, { x: x + 0.002, y: yy + 0.002, z, w: w - 0.004, d: lgd - 0.004, h: t, c: (r + k) % 2 ? '#c89a62' : '#d6a86e' }));
    x += w;
  }
  for (let y = 0.3; y < g.L; y += 0.8) add('kiler', { x: 0, y, z: z, w: FUGE, d: 0.05, h: 0.02, c: '#e05a3a' });
  add('list', { x: 0, y: 0, z: 0, w: g.B, d: 0.015, h: 0.06, c: '#f4f1ea' });
  add('list', { x: 0, y: 0, z: 0, w: 0.015, d: g.L, h: 0.06, c: '#f4f1ea' });
  return bx;
}

/* ---------- delene ---------- */
export function gulvDeler(p) {
  const g = gulvGeo(p.mal);
  const D = (tittel, tegning, tekst, deler, ny, rod) => ({ tittel, tegning, tekst, deler, ny, rod });
  const planTekst = g.kappForste
    ? `Rommet er ${cm(g.B)} cm bredt. Trekk fra 2 × 1 cm luft: ${cm(g.W)} cm. Med ${cm1(g.bw)} cm brede bord ville siste rad blitt under 5 cm. Kapp derfor FØRSTE og SISTE rad til ${cm1(g.forste)} cm hver. Du får ${g.nRader} rader.`
    : `Rommet er ${cm(g.B)} cm bredt. Trekk fra 2 × 1 cm luft: ${cm(g.W)} cm. Med ${cm1(g.bw)} cm brede bord blir det ${g.nRader} rader, og siste rad blir ${cm1(g.siste)} cm – det er over 5 cm, så første rad legges med helt bord.`;
  return [
    [
      D('La gulvet venne seg til rommet', 'pakker', 'Legg pakkene uåpnet midt i rommet der gulvet skal ligge, ved vanlig romtemperatur, i 48 timer.', [['pakke', 1]], ['rom']),
      D('Tøm rommet og fjern listene', 'lister', 'Bær ut møblene og ta av de gamle gulvlistene. Støvsug gulvet – grus under gulvet gir knirk og skader.', [['brekkjern', 1], ['stovsuger', 1]], []),
      D('Sjekk at gulvet er plant', 'planhet', 'Legg en rett 2-meters rettholt på gulvet flere steder. Avviket skal ikke være mer enn ±3 mm på 2 m (±2 mm på 1 m). Er det mer, må gulvet rettes før du legger.', [['rettholt', 1]], []),
    ],
    [
      D('Fuktsperre på betong', 'fukt', 'Er undergulvet betong, eller har du gulvvarme: legg 0,2 mm aldringsbestandig plastfolie. Minst 20 cm omlegg i skjøtene, eller tape dem. Brett den litt opp på veggen. På tregulv uten fukt trengs den som regel ikke.', [['fuktsperre', 1], ['tape', 1]], ['fukt']),
      D('Legg underlaget', 'underlag', 'Legg parkettunderlaget oppå fuktsperren. Følg anvisningen på rullen for skjøtene. Finnes underlag med fuktsperre ferdig på, erstatter det plastfolien.', [['underlag', 1]], ['underlag']),
    ],
    [
      D('Velg retning', 'retning', 'Legg bordene langs rommets lengste retning, helst i samme retning som lyset fra vinduet. Da blir skjøtene minst synlige.', [], []),
      D('Regn ut første og siste rad', 'siste', planTekst, [['maalebaand', 1]], []),
    ],
    [
      D('Første rad med kiler', 'kiler', 'Start i venstre hjørne. Sett kiler mellom bordet og veggen: 8–10 mm luft langs alle vegger. Hvilken side av bordet (not eller fjær) som skal mot veggen, står på pakken – den varierer.', [['kiler', 1], ['bord', 1]], ['rad1', 'kiler']),
      D('Klikk bordene sammen', 'klikk', 'Hold det nye bordet på skrå inn i det forrige, trykk sammen og legg det ned. Du skal høre et klikk. Presser du feil, kan låsen knekke.', [['slagkloss', 1]], []),
      D('Forskyv skjøtene min. 30 cm', 'skjot', 'Kappbiten fra enden av en rad blir starten på neste rad – hvis den er minst 30 cm. Er den kortere, start med et nytt bord. Skjøtene i to naborader skal ligge minst 30 cm fra hverandre.', [['sag', 1]], ['rader']),
      D('Siste rad', 'sisteRad', `Siste rad skal være ${cm1(g.siste)} cm bred (husk 8–10 mm luft mot veggen). Legg bordet oppå forrige rad, merk langs veggen og kapp på langs.`, [['bord', 1], ['sag', 1]], ['siste']),
    ],
    [
      D('Rundt rør og døråpninger', 'ror', 'Samme 8–10 mm luft rundt rør, terskler og dørkarmer. Kjøkkenøy og tunge skap skal stå på undergulvet – ikke på det flytende gulvet. Sjekk at døren fortsatt går opp.', [['bor', 1]], []),
      D('Fjern kilene og sett på lister', 'list', 'Ta ut kilene. Fest gulvlistene i veggen – aldri i gulvet, for gulvet skal kunne bevege seg. Luften skal være tom: ikke fyll den med silikon eller fugemasse.', [['list', 1]], ['list']),
      D('Sluttkontroll', 'ferdig', 'Gå over hele gulvet: ingen åpne skjøter, ingen knirk, og luften mot veggen er skjult bak listen. Har du gulvvarme: overflaten skal ikke over 27 °C.', [], []),
    ],
  ];
}

/* ---------- IKEA-tegninger ---------- */
function Rom({ g, x0 = 50, y0 = 30, max = 150, rader = 0, fugeVis = false }) {
  const s = Math.min(240 / g.B, max / g.L); const w = g.B * s, h = g.L * s;
  let x = x0 + FUGE * s; const r = [];
  for (let i = 0; i < Math.min(rader, g.nRader); i++) { const bw = i === 0 ? g.forste : i === g.nRader - 1 ? g.siste : g.bw; r.push(<rect key={i} x={x} y={y0 + FUGE * s} width={bw * s} height={h - 2 * FUGE * s} fill={i === 0 ? 'url(#skrav)' : '#fff'} {...tynn} />); x += bw * s; }
  return (<g><rect x={x0} y={y0} width={w} height={h} fill="none" {...ln} strokeWidth={4} />{r}
    {fugeVis && <text x={x0 + 4} y={y0 + h + 16} fontSize={11} fontWeight={800} fill={K}>8–10 mm luft</text>}</g>);
}

function GulvTegning({ type, g }) {
  const W = 340, H = 220; let inn = null;
  switch (type) {
    case 'pakker':
      inn = (<g>{[0, 1, 2].map((i) => <rect key={i} x={90 + i * 8} y={150 - i * 26} width={170} height={24} fill="#fff" {...ln} />)}
        <text x={180} y={200} textAnchor="middle" fontSize={20} fontWeight={900} fill={K}>48 t</text><text x={180} y={60} textAnchor="middle" fontSize={12} fontWeight={800} fill={K}>uåpnet · i rommet</text></g>);
      break;
    case 'lister':
      inn = (<g><line x1={40} y1={40} x2={40} y2={190} {...ln} strokeWidth={4} /><line x1={40} y1={190} x2={300} y2={190} {...ln} />
        <rect x={44} y={168} width={10} height={22} fill="#fff" {...ln} transform="rotate(-20 49 190)" /><path d="M70 150 l40 -30" {...ln} markerEnd="url(#pil)" /><Nr x={290} y={40} n={1} /></g>);
      break;
    case 'planhet':
      inn = (<g><path d="M30 170 Q120 160 170 172 T310 168" {...ln} /><rect x={50} y={146} width={240} height={10} fill="#fff" {...ln} />
        <Mal x1={170} y1={156} x2={170} y2={172} t="" side={0} /><text x={185} y={190} fontSize={12} fontWeight={900} fill={K}>maks ±3 mm</text>
        <Mal x1={50} y1={146} x2={290} y2={146} t="2 m" side={-14} /><OK x={310} y={60} ja /></g>);
      break;
    case 'fukt':
      inn = (<g><line x1={40} y1={40} x2={40} y2={180} {...ln} strokeWidth={4} /><rect x={40} y={180} width={270} height={16} fill="url(#skrav)" {...tynn} />
        <path d="M44 120 V176 H200" {...ln} stroke="#2a6fb0" strokeWidth={3} /><path d="M150 172 H300" {...ln} stroke="#2a6fb0" strokeWidth={3} strokeDasharray="1 0" />
        <Mal x1={150} y1={172} x2={200} y2={172} t="20 cm" side={-14} /><text x={60} y={112} fontSize={11} fontWeight={800} fill={K}>0,2 mm plast</text><text x={240} y={212} fontSize={11} fill={K}>betong</text></g>);
      break;
    case 'underlag':
      inn = (<g><rect x={40} y={170} width={270} height={10} fill="#fff" {...ln} /><rect x={40} y={180} width={270} height={16} fill="url(#skrav)" {...tynn} />
        <ellipse cx={270} cy={150} rx={20} ry={20} fill="#fff" {...ln} /><path d="M270 170 H120" {...tynn} /><text x={60} y={160} fontSize={11} fontWeight={800} fill={K}>underlag oppå plasten</text></g>);
      break;
    case 'retning':
      inn = (<g><rect x={60} y={40} width={220} height={140} fill="#fff" {...ln} strokeWidth={4} /><rect x={120} y={34} width={100} height={12} fill="#fff" {...ln} />
        <text x={170} y={28} textAnchor="middle" fontSize={11} fontWeight={800} fill={K}>vindu</text>
        {[0, 1, 2, 3, 4].map((i) => <line key={i} x1={90 + i * 40} y1={60} x2={90 + i * 40} y2={165} {...ln} markerEnd="url(#pil)" />)}<OK x={300} y={190} ja /></g>);
      break;
    case 'siste':
      inn = (<g><Rom g={g} rader={g.nRader} y0={36} max={130} />
        <text x={170} y={200} textAnchor="middle" fontSize={13} fontWeight={900} fill={K}>{g.nRader} rader · første {cm1(g.forste)} · siste {cm1(g.siste)} cm</text>
        <OK x={316} y={40} ja={!g.kappForste || g.siste >= 0.05} /></g>);
      break;
    case 'kiler':
      inn = (<g><line x1={40} y1={30} x2={40} y2={196} {...ln} strokeWidth={4} /><rect x={52} y={40} width={40} height={150} fill="url(#skrav)" {...ln} />
        {[70, 120, 170].map((y) => <path key={y} d={`M42 ${y} l8 -6 v12 z`} fill={K} />)}
        <Mal x1={42} y1={200} x2={52} y2={200} t="" side={0} /><text x={60} y={214} fontSize={12} fontWeight={900} fill={K}>8–10 mm</text><Nr x={110} y={40} n={1} /></g>);
      break;
    case 'klikk':
      inn = (<g><rect x={40} y={120} width={130} height={22} fill="#fff" {...ln} /><rect x={172} y={92} width={130} height={22} fill="#fff" {...ln} transform="rotate(-18 172 114)" />
        <path d="M230 60 q30 20 10 50" {...ln} markerEnd="url(#pil)" /><text x={250} y={170} fontSize={14} fontWeight={900} fill={K}>klikk!</text></g>);
      break;
    case 'skjot':
      inn = (<g>{[0, 1, 2].map((r) => <g key={r}><rect x={40} y={60 + r * 30} width={260} height={26} fill="#fff" {...ln} /><line x1={[210, 120, 250][r]} y1={60 + r * 30} x2={[210, 120, 250][r]} y2={86 + r * 30} {...ln} /></g>)}
        <Mal x1={120} y1={176} x2={210} y2={176} t="min. 30 cm" side={16} /><OK x={316} y={50} ja /></g>);
      break;
    case 'sisteRad':
      inn = (<g><line x1={300} y1={30} x2={300} y2={196} {...ln} strokeWidth={4} /><rect x={80} y={40} width={200} height={150} fill="#fff" {...ln} />
        <rect x={250} y={40} width={50} height={150} fill="url(#skrav)" {...tynn} /><Mal x1={250} y1={40} x2={299} y2={40} t={`${cm1(g.siste)} cm`} side={-14} /></g>);
      break;
    case 'ror':
      inn = (<g><rect x={40} y={40} width={260} height={150} fill="#fff" {...ln} /><circle cx={170} cy={110} r={10} fill={K} /><circle cx={170} cy={110} r={20} fill="none" {...tynn} strokeDasharray="4 3" />
        <text x={200} y={114} fontSize={12} fontWeight={800} fill={K}>8–10 mm</text></g>);
      break;
    case 'list':
      inn = (<g><line x1={100} y1={30} x2={100} y2={196} {...ln} strokeWidth={4} /><rect x={112} y={170} width={180} height={12} fill="#fff" {...ln} />
        <rect x={102} y={146} width={14} height={36} fill="#fff" {...ln} /><path d="M60 160 H102" {...ln} markerEnd="url(#pil)" /><text x={40} y={150} fontSize={11} fontWeight={800} fill={K}>i veggen</text>
        <OK x={250} y={110} ja /></g>);
      break;
    default:
      inn = (<g><Rom g={g} rader={g.nRader} /><OK x={316} y={40} ja /></g>);
  }
  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', display: 'block', background: '#fff' }} role="img" aria-label="Monteringstegning">
      <defs>
        <marker id="pil" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 1 L9 5 L0 9 z" fill={K} /></marker>
        <pattern id="skrav" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="6" stroke="#999" strokeWidth="1.5" /></pattern>
      </defs>
      {inn}
    </svg>
  );
}

const DEL_NAVN = {
  pakke: 'Gulvpakker', brekkjern: 'Brekkjern', stovsuger: 'Støvsuger', rettholt: 'Rettholt 2 m', fuktsperre: 'Fuktsperre 0,2 mm',
  tape: 'Tape', underlag: 'Parkettunderlag', maalebaand: 'Målebånd', kiler: 'Kiler 8–10 mm', bord: 'Gulvbord', slagkloss: 'Slagkloss',
  sag: 'Sag', bor: 'Bor', list: 'Gulvlist',
};

function GulvAnimasjon({ p, synlig, ny, Iso }) {
  const [t, setT] = useState(0);
  useEffect(() => {
    let id; const s = performance.now();
    const tikk = (n) => { setT(((n - s) / 1000) % 3.2); id = requestAnimationFrame(tikk); };
    const redusert = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if (!redusert) id = requestAnimationFrame(tikk); else setT(2);
    return () => cancelAnimationFrame(id);
  }, [ny.join()]);
  const fall = Math.max(0, 1 - t / 1.3); const e = fall * fall; const blink = t > 1.3 && t < 2.6;
  const bx = gulvBokser(p).filter((q) => synlig.has(q.tag) || ny.includes(q.tag)).map((q) => ny.includes(q.tag)
    ? { ...q, dz: e * 0.8, fall: true, c: blink || e > 0 ? '#f7b83f' : q.c } : q);
  return <Iso p={p} bokser={bx} vinkel={30} hoyde={240} interaktiv />;
}

export function gulvSynlig(alle, stegIdx, delIdx) {
  const synlig = new Set(['rom']);
  alle.forEach((ds, si) => ds.forEach((x, di) => { if (si < stegIdx || (si === stegIdx && di < delIdx)) x.ny.forEach((tg) => synlig.add(tg)); }));
  if (synlig.has('list')) synlig.delete('kiler');
  return synlig;
}

export function GulvManual({ p, stegIdx, delIdx, settDel, kryss, vend, Iso, C }) {
  const alle = gulvDeler(p); const deler = alle[stegIdx]; const d = deler[Math.min(delIdx, deler.length - 1)];
  const g = gulvGeo(p.mal); const video = GULV_VIDEO[stegIdx];
  const [vis, setVis] = useState('tegning');
  useEffect(() => { if (vis === 'video' && !video) setVis('tegning'); }, [video, vis]);
  const synlig = gulvSynlig(alle, stegIdx, delIdx);
  const ny = d.ny;
  const faner = [['tegning', 'Tegning'], ['3d', '3D'], ...(video ? [['video', 'Video']] : [])];
  const fn = { border: 0, borderRadius: 9, padding: '8px 0', fontWeight: 800, fontSize: 13, flex: 1 };
  const gul = { background: '#4a3a12', border: '1px solid #f7b83f', borderRadius: 10, padding: 10, fontSize: 13, marginBottom: 8 };
  return (
    <div>
      {stegIdx === 0 && delIdx === 0 && <>
        <div style={gul}>⚠️ Følg alltid leggeanvisningen i pakken med ditt gulv. Denne guiden gjelder flytende klikkgulv (laminat eller parkett).</div>
        {g.varsler.map((v, i) => <div key={i} style={gul}>⚠️ {v}</div>)}
      </>}
      <div style={{ display: 'flex', gap: 6, marginBottom: 8, background: '#ffffff10', padding: 4, borderRadius: 12 }}>
        {faner.map(([k, t]) => <button key={k} onClick={() => setVis(k)} style={{ ...fn, background: vis === k ? C.gold : 'transparent', color: vis === k ? C.ink : 'white' }}>{t}</button>)}
      </div>
      <div style={{ borderRadius: 12, overflow: 'hidden', background: '#fff', position: 'relative' }}>
        {vis === 'tegning' && <GulvTegning type={d.tegning} g={g} />}
        {vis === '3d' && <div style={{ background: '#FBFBF9' }}><GulvAnimasjon p={p} synlig={synlig} ny={ny} Iso={Iso} /></div>}
        {vis === 'video' && <video src={video} controls playsInline style={{ width: '100%', display: 'block', background: '#000' }} />}
        <div style={{ position: 'absolute', left: 8, top: 8, background: C.ink, color: 'white', borderRadius: 8, padding: '3px 8px', fontWeight: 900, fontSize: 13 }}>{stegIdx + 1}.{delIdx + 1}</div>
      </div>
      {d.deler.filter(([, n]) => n > 0).length > 0 && (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 8 }}>
          {d.deler.filter(([, n]) => n > 0).map(([k, n]) => <span key={k} style={{ background: '#fff', color: C.ink, borderRadius: 8, padding: '4px 8px', fontSize: 12, fontWeight: 800 }}>{n > 1 ? `${n} × ` : ''}{DEL_NAVN[k]}</span>)}
        </div>
      )}
      <div style={{ marginTop: 10, fontWeight: 800, fontSize: 17 }}>{d.tittel}</div>
      <p style={{ margin: '6px 0 0', fontSize: 15, lineHeight: 1.5, color: '#dfe8ef' }}>{d.tekst}</p>
      <div style={{ display: 'flex', gap: 6, marginTop: 12 }}>
        {deler.map((x, k) => (
          <button key={k} aria-label={`Del ${k + 1}: ${x.tittel}`} onClick={() => settDel(k)} style={{ flex: 1, height: 8, border: 0, borderRadius: 4, padding: 0, background: kryss[k] ? C.ok : k === delIdx ? C.gold : '#ffffff30' }} />
        ))}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 8, marginTop: 10 }}>
        <button disabled={delIdx === 0} onClick={() => settDel(delIdx - 1)} style={{ border: '1px solid #ffffff30', background: '#ffffff14', color: 'white', borderRadius: 12, padding: 12, fontWeight: 800, opacity: delIdx === 0 ? 0.4 : 1 }}>Forrige</button>
        <button onClick={() => { if (!kryss[delIdx]) vend(delIdx); if (delIdx + 1 < deler.length) settDel(delIdx + 1); }} style={{ border: 0, background: kryss[delIdx] ? C.ok : 'white', color: C.ink, borderRadius: 12, padding: 12, fontWeight: 900 }}>
          {kryss[delIdx] ? '✓ Gjort' : 'Gjort'}{delIdx + 1 < deler.length ? ' – neste del' : ''}
        </button>
      </div>
    </div>
  );
}
