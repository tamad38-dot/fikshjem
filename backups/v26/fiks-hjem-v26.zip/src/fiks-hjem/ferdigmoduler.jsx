import React, { useState } from 'react';

/* ================================================================
   FERDIGE BYGGMODULER MED EGNE TEGNINGER
   ----------------------------------------------------------------
   Hver modul har ferdige standardmål, en enkel fagtegning (oppriss med
   mål) og et veiledende prisintervall. Da kan modulen settes rett inn i
   3D-rommet, og byttes ut med en annen, uten at noe må måles først.
   Målene kan alltid justeres etterpå i 3D-panelet.
   ================================================================ */

export const FERDIGMODULER = [
  { id: 'vindu-12', navn: 'Vindu 1,2 × 1,2 m', type: 'vindu', gruppe: 'Vindu og dør', tegning: 'vindu', bredde: 1.2, hoyde: 1.2, dybde: 0.1, y: 0.9, prisFra: 6500, prisTil: 14000, note: 'Toppsving, 2-lags glass' },
  { id: 'vindu-18', navn: 'Vindu 1,8 × 1,2 m', type: 'vindu', gruppe: 'Vindu og dør', tegning: 'vindu', bredde: 1.8, hoyde: 1.2, dybde: 0.1, y: 0.9, prisFra: 8500, prisTil: 18000, note: 'To rammer, fast midtpost' },
  { id: 'vindu-bad', navn: 'Vindu bad 0,8 × 0,8 m', type: 'vindu', gruppe: 'Vindu og dør', tegning: 'vindu', bredde: 0.8, hoyde: 0.8, dybde: 0.1, y: 1.35, prisFra: 4500, prisTil: 9500, note: 'Frostet glass' },
  { id: 'balkongdor', navn: 'Balkongdør 0,9 × 2,1 m', type: 'dor', gruppe: 'Vindu og dør', tegning: 'dor', bredde: 0.9, hoyde: 2.1, dybde: 0.1, y: 0, prisFra: 9000, prisTil: 19000, note: 'Glass i hele døra' },
  { id: 'ytterdor', navn: 'Ytterdør 1,0 × 2,1 m', type: 'dor', gruppe: 'Vindu og dør', tegning: 'dor', bredde: 1.0, hoyde: 2.1, dybde: 0.1, y: 0, prisFra: 12000, prisTil: 28000, note: 'Isolert, med lås' },
  { id: 'innerdor', navn: 'Innerdør 0,9 × 2,0 m', type: 'dor', gruppe: 'Vindu og dør', tegning: 'dor', bredde: 0.9, hoyde: 2.0, dybde: 0.08, y: 0, prisFra: 2500, prisTil: 7000, note: 'Med karm og gerikt' },
  { id: 'kjokken-36', navn: 'Kjøkken 3,6 m', type: 'vegg', gruppe: 'Innredning', tegning: 'skap', bredde: 3.6, hoyde: 0.9, dybde: 0.65, y: 0, prisFra: 45000, prisTil: 140000, note: 'Underskap med benkeplate' },
  { id: 'kjokken-overskap', navn: 'Overskap 2,4 m', type: 'vegg', gruppe: 'Innredning', tegning: 'skap', bredde: 2.4, hoyde: 0.7, dybde: 0.35, y: 1.5, prisFra: 12000, prisTil: 38000, note: 'Henges på vegg' },
  { id: 'baderomsinnredning', navn: 'Baderomsinnredning 1,2 m', type: 'vegg', gruppe: 'Innredning', tegning: 'skap', bredde: 1.2, hoyde: 0.9, dybde: 0.55, y: 0, prisFra: 9000, prisTil: 32000, note: 'Servant og underskap' },
  { id: 'dusjhjorne', navn: 'Dusjhjørne 0,9 × 0,9 m', type: 'vegg', gruppe: 'Innredning', tegning: 'skap', bredde: 0.9, hoyde: 2.0, dybde: 0.9, y: 0, prisFra: 7000, prisTil: 22000, note: 'Med dusjvegger' },
  { id: 'garderobe', navn: 'Garderobeskap 2,0 m', type: 'vegg', gruppe: 'Innredning', tegning: 'skap', bredde: 2.0, hoyde: 2.4, dybde: 0.6, y: 0, prisFra: 8000, prisTil: 30000, note: 'Gulv til tak' },
  { id: 'trapp-rett', navn: 'Rett trapp 0,9 m bred', type: 'trapp', gruppe: 'Konstruksjon', tegning: 'trapp', bredde: 0.9, hoyde: 2.4, dybde: 3.6, y: 0, prisFra: 25000, prisTil: 90000, note: '14 trinn, rett løp' },
  { id: 'lettvegg', navn: 'Lettvegg 2,4 m', type: 'vegg', gruppe: 'Konstruksjon', tegning: 'vegg', bredde: 2.4, hoyde: 2.4, dybde: 0.1, y: 0, prisFra: 4500, prisTil: 14000, note: '48 × 98 stendere og gips' },
  { id: 'peis', navn: 'Peisovn 0,6 × 1,2 m', type: 'vegg', gruppe: 'Innredning', tegning: 'skap', bredde: 0.6, hoyde: 1.2, dybde: 0.5, y: 0, prisFra: 18000, prisTil: 55000, note: 'Inkl. montering og pipe' },
];

export const FERDIGMODUL_GRUPPER = ['Alle', ...Array.from(new Set(FERDIGMODULER.map((m) => m.gruppe)))];

const T = {
  kort: { border: '1px solid #DDE2DC', borderRadius: 12, padding: 10, background: '#fff', display: 'grid', gap: 6 },
  rutenett: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: 10 },
  navn: { fontSize: 13, fontWeight: 700, color: '#1C2321', lineHeight: 1.3 },
  smaa: { fontSize: 11, color: '#8A938C', lineHeight: 1.4 },
  pris: { fontSize: 12, fontWeight: 600, color: '#2F5F55' },
  knapp: { width: '100%', padding: '8px 10px', borderRadius: 10, border: 'none', background: '#2F5F55', color: '#fff', fontSize: 12, fontWeight: 700, cursor: 'pointer' },
  knappSek: { width: '100%', padding: '8px 10px', borderRadius: 10, border: '1px solid #C8D0C8', background: '#fff', color: '#1C2321', fontSize: 12, fontWeight: 600, cursor: 'pointer' },
  rad: { display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', borderTop: '1px solid #EDF0EC', paddingTop: 8 },
  velg: { flex: 1, minWidth: 140, padding: '7px 8px', borderRadius: 8, border: '1px solid #C8D0C8', fontSize: 12, background: '#fff' },
};

const kr = (n) => Math.round(n).toLocaleString('no-NO');

const DELER = {
  vindu: ['Karm', 'Ramme / glass', 'Feste og tetting'],
  dor: ['Karm', 'Dørblad', 'Terskel og tetting'],
  skap: ['Skrog', 'Front / innredning', 'Feste mot vegg'],
  vegg: ['Bunn- og toppsvill', 'Stendere c/c 600', 'Platekledning'],
  trapp: ['Vanger', 'Trinn', 'Rekkverk og feste'],
};

function Delmerke({ nr, x, y }) {
  return (
    <g aria-label={`Del ${nr}`}>
      <circle cx={x} cy={y} r="7" fill="#E3B341" stroke="#1C2321" strokeWidth="1" />
      <text x={x} y={y + 2.5} textAnchor="middle" fontSize="7" fontWeight="700" fill="#1C2321">{nr}</text>
    </g>
  );
}

/** Enkel fagtegning (oppriss) av modulen, med målsetting. */
export function ModulTegning({ modul, hoydeAvBilde = 128 }) {
  const b = Math.max(0.2, modul.bredde);
  const h = Math.max(0.2, modul.tegning === 'trapp' ? modul.hoyde : modul.hoyde);
  const skala = Math.min(132 / b, (hoydeAvBilde - 38) / h);
  const w = b * skala;
  const ht = h * skala;
  const x0 = (170 - w) / 2;
  const y0 = hoydeAvBilde - ht - 25;
  const strek = { stroke: '#2F5F55', fill: 'none', strokeWidth: 1.2 };
  return (
    <svg viewBox={`0 0 170 ${hoydeAvBilde}`} width="100%" height={hoydeAvBilde} role="img"
      aria-label={`Detaljert arbeidstegning av ${modul.navn}`} style={{ background: '#F6F7F4', borderRadius: 8 }}>
      <text x="8" y="11" fontSize="7" fontWeight="700" fill="#1C2321">MONTERINGSOVERSIKT</text>
      <text x="162" y="11" textAnchor="end" fontSize="6" fill="#5C665E">Alle mål kontrolleres på stedet</text>
      <rect x={x0} y={y0} width={w} height={ht} {...strek} fill="#fff" />
      {modul.tegning === 'vindu' ? (
        <>
          <rect x={x0 + 4} y={y0 + 4} width={w - 8} height={ht - 8} {...strek} strokeWidth={0.8} fill="#EAF1F3" />
          <line x1={x0 + w / 2} y1={y0 + 4} x2={x0 + w / 2} y2={y0 + ht - 4} {...strek} strokeWidth={0.8} />
        </>
      ) : null}
      {modul.tegning === 'dor' ? (
        <>
          <rect x={x0 + 4} y={y0 + 4} width={w - 8} height={ht - 8} {...strek} strokeWidth={0.8} fill="#F3EDE7" />
          <circle cx={x0 + w - 10} cy={y0 + ht / 2} r={2} fill="#2F5F55" />
        </>
      ) : null}
      {modul.tegning === 'skap' ? (
        <>
          <line x1={x0 + w / 2} y1={y0} x2={x0 + w / 2} y2={y0 + ht} {...strek} strokeWidth={0.8} />
          <line x1={x0} y1={y0 + ht * 0.35} x2={x0 + w} y2={y0 + ht * 0.35} {...strek} strokeWidth={0.8} />
        </>
      ) : null}
      {modul.tegning === 'vegg' ? (
        Array.from({ length: 5 }).map((_, i) => (
          <line key={i} x1={x0 + (w / 5) * (i + 0.5)} y1={y0} x2={x0 + (w / 5) * (i + 0.5)} y2={y0 + ht} {...strek} strokeWidth={0.7} strokeDasharray="3 3" />
        ))
      ) : null}
      {modul.tegning === 'trapp' ? (
        Array.from({ length: 7 }).map((_, i) => (
          <polyline key={i} points={`${x0},${y0 + ht - (ht / 7) * i} ${x0 + (w / 7) * (i + 1)},${y0 + ht - (ht / 7) * i} ${x0 + (w / 7) * (i + 1)},${y0 + ht - (ht / 7) * (i + 1)}`} {...strek} strokeWidth={0.8} />
        ))
      ) : null}
      <Delmerke nr="1" x={x0 + Math.min(10, w * 0.18)} y={y0 + Math.min(10, ht * 0.22)} />
      <Delmerke nr="2" x={x0 + w / 2} y={y0 + ht / 2} />
      <Delmerke nr="3" x={x0 + w - Math.min(9, w * 0.16)} y={y0 + ht - Math.min(9, ht * 0.18)} />
      <line x1={x0} y1={hoydeAvBilde - 13} x2={x0 + w} y2={hoydeAvBilde - 13} stroke="#5C665E" strokeWidth={0.8} />
      <line x1={x0} y1={hoydeAvBilde - 17} x2={x0} y2={hoydeAvBilde - 9} stroke="#5C665E" strokeWidth={0.8} />
      <line x1={x0 + w} y1={hoydeAvBilde - 17} x2={x0 + w} y2={hoydeAvBilde - 9} stroke="#5C665E" strokeWidth={0.8} />
      <text x={x0 + w / 2} y={hoydeAvBilde - 3} textAnchor="middle" fontSize="7" fill="#1C2321">B {modul.bredde.toFixed(2)} m</text>
      <line x1={x0 - 9} y1={y0} x2={x0 - 9} y2={y0 + ht} stroke="#5C665E" strokeWidth={0.8} />
      <line x1={x0 - 13} y1={y0} x2={x0 - 5} y2={y0} stroke="#5C665E" strokeWidth={0.8} />
      <line x1={x0 - 13} y1={y0 + ht} x2={x0 - 5} y2={y0 + ht} stroke="#5C665E" strokeWidth={0.8} />
      <text x={x0 - 14} y={y0 + ht / 2} textAnchor="middle" fontSize="7" fill="#1C2321" transform={`rotate(-90 ${x0 - 14} ${y0 + ht / 2})`}>H {modul.hoyde.toFixed(2)} m</text>
    </svg>
  );
}

/**
 * Bibliotek med ferdige moduler + liste over modulene som allerede står i 3D,
 * der hver enkelt kan byttes ut med en annen modul uten ny måling.
 */
export function ModulBibliotek({ plasseringer, onSettInn, onBytt, onFjern, kanSetteInn }) {
  const [gruppe, setGruppe] = useState('Alle');
  const liste = FERDIGMODULER.filter((m) => gruppe === 'Alle' || m.gruppe === gruppe);
  const satteInn = (plasseringer || []).filter((p) => p.modulId);
  return (
    <div style={{ display: 'grid', gap: 12 }}>
      <select style={T.velg} value={gruppe} onChange={(e) => setGruppe(e.target.value)} aria-label="Velg gruppe">
        {FERDIGMODUL_GRUPPER.map((g) => <option key={g} value={g}>{g}</option>)}
      </select>
      <div style={T.rutenett}>
        {liste.map((modul) => (
          <div key={modul.id} style={T.kort}>
            <ModulTegning modul={modul} />
            <div style={T.navn}>{modul.navn}</div>
            <div style={T.smaa}>{modul.note}</div>
            <div style={{ display: 'grid', gap: 3, padding: '7px 0', borderTop: '1px solid #EDF0EC', borderBottom: '1px solid #EDF0EC' }}>
              {(DELER[modul.tegning] || DELER.skap).map((del, i) => (
                <div key={del} style={{ ...T.smaa, color: '#1C2321', display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{ width: 17, height: 17, display: 'inline-grid', placeItems: 'center', borderRadius: '50%', background: '#E3B341', fontSize: 9, fontWeight: 800 }}>{i + 1}</span>
                  {del}
                </div>
              ))}
              <div style={{ ...T.smaa, marginTop: 3 }}>Dybde: {modul.dybde.toFixed(2)} m · Kontroller lodd, vater og feste.</div>
            </div>
            <div style={T.pris}>{kr(modul.prisFra)}–{kr(modul.prisTil)} kr</div>
            <button type="button" style={{ ...T.knapp, opacity: kanSetteInn ? 1 : 0.5 }} disabled={!kanSetteInn}
              onClick={() => onSettInn(modul)}>Sett inn i 3D</button>
          </div>
        ))}
      </div>
      {satteInn.length ? (
        <div style={{ display: 'grid', gap: 8 }} data-tf="innsatte-moduler">
          <div style={T.navn}>Moduler i 3D-rommet</div>
          {satteInn.map((p) => (
            <div key={p.id} style={T.rad}>
              <span style={{ fontSize: 12, flex: 1, minWidth: 120 }}>{p.navn}</span>
              <select
                style={T.velg}
                value={p.modulId}
                aria-label={'Bytt ut ' + p.navn}
                onChange={(e) => onBytt(p.id, FERDIGMODULER.find((m) => m.id === e.target.value))}
              >
                {FERDIGMODULER.map((m) => <option key={m.id} value={m.id}>Bytt til: {m.navn}</option>)}
              </select>
              <button type="button" style={{ ...T.knappSek, width: 'auto' }} onClick={() => onFjern(p.id)}>Fjern</button>
            </div>
          ))}
        </div>
      ) : (
        <div style={T.smaa}>Ingen ferdigmoduler er satt inn ennå. Velg en modul over, så havner den midt i rommet du har valgt.</div>
      )}
    </div>
  );
}
