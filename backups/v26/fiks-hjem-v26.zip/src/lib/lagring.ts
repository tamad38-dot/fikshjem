/* Varig lagring på telefonen.

   Appen lagrer prosjekter, handleliste og byggemoduler i localStorage.
   I en iOS-app er det usikkert: iOS kan tømme nettleserlageret når telefonen
   trenger plass, og da er brukerens prosjekter borte.

   Løsningen her endrer ingen annen kode: alt som skrives til localStorage
   speiles også til Capacitor Preferences (lagres som vanlige appdata).
   Når appen starter, legges det som ligger i Preferences tilbake i
   localStorage før første skjerm vises. I nettleseren gjør dette ingenting. */
import { Capacitor } from '@capacitor/core';
import { Preferences } from '@capacitor/preferences';

let startet = false;

export async function startLagring(): Promise<void> {
  if (startet) return;
  startet = true;
  if (!Capacitor.isNativePlatform()) return;

  try {
    const { keys } = await Preferences.keys();
    const lagret = new Set(keys);
    // 1) Preferences er fasiten: legg det tilbake i localStorage.
    for (const k of keys) {
      const { value } = await Preferences.get({ key: k });
      if (value !== null) localStorage.setItem(k, value);
    }
    // 2) Det som bare finnes i localStorage (data fra før denne versjonen) flyttes opp.
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k === null || lagret.has(k)) continue;
      const v = localStorage.getItem(k);
      if (v !== null) await Preferences.set({ key: k, value: v });
    }
  } catch {
    /* Preferences svarte ikke: appen kjører videre på localStorage alene. */
  }

  // 3) Speil alle senere endringer.
  const set = Storage.prototype.setItem;
  const fjern = Storage.prototype.removeItem;
  const tom = Storage.prototype.clear;
  Storage.prototype.setItem = function (this: Storage, k: string, v: string) {
    set.call(this, k, v);
    if (this === window.localStorage) void Preferences.set({ key: String(k), value: String(v) }).catch(() => {});
  };
  Storage.prototype.removeItem = function (this: Storage, k: string) {
    fjern.call(this, k);
    if (this === window.localStorage) void Preferences.remove({ key: String(k) }).catch(() => {});
  };
  Storage.prototype.clear = function (this: Storage) {
    tom.call(this);
    if (this === window.localStorage) void Preferences.clear().catch(() => {});
  };
}
