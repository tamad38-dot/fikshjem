/* Telefonens egen AI (Apple Foundation Models, iOS 26+ med Apple Intelligence).

   Rekkefølgen for AI i appen:
     1. Telefonens egen AI, hvis den finnes: gratis, uten nett, uten nøkkel.
     2. Ellers brukerens egen API-nøkkel, som før.
     3. Ellers ingen AI – appen virker fullt ut uten.

   Swift-delen ligger i native-plugins/fiks-lokal-ai. I nettleseren og på
   eldre telefoner svarer lokalAIFinnes() alltid false. */
import { Capacitor, registerPlugin } from '@capacitor/core';

type Status = { ok: boolean; grunn?: string; vision?: boolean; bilde?: boolean };
export type BildeSvar = {
  koder: { type: string; verdi: string }[];
  tekst: string;   // tekst Vision leste på etiketten
  svar: string;    // JSON-svar fra telefonens AI, eller tom streng
  kilde: 'vision' | 'tekstmodell' | 'bilde';
};
type LokalAI = {
  tilgjengelig(): Promise<Status>;
  svar(o: { prompt: string; system?: string }): Promise<{ tekst: string }>;
  lesBilde(o: { bilde: string; prompt?: string }): Promise<BildeSvar>;
};

const Lokal = registerPlugin<LokalAI>('FiksLokalAI');
let sjekk: Promise<Status> | null = null;

function status(): Promise<Status> {
  try {
    if (!Capacitor.isNativePlatform() || !Capacitor.isPluginAvailable('FiksLokalAI')) return Promise.resolve({ ok: false });
  } catch {
    return Promise.resolve({ ok: false });
  }
  if (!sjekk) sjekk = Lokal.tilgjengelig().catch(() => ({ ok: false }));
  return sjekk;
}

/** Tekst-AI på telefonen (iOS 26+ med Apple Intelligence). */
export function lokalAIFinnes(): Promise<boolean> {
  return status().then((s) => !!s.ok);
}

/** Bildelesing på telefonen: strekkode og tekst virker på alle iPhoner i appen. */
export function lokalBildeFinnes(): Promise<boolean> {
  return status().then((s) => !!s.vision);
}

export async function lokalSvar(prompt: string, system = ''): Promise<string> {
  const r = await Lokal.svar({ prompt, system });
  return (r.tekst || '').trim();
}

export async function lokalBilde(base64: string, prompt = ''): Promise<BildeSvar> {
  const r = await Lokal.lesBilde({ bilde: base64, prompt });
  return { koder: r.koder || [], tekst: (r.tekst || '').trim(), svar: (r.svar || '').trim(), kilde: r.kilde || 'vision' };
}

// Samme funksjoner for den store TamerFixApp-filen, uten ny import der.
try {
  (window as unknown as { FIKS_LOKAL_AI?: unknown }).FIKS_LOKAL_AI = {
    finnes: lokalAIFinnes, svar: lokalSvar, bildeFinnes: lokalBildeFinnes, bilde: lokalBilde,
  };
} catch { /* ingen window */ }
