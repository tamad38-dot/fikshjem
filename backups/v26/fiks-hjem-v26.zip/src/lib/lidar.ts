/* LiDAR på iPhone: måling (ARKit) og romskanning (RoomPlan).

   Swift-delen ligger i native-plugins/fiks-lidar. Her kobles den til appen
   gjennom de samme «krokene» modulene allerede venter på:
     window.TAMERFIX_MAAL_AR()   → meter (tall) eller null hvis avbrutt
     window.TAMERFIX_SKANN_ROM() → rådata fra RoomPlan, eller null
   Finnes ikke krokene (nettleser, Android, telefon uten støtte), skjuler
   appen knappene, og alt annet virker som før med mål du skriver inn. */
import { Capacitor, registerPlugin } from '@capacitor/core';

type Status = { ar: boolean; lidar: boolean; rom: boolean };
type LidarPlugin = {
  status(): Promise<Status>;
  maal(): Promise<{ meter?: number; avbrutt?: boolean }>;
  skannRom(): Promise<Record<string, unknown> & { avbrutt?: boolean }>;
};

const Lidar = registerPlugin<LidarPlugin>('FiksLidar');

export async function startLidar(): Promise<Status | null> {
  try {
    if (!Capacitor.isNativePlatform() || !Capacitor.isPluginAvailable('FiksLidar')) return null;
    const s = await Promise.race([
      Lidar.status(),
      new Promise<null>((ok) => setTimeout(() => ok(null), 1500)),
    ]);
    if (!s) return null;
    const w = window as unknown as Record<string, unknown>;
    if (s.ar) {
      w.TAMERFIX_MAAL_AR = async () => {
        const r = await Lidar.maal();
        return r && !r.avbrutt && typeof r.meter === 'number' ? r.meter : null;
      };
    }
    if (s.rom) {
      w.TAMERFIX_SKANN_ROM = async () => {
        const r = await Lidar.skannRom();
        return r && !r.avbrutt ? r : null;
      };
    }
    w.FIKS_LIDAR = s;
    return s;
  } catch {
    return null;
  }
}
