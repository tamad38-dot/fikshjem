/* AI-hjelp til fagtekst på byggesakstegninger.
   Kjører i appen (ingen server, ingen Lovable). Først prøves telefonens egen AI
   (Apple, iOS 26+). Finnes den ikke, brukes KUN brukerens egen Anthropic-nøkkel.
   Uten noen av delene: ingen AI, ingen kostnad – brukeren bruker standardteksten. */
import { lokalAIFinnes, lokalSvar } from './lokalAI';

type Inn = {
  arkType: string; arkTittel: string; maalestokk?: string; adresse?: string; gnr?: string; bnr?: string;
  kommune?: string; areal?: number; takhoyde?: number; takform?: string; takvinkel?: number;
  rom?: string[]; jobber?: string[]; beskrivelse?: string; boligtype?: string; krav?: string[];
};
type Svar = { ok: boolean; tekst: string; feil: string };

export async function lagFagtekst({ data: d }: { data: Inn }): Promise<Svar> {
  const krav = d.krav ?? [];
  const prompt = [
    `Skriv fagteksten som skal stå på arket "${d.arkTittel}" (${d.arkType}, målestokk ${d.maalestokk || '1:100'}) i en norsk byggesøknad.`,
    `Eiendom: ${d.adresse || 'adresse ikke oppgitt'}, gnr ${d.gnr || '–'} bnr ${d.bnr || '–'}, ${d.kommune || ''} kommune.`,
    `Bygget: ${d.areal ?? 0} m², takhøyde ${d.takhoyde ?? 2.4} m, ${d.takform || 'saltak'} ${d.takvinkel ?? 30}°. Rom: ${(d.rom ?? []).join(', ') || 'ikke oppgitt'}.`,
    `Fagjobber: ${(d.jobber ?? []).join(', ') || 'ingen oppgitt'}.`,
    `Boligtype: ${d.boligtype || 'villa'}. Tilpass ordbruk og krav til denne boligtypen (leilighet: brannskille, lyd og sameie/seksjon; rekkehus: brannvegg mot nabo og lydkrav; villa: frittliggende enebolig).`,
    krav.length ? `Krav fra kommunen som MÅ omtales punkt for punkt: ${krav.join('; ')}.` : '',
    d.beskrivelse ? `Tiltaket: ${d.beskrivelse}` : '',
    'Svar med 3–5 korte punkter på norsk bokmål, uten overskrift, uten markdown-tegn. Vis til TEK17 der det er naturlig. Maks 90 ord totalt. Ikke finn på mål som ikke er oppgitt.',
  ].filter(Boolean).join('\n');

  const system = 'Du er en norsk byggesaksrådgiver som skriver knappe, presise fagtekster på byggesakstegninger.';

  // 1) Telefonens egen AI først.
  if (await lokalAIFinnes()) {
    try {
      const t = await lokalSvar(prompt, system);
      if (t) return { ok: true, tekst: t, feil: '' };
    } catch { /* faller videre til egen nøkkel */ }
  }

  // 2) Brukerens egen nøkkel.
  const nokkel = (globalThis as unknown as { __FH_EGEN_NOKKEL?: string | null }).__FH_EGEN_NOKKEL;
  if (!nokkel) return { ok: false, tekst: '', feil: 'AI-hjelp krever telefonens egen AI (iOS 26+) eller din egen API-nøkkel (legg den inn i innstillingene). Bruk standardteksten så lenge.' };

  let res: Response;
  try {
    res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': nokkel,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 900,
        system,
        messages: [{ role: 'user', content: prompt }],
      }),
    });
  } catch {
    return { ok: false, tekst: '', feil: 'Ingen nettforbindelse. Bruk standardteksten.' };
  }
  if (!res.ok) {
    if (res.status === 401) return { ok: false, tekst: '', feil: 'API-nøkkelen ble avvist. Sjekk den i innstillingene.' };
    if (res.status === 429) return { ok: false, tekst: '', feil: 'AI-hjelpen er travel akkurat nå. Prøv igjen om litt.' };
    return { ok: false, tekst: '', feil: 'AI-hjelpen svarte ikke (' + res.status + ').' };
  }
  const json = (await res.json()) as { content?: Array<{ type: string; text?: string }> };
  const tekst = (json.content ?? []).filter((b) => b.type === 'text').map((b) => b.text ?? '').join('').trim();
  return tekst ? { ok: true, tekst, feil: '' } : { ok: false, tekst: '', feil: 'AI-hjelpen ga tomt svar. Prøv igjen.' };
}
