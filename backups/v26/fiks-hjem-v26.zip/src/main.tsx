import { StrictMode, Suspense, lazy } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';
import { startLagring } from './lib/lagring';
import { lokalAIFinnes } from './lib/lokalAI';
import { startLidar } from './lib/lidar';

/* Appen starter på den egentlige Fiks hjem-skjermen (TamerFixApp):
   søk, Skann/Beregn-kortet med håndverkerbildet, Byggemoduler, Boligen og «Fra Fiks hjem».
   I v23 startet den på en annen skisse (ModernFiksApp). Den fila ligger fortsatt i
   prosjektet, men brukes ikke. */
const TamerFixApp = lazy(() => import('./fiks-hjem/TamerFixApp.jsx'));

/* Lagring for TamerFixApp: localStorage med prefiks «fh_tf_».
   lagring.ts speiler den videre til Capacitor Preferences på iPhone. */
const TF = 'fh_tf_';
try {
  const w = window as unknown as { TAMERFIX_STORAGE?: unknown; storage?: unknown };
  if (!w.TAMERFIX_STORAGE && !w.storage && window.localStorage) {
    w.TAMERFIX_STORAGE = {
      async get(k: string) { const v = localStorage.getItem(TF + k); if (v === null) throw new Error('not found'); return { key: k, value: v }; },
      async set(k: string, v: string) { localStorage.setItem(TF + k, v); return { key: k, value: v }; },
      async delete(k: string) { localStorage.removeItem(TF + k); return { key: k, deleted: true }; },
      async list() { return { keys: Object.keys(localStorage).filter((x) => x.startsWith(TF)).map((x) => x.slice(TF.length)) }; },
    };
  }
} catch { /* lagring blokkert — minnet brukes */ }

// Sjekken startes tidlig, og importen kan ikke fjernes av byggeverktøyet.
void lokalAIFinnes();

// LiDAR-krokene må være på plass før første skjerm, ellers vises ikke målerknappene.
Promise.allSettled([startLagring(), startLidar()]).finally(() => {
  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <Suspense fallback={<div style={{ minHeight: '100vh', background: '#061b2d' }} />}>
        <TamerFixApp />
      </Suspense>
    </StrictMode>,
  );
});
