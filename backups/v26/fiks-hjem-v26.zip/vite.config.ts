import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import tsconfigPaths from 'vite-tsconfig-paths';

// Vanlig, åpen Vite-oppsett. Ingen leverandørbinding.
// `npm run build` lager en statisk mappe `dist/` som kan legges på
// hvilken som helst webhotell (Netlify, Vercel, GitHub Pages, Cloudflare Pages)
// eller pakkes med Capacitor til iOS/Android (webDir: "dist").
export default defineConfig({
  base: './',
  plugins: [react(), tailwindcss(), tsconfigPaths()],
});
