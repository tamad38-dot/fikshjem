/* Fiks hjem / FixOne – felles zoom for bilder du merker på.
 *
 * Én finger = sett og flytt punkter (som før).
 * To fingre = knip for å zoome, dra for å flytte bildet.
 * PC: Ctrl/⌘ + rulling, eller knappene + / − / Tilpass.
 *
 * Zoomen er en CSS-transform på flaten. getBoundingClientRect() tar med
 * transformen, så koden som regner ut hvor du trykket, treffer riktig
 * uten endringer. Flaten får CSS-variabelen --z = 1/skala, slik at punkter
 * og etiketter kan holde samme størrelse på skjermen mens bildet forstørres.
 *
 * lagZoom(boks, flate, { maks, onPinchStart, etter }) -> { inn, ut, tilpass, aktiv(), skala() }
 */
(function () {
  function lagZoom(boks, flate, opt) {
    opt = opt || {};
    var maks = opt.maks || 8;
    var z = { s: 1, x: 0, y: 0 };
    var pek = new Map();
    var pinch = false, start = null;

    flate.style.transformOrigin = '0 0';
    flate.style.willChange = 'transform';

    function bruk() {
      var w = boks.clientWidth, h = boks.clientHeight;
      z.s = Math.max(1, Math.min(maks, z.s));
      z.x = Math.min(0, Math.max(w - w * z.s, z.x));
      z.y = Math.min(0, Math.max(h - h * z.s, z.y));
      flate.style.transform = 'translate(' + z.x + 'px,' + z.y + 'px) scale(' + z.s + ')';
      flate.style.setProperty('--z', String(1 / z.s));
      if (opt.etter) opt.etter(z.s);
    }
    // Zoom rundt et punkt (klientkoordinater), slik at det som er under fingeren blir der.
    function zoomRundt(ny, cx, cy) {
      var r = boks.getBoundingClientRect();
      var px = (cx - r.left - z.x) / z.s, py = (cy - r.top - z.y) / z.s;
      z.s = Math.max(1, Math.min(maks, ny));
      z.x = cx - r.left - px * z.s;
      z.y = cy - r.top - py * z.s;
      bruk();
    }
    function midt() {
      var a = Array.from(pek.values());
      return { x: (a[0].x + a[1].x) / 2, y: (a[0].y + a[1].y) / 2, d: Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y) };
    }

    boks.addEventListener('pointerdown', function (e) {
      pek.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pek.size === 2) {
        pinch = true;
        var m = midt(), r = boks.getBoundingClientRect();
        start = { mx: m.x, my: m.y, d: Math.max(1, m.d), s: z.s, px: (m.x - r.left - z.x) / z.s, py: (m.y - r.top - z.y) / z.s };
        if (opt.onPinchStart) opt.onPinchStart();
        e.stopPropagation(); e.preventDefault();
      } else if (pinch) { e.stopPropagation(); e.preventDefault(); }
    }, true);

    boks.addEventListener('pointermove', function (e) {
      if (pek.has(e.pointerId)) pek.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (!pinch) return;
      e.stopPropagation(); e.preventDefault();
      if (pek.size < 2) return;
      var m = midt(), r = boks.getBoundingClientRect();
      z.s = Math.max(1, Math.min(maks, start.s * m.d / start.d));
      z.x = m.x - r.left - start.px * z.s;
      z.y = m.y - r.top - start.py * z.s;
      bruk();
    }, true);

    function slipp(e) {
      var hadde = pek.delete(e.pointerId);
      if (pinch) {
        e.stopPropagation(); e.preventDefault();
        if (pek.size === 0) pinch = false;
      }
      return hadde;
    }
    boks.addEventListener('pointerup', slipp, true);
    boks.addEventListener('pointercancel', slipp, true);

    boks.addEventListener('wheel', function (e) {
      if (!(e.ctrlKey || e.metaKey)) return;
      e.preventDefault();
      zoomRundt(z.s * Math.exp(-e.deltaY * 0.01), e.clientX, e.clientY);
    }, { passive: false });

    function midtpunkt() { var r = boks.getBoundingClientRect(); return [r.left + r.width / 2, r.top + r.height / 2]; }
    var api = {
      inn: function () { var c = midtpunkt(); zoomRundt(z.s * 1.6, c[0], c[1]); },
      ut: function () { var c = midtpunkt(); zoomRundt(z.s / 1.6, c[0], c[1]); },
      tilpass: function () { z.s = 1; z.x = 0; z.y = 0; bruk(); },
      aktiv: function () { return pinch; },
      skala: function () { return z.s; },
      oppdater: bruk
    };
    window.addEventListener('resize', bruk);
    bruk();
    return api;
  }

  // Liten knapperad: − / + / Tilpass, med skala vist i midten.
  function zoomKnapper(api, mal) {
    var rad = document.createElement('div');
    rad.className = 'zoomrad';
    rad.innerHTML = '<button type="button" aria-label="Zoom ut">−</button>' +
      '<span class="zoomtall" aria-live="polite">100 %</span>' +
      '<button type="button" aria-label="Zoom inn">+</button>' +
      '<button type="button" class="zoomfit">Tilpass</button>' +
      '<span class="zoomhint">Knip med to fingre for å zoome</span>';
    var b = rad.querySelectorAll('button');
    b[0].onclick = api.ut; b[1].onclick = api.inn; b[2].onclick = api.tilpass;
    mal.appendChild(rad);
    return function (s) { rad.querySelector('.zoomtall').textContent = Math.round(s * 100) + ' %'; };
  }

  window.FixOneZoom = { lagZoom: lagZoom, zoomKnapper: zoomKnapper };
})();
