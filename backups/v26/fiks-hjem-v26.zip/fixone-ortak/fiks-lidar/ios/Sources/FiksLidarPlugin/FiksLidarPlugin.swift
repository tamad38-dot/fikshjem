// Fiks hjem – måling med LiDAR og romskanning, som Capacitor-plugin.
//
// Tre metoder (JS-siden er src/lib/lidar.ts):
//   status()   → { ar, lidar, rom }  hva telefonen kan
//   maal()     → { meter } eller { avbrutt: true }
//                Fullskjerm-kamera med sikte i midten. «Sett punkt» to ganger,
//                så «Bruk 2,43 m». Med LiDAR (iPhone 12 Pro og nyere Pro-modeller)
//                treffer siktet flater med en gang; uten LiDAR må telefonen
//                beveges litt først.
//   skannRom() → { vegger, dorer, vinduer, apninger, gulv? } eller { avbrutt: true }
//                Apples RoomPlan (iOS 16+, krever LiDAR). Gir rådata i meter;
//                appen gjør dem om til rom, vegger og åpninger (src/lib/romplan.js).
//
// Regelen fra tüzük gjelder: telefonen MÅLER, appen REGNER. Ingenting her
// gjetter mål – det som returneres er det sensoren faktisk målte.
//
// IKKE TESTET ENNÅ: skrevet uten Xcode. Første test er en bygging i Xcode
// og en kjøring på en iPhone med LiDAR.
import Foundation
import UIKit
import ARKit
import SceneKit
import simd
import Capacitor
#if canImport(RoomPlan)
import RoomPlan
#endif

@objc(FiksLidarPlugin)
public class FiksLidarPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "FiksLidarPlugin"
    public let jsName = "FiksLidar"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "status", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "maal", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "skannRom", returnType: CAPPluginReturnPromise)
    ]

    // MARK: - Hva kan telefonen?

    private func romStottes() -> Bool {
        #if canImport(RoomPlan)
        if #available(iOS 16.0, *) { return RoomCaptureSession.isSupported }
        #endif
        return false
    }

    @objc func status(_ call: CAPPluginCall) {
        call.resolve([
            "ar": ARWorldTrackingConfiguration.isSupported,
            "lidar": ARWorldTrackingConfiguration.supportsSceneReconstruction(.mesh),
            "rom": romStottes()
        ])
    }

    // MARK: - Mål en avstand

    @objc func maal(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            guard ARWorldTrackingConfiguration.isSupported else {
                call.reject("Denne telefonen kan ikke måle med kameraet.")
                return
            }
            guard let vert = self.bridge?.viewController, vert.presentedViewController == nil else {
                call.reject("Et annet vindu er allerede åpent.")
                return
            }
            let vc = MaalViewController()
            vc.ferdig = { meter in
                if let m = meter {
                    call.resolve(["meter": m])
                } else {
                    call.resolve(["avbrutt": true])
                }
            }
            vc.modalPresentationStyle = .fullScreen
            vert.present(vc, animated: true)
        }
    }

    // MARK: - Skann et rom

    @objc func skannRom(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            #if canImport(RoomPlan)
            if #available(iOS 16.0, *), RoomCaptureSession.isSupported {
                guard let vert = self.bridge?.viewController, vert.presentedViewController == nil else {
                    call.reject("Et annet vindu er allerede åpent.")
                    return
                }
                let vc = RomSkannViewController()
                vc.ferdig = { data in
                    if let d = data { call.resolve(d) } else { call.resolve(["avbrutt": true]) }
                }
                vc.modalPresentationStyle = .fullScreen
                vert.present(vc, animated: true)
                return
            }
            #endif
            call.reject("Romskanning krever iOS 16 og en iPhone med LiDAR.")
        }
    }
}

// MARK: - Felles knappestil

@MainActor
private func lagKnapp(_ tittel: String, hoved: Bool) -> UIButton {
    var c = UIButton.Configuration.filled()
    c.title = tittel
    c.cornerStyle = .capsule
    c.baseBackgroundColor = hoved ? UIColor(red: 0.97, green: 0.72, blue: 0.25, alpha: 1) : UIColor(white: 0, alpha: 0.55)
    c.baseForegroundColor = hoved ? UIColor(red: 0.06, green: 0.13, blue: 0.18, alpha: 1) : .white
    c.contentInsets = NSDirectionalEdgeInsets(top: 14, leading: 20, bottom: 14, trailing: 20)
    var a = AttributeContainer()
    a.font = UIFont.systemFont(ofSize: 17, weight: .bold)
    c.attributedTitle = AttributedString(tittel, attributes: a)
    let b = UIButton(configuration: c)
    b.translatesAutoresizingMaskIntoConstraints = false
    return b
}

@MainActor
private func settTittel(_ b: UIButton, _ tittel: String) {
    guard var c = b.configuration else { return }
    var a = AttributeContainer()
    a.font = UIFont.systemFont(ofSize: 17, weight: .bold)
    c.attributedTitle = AttributedString(tittel, attributes: a)
    b.configuration = c
}

/// 2,43 m – norsk desimalkomma.
private func norskMeter(_ m: Float) -> String {
    return String(format: "%.2f m", m).replacingOccurrences(of: ".", with: ",")
}

/// LiDAR rekker omtrent 5 m. Lenger enn det blir målet mindre sikkert.
private func rekkeviddeMerknad(_ m: Float) -> String {
    return m > 5 ? "\nOver 5 m: mindre nøyaktig. Mål gjerne i to deler." : ""
}

// MARK: - Måleskjermen (ARKit + LiDAR)

final class MaalViewController: UIViewController, ARSCNViewDelegate {
    var ferdig: ((Double?) -> Void)?

    private let scene = ARSCNView(frame: .zero)
    private let sikte = UIView()
    private let tekst = UILabel()
    private let tekstBakgrunn = UIVisualEffectView(effect: UIBlurEffect(style: .systemUltraThinMaterialDark))
    private lazy var settKnapp = lagKnapp("＋ Sett punkt", hoved: true)
    private lazy var angreKnapp = lagKnapp("Angre", hoved: false)
    private let lukkKnapp = UIButton(type: .system)
    private var punkter: [SCNVector3] = []
    private var punktNoder: [SCNNode] = []
    private var linjeNode: SCNNode?
    private var treffNa: SCNVector3?
    private var visning: CADisplayLink?
    private var sendt = false
    private let harLidar = ARWorldTrackingConfiguration.supportsSceneReconstruction(.mesh)

    override var prefersStatusBarHidden: Bool { true }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black

        scene.translatesAutoresizingMaskIntoConstraints = false
        scene.delegate = self
        scene.automaticallyUpdatesLighting = true
        view.addSubview(scene)

        // Siktet i midten av skjermen. Punktet settes der siktet treffer.
        sikte.translatesAutoresizingMaskIntoConstraints = false
        sikte.layer.cornerRadius = 14
        sikte.layer.borderWidth = 3
        sikte.layer.borderColor = UIColor.white.cgColor
        sikte.isUserInteractionEnabled = false
        let prikk = UIView()
        prikk.translatesAutoresizingMaskIntoConstraints = false
        prikk.backgroundColor = .white
        prikk.layer.cornerRadius = 3
        sikte.addSubview(prikk)
        view.addSubview(sikte)

        tekstBakgrunn.translatesAutoresizingMaskIntoConstraints = false
        tekstBakgrunn.layer.cornerRadius = 18
        tekstBakgrunn.clipsToBounds = true
        tekst.translatesAutoresizingMaskIntoConstraints = false
        tekst.textColor = .white
        tekst.numberOfLines = 0
        tekst.textAlignment = .center
        tekst.font = UIFont.systemFont(ofSize: 17, weight: .semibold)
        tekstBakgrunn.contentView.addSubview(tekst)
        view.addSubview(tekstBakgrunn)

        var lc = UIButton.Configuration.plain()
        lc.image = UIImage(systemName: "xmark.circle.fill")
        lc.preferredSymbolConfigurationForImage = UIImage.SymbolConfiguration(pointSize: 30)
        lc.baseForegroundColor = .white
        lukkKnapp.configuration = lc
        lukkKnapp.translatesAutoresizingMaskIntoConstraints = false
        lukkKnapp.accessibilityLabel = "Avbryt"
        view.addSubview(lukkKnapp)

        let rad = UIStackView(arrangedSubviews: [angreKnapp, settKnapp])
        rad.translatesAutoresizingMaskIntoConstraints = false
        rad.axis = .horizontal
        rad.spacing = 12
        rad.distribution = .fill
        view.addSubview(rad)

        let g = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            scene.topAnchor.constraint(equalTo: view.topAnchor),
            scene.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            scene.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scene.trailingAnchor.constraint(equalTo: view.trailingAnchor),

            sikte.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            sikte.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            sikte.widthAnchor.constraint(equalToConstant: 28),
            sikte.heightAnchor.constraint(equalToConstant: 28),
            prikk.centerXAnchor.constraint(equalTo: sikte.centerXAnchor),
            prikk.centerYAnchor.constraint(equalTo: sikte.centerYAnchor),
            prikk.widthAnchor.constraint(equalToConstant: 6),
            prikk.heightAnchor.constraint(equalToConstant: 6),

            lukkKnapp.topAnchor.constraint(equalTo: g.topAnchor, constant: 8),
            lukkKnapp.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 8),

            tekstBakgrunn.topAnchor.constraint(equalTo: g.topAnchor, constant: 12),
            tekstBakgrunn.leadingAnchor.constraint(equalTo: lukkKnapp.trailingAnchor, constant: 8),
            tekstBakgrunn.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -16),
            tekst.topAnchor.constraint(equalTo: tekstBakgrunn.contentView.topAnchor, constant: 12),
            tekst.bottomAnchor.constraint(equalTo: tekstBakgrunn.contentView.bottomAnchor, constant: -12),
            tekst.leadingAnchor.constraint(equalTo: tekstBakgrunn.contentView.leadingAnchor, constant: 14),
            tekst.trailingAnchor.constraint(equalTo: tekstBakgrunn.contentView.trailingAnchor, constant: -14),

            rad.bottomAnchor.constraint(equalTo: g.bottomAnchor, constant: -20),
            rad.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            rad.leadingAnchor.constraint(greaterThanOrEqualTo: g.leadingAnchor, constant: 16),
        ])

        lukkKnapp.addTarget(self, action: #selector(avbryt), for: .touchUpInside)
        settKnapp.addTarget(self, action: #selector(hovedknapp), for: .touchUpInside)
        angreKnapp.addTarget(self, action: #selector(angre), for: .touchUpInside)
        oppdaterTekst()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let cfg = ARWorldTrackingConfiguration()
        cfg.planeDetection = [.horizontal, .vertical]
        // LiDAR: dybdekart og 3D-nett gjør at siktet treffer vegg, gulv og karm presist.
        if ARWorldTrackingConfiguration.supportsSceneReconstruction(.mesh) {
            cfg.sceneReconstruction = .mesh
        }
        if ARWorldTrackingConfiguration.supportsFrameSemantics(.sceneDepth) {
            cfg.frameSemantics.insert(.sceneDepth)
        }
        scene.session.run(cfg, options: [.resetTracking, .removeExistingAnchors])
        let d = CADisplayLink(target: self, selector: #selector(tikk))
        d.add(to: .main, forMode: .common)
        visning = d
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        visning?.invalidate()
        visning = nil
        scene.session.pause()
    }

    // MARK: Siktet

    private func treffIMidten() -> SCNVector3? {
        let midt = CGPoint(x: scene.bounds.midX, y: scene.bounds.midY)
        guard let q = scene.raycastQuery(from: midt, allowing: .estimatedPlane, alignment: .any),
              let r = scene.session.raycast(q).first else { return nil }
        let t = r.worldTransform.columns.3
        return SCNVector3Make(t.x, t.y, t.z)
    }

    @objc private func tikk() {
        guard punkter.count < 2 else { return }
        treffNa = treffIMidten()
        let truffet = treffNa != nil
        sikte.layer.borderColor = (truffet ? UIColor.systemYellow : UIColor(white: 1, alpha: 0.5)).cgColor
        settKnapp.isEnabled = truffet
        if punkter.count == 1, let a = punkter.first, let b = treffNa {
            tegnLinje(fra: a, til: b)
            let d = avstand(a, b)
            tekst.text = norskMeter(d) + "\nPek på det andre punktet og trykk «Sett punkt»." + rekkeviddeMerknad(d)
        }
    }

    private func avstand(_ a: SCNVector3, _ b: SCNVector3) -> Float {
        let dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z
        return sqrtf(dx * dx + dy * dy + dz * dz)
    }

    private func oppdaterTekst() {
        switch punkter.count {
        case 0:
            tekst.text = harLidar
                ? "Sett siktet på det første punktet og trykk «Sett punkt»."
                : "Beveg telefonen litt så den finner flatene. Sett så siktet på det første punktet."
        case 1:
            tekst.text = "Pek på det andre punktet og trykk «Sett punkt»."
        default:
            if punkter.count == 2 {
                let d = avstand(punkter[0], punkter[1])
                tekst.text = "Målt: " + norskMeter(d) + rekkeviddeMerknad(d)
            }
        }
        angreKnapp.isHidden = punkter.isEmpty
        if punkter.count == 2 {
            settTittel(settKnapp, "Bruk " + norskMeter(avstand(punkter[0], punkter[1])))
            settKnapp.isEnabled = true
        } else {
            settTittel(settKnapp, "＋ Sett punkt")
        }
    }

    // MARK: 3D-markører

    private func lagPunktNode(_ p: SCNVector3) -> SCNNode {
        let kule = SCNSphere(radius: 0.006)
        kule.firstMaterial?.diffuse.contents = UIColor.systemYellow
        kule.firstMaterial?.lightingModel = .constant
        let n = SCNNode(geometry: kule)
        n.position = p
        return n
    }

    private func tegnLinje(fra a: SCNVector3, til b: SCNVector3) {
        linjeNode?.removeFromParentNode()
        let l = avstand(a, b)
        guard l > 0.001 else { return }
        let ror = SCNCylinder(radius: 0.0025, height: CGFloat(l))
        ror.firstMaterial?.diffuse.contents = UIColor.systemYellow
        ror.firstMaterial?.lightingModel = .constant
        let n = SCNNode(geometry: ror)
        n.position = SCNVector3Make((a.x + b.x) / 2, (a.y + b.y) / 2, (a.z + b.z) / 2)
        // Sylinderen står langs sin egen y-akse; snu den mot punkt b.
        let loddrett = abs((b.y - a.y) / l) > 0.98
        n.look(at: b, up: loddrett ? SCNVector3Make(1, 0, 0) : SCNVector3Make(0, 1, 0), localFront: SCNVector3Make(0, 1, 0))
        scene.scene.rootNode.addChildNode(n)
        linjeNode = n
    }

    // MARK: Knapper

    @objc private func hovedknapp() {
        if punkter.count == 2 {
            avslutt(Double(avstand(punkter[0], punkter[1])))
            return
        }
        guard let p = treffNa ?? treffIMidten() else { return }
        punkter.append(p)
        let n = lagPunktNode(p)
        scene.scene.rootNode.addChildNode(n)
        punktNoder.append(n)
        if punkter.count == 2 { tegnLinje(fra: punkter[0], til: punkter[1]) }
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        oppdaterTekst()
    }

    @objc private func angre() {
        guard !punkter.isEmpty else { return }
        punkter.removeLast()
        punktNoder.popLast()?.removeFromParentNode()
        linjeNode?.removeFromParentNode()
        linjeNode = nil
        oppdaterTekst()
    }

    @objc private func avbryt() { avslutt(nil) }

    private func avslutt(_ meter: Double?) {
        guard !sendt else { return }
        sendt = true
        let svar = ferdig
        dismiss(animated: true) { svar?(meter) }
    }

    // MARK: ARSessionObserver

    func session(_ session: ARSession, didFailWithError error: Error) {
        DispatchQueue.main.async {
            if let e = error as? ARError, e.code == .cameraUnauthorized {
                self.tekst.text = "Fiks hjem har ikke lov til å bruke kameraet. Slå det på i Innstillinger → Fiks hjem → Kamera."
            } else {
                self.tekst.text = "Kameraet stoppet: \(error.localizedDescription)"
            }
        }
    }
}

// MARK: - Romskanning (RoomPlan)

#if canImport(RoomPlan)
@available(iOS 16.0, *)
final class RomSkannViewController: UIViewController, RoomCaptureViewDelegate {
    var ferdig: ((JSObject?) -> Void)?

    private var romView: RoomCaptureView?
    private var resultat: CapturedRoom?
    private lazy var hovedKnapp = lagKnapp("Ferdig med rommet", hoved: true)
    private let lukkKnapp = UIButton(type: .system)
    private let tekst = UILabel()
    private var sendt = false

    override var prefersStatusBarHidden: Bool { true }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        let rv = RoomCaptureView(frame: view.bounds)
        rv.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        rv.delegate = self
        view.addSubview(rv)
        romView = rv

        var lc = UIButton.Configuration.plain()
        lc.image = UIImage(systemName: "xmark.circle.fill")
        lc.preferredSymbolConfigurationForImage = UIImage.SymbolConfiguration(pointSize: 30)
        lc.baseForegroundColor = .white
        lukkKnapp.configuration = lc
        lukkKnapp.translatesAutoresizingMaskIntoConstraints = false
        lukkKnapp.accessibilityLabel = "Avbryt"
        view.addSubview(lukkKnapp)

        tekst.translatesAutoresizingMaskIntoConstraints = false
        tekst.textColor = .white
        tekst.numberOfLines = 0
        tekst.textAlignment = .center
        tekst.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
        tekst.text = "Gå rolig rundt i rommet og pek på alle veggene, dørene og vinduene."
        view.addSubview(tekst)
        view.addSubview(hovedKnapp)

        let g = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            lukkKnapp.topAnchor.constraint(equalTo: g.topAnchor, constant: 8),
            lukkKnapp.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 8),
            tekst.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 24),
            tekst.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -24),
            tekst.bottomAnchor.constraint(equalTo: hovedKnapp.topAnchor, constant: -12),
            hovedKnapp.bottomAnchor.constraint(equalTo: g.bottomAnchor, constant: -20),
            hovedKnapp.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        ])
        lukkKnapp.addTarget(self, action: #selector(avbryt), for: .touchUpInside)
        hovedKnapp.addTarget(self, action: #selector(hovedknapp), for: .touchUpInside)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        romView?.captureSession.run(configuration: RoomCaptureSession.Configuration())
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        romView?.captureSession.stop()
    }

    @objc private func hovedknapp() {
        if let r = resultat {
            avslutt(Self.tilJS(r))
            return
        }
        // Stopp skanningen; RoomPlan lager modellen og kaller captureView(didPresent:).
        hovedKnapp.isEnabled = false
        settTittel(hovedKnapp, "Lager plantegning …")
        tekst.text = ""
        romView?.captureSession.stop()
    }

    @objc private func avbryt() { avslutt(nil) }

    private func avslutt(_ data: JSObject?) {
        guard !sendt else { return }
        sendt = true
        let svar = ferdig
        dismiss(animated: true) { svar?(data) }
    }

    // MARK: RoomCaptureViewDelegate

    func captureView(shouldPresent roomDataForProcessing: CapturedRoomData, error: Error?) -> Bool {
        return true
    }

    func captureView(didPresent processedResult: CapturedRoom, error: Error?) {
        if let error {
            tekst.text = "Skanningen feilet: \(error.localizedDescription)"
            settTittel(hovedKnapp, "Lukk")
            hovedKnapp.isEnabled = true
            hovedKnapp.removeTarget(self, action: #selector(hovedknapp), for: .touchUpInside)
            hovedKnapp.addTarget(self, action: #selector(avbryt), for: .touchUpInside)
            return
        }
        resultat = processedResult
        let n = processedResult.walls.count
        tekst.text = "\(n) vegger, \(processedResult.doors.count) dører og \(processedResult.windows.count) vinduer funnet."
        settTittel(hovedKnapp, "Bruk skannet")
        hovedKnapp.isEnabled = true
    }

    // MARK: Rådata til JS (meter, verdenskoordinater, y er opp)

    static func flate(_ s: CapturedRoom.Surface) -> JSObject {
        let t = s.transform
        let c = t.columns.3
        let x = t.columns.0   // flatens egen x-akse (langs veggen) i verden
        return [
            "cx": Double(c.x), "cy": Double(c.y), "cz": Double(c.z),
            "dx": Double(x.x), "dz": Double(x.z),
            "bredde": Double(s.dimensions.x), "hoyde": Double(s.dimensions.y)
        ]
    }

    static func tilJS(_ r: CapturedRoom) -> JSObject {
        var ut: JSObject = [
            "vegger": r.walls.map { flate($0) },
            "dorer": r.doors.map { flate($0) },
            "vinduer": r.windows.map { flate($0) },
            "apninger": r.openings.map { flate($0) }
        ]
        if #available(iOS 17.0, *), let gulv = r.floors.first {
            let t = gulv.transform
            let hjorner: [JSObject] = gulv.polygonCorners.map { p in
                let w = t * SIMD4<Float>(p.x, p.y, p.z, 1)
                return ["x": Double(w.x), "z": Double(w.z)]
            }
            ut["gulv"] = hjorner
        }
        return ut
    }
}
#endif
