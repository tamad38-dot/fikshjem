# fiks-lidar – LiDAR i Fiks hjem

To ting, begge bare på iPhone:

| Hva | Krever | Hvor i appen |
|---|---|---|
| **📏 Mål** – sikte i midten, «Sett punkt» to ganger, «Bruk 2,43 m» | ARKit (alle nyere iPhoner). Best med LiDAR (Pro-modeller fra iPhone 12 Pro) | Ved siden av lengdefeltene i Terrasse, Gulv, Vegg, Tak, Trapp, Fasade, Vindusåpning, Pergola og Teknisk tegning |
| **📡 Skann rommet** – Apples RoomPlan | iOS 16+ og LiDAR | Teknisk tegning, trinn 1 (Byggemoduler → «Skann rommet med LiDAR») |

Telefonen måler, appen regner (tüzük). Skanningen gir vegger, dører, vinduer og takhøyde i meter;
`src/lib/romplan.js` gjør dem om til rom og åpninger. Enhetstest: `node tester/romplan-test.mjs`.

## Første test på iPhone 16 Pro
1. `npm install` → første gang `npm run build && npx cap add ios` → så `npm run ios` (bygger, synker, legger inn kameratekst, åpner Xcode).
2. I Xcode: velg telefonen, trykk ▶.
3. Byggemoduler → Terrasse: trykk **📏 Mål** ved Bredde. Pek siktet på et hjørne, «Sett punkt», pek på neste, «Sett punkt», «Bruk».
4. Byggemoduler → **Skann rommet med LiDAR** → **📡 Skann rommet**. Gå rundt, trykk «Ferdig med rommet», så «Bruk skannet», gi rommet et navn.
5. Kontroller ett mål med tommestokk/laser. Skriv ned avviket.

## Hvis Xcode gir feil
- `cannot find type 'CAPBridgedPlugin'` → Capacitor er eldre enn 6. Fjern `CAPBridgedPlugin` og de tre linjene under (identifier, jsName, pluginMethods) og legg til en `.m`-registrering.
- Krasj ved start på en telefon med iOS 15 → sett «Minimum Deployments» til iOS 16 i Xcode (RoomPlan finnes ikke på iOS 15).
- Knappene vises ikke → sjekk i Xcode-loggen at `FiksLidar` er registrert, og at telefonen ikke er en simulator (ARKit virker ikke i simulatoren).

IKKE TESTET ENNÅ: Swift-koden er skrevet uten Xcode.
