Pod::Spec.new do |s|
  s.name = 'FiksLidar'
  s.version = '0.1.0'
  s.summary = 'Fiks hjem: LiDAR-måling (ARKit) og romskanning (RoomPlan) som Capacitor-plugin'
  s.license = { :type => 'Proprietary' }
  s.homepage = 'https://github.com/tamad38-dot/fikshjem'
  s.author = 'Tamer Adiyaman'
  s.source = { :git => 'https://github.com/tamad38-dot/fikshjem.git', :tag => s.version.to_s }
  s.source_files = 'ios/Sources/**/*.swift'
  s.ios.deployment_target = '15.0'
  s.frameworks = 'ARKit', 'SceneKit'
  s.weak_frameworks = 'RoomPlan'
  s.dependency 'Capacitor'
  s.swift_version = '5.9'
end
