// JS-siden ligger i appen (src/lib/lidar.ts). Denne pakken finnes for at
// `npx cap sync` skal ta med Swift-koden under ios/.
module.exports = {};
