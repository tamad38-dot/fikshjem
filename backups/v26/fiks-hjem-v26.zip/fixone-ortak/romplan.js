/* Fra LiDAR-skann (Apples RoomPlan) til et rom i Fiks hjem.

   Telefonen gir rådata i meter, i sitt eget 3D-rom (y er opp):
     vegger/dorer/vinduer/apninger: [{ cx, cy, cz, dx, dz, bredde, hoyde }]
       cx/cy/cz = midtpunktet, dx/dz = retningen langs flaten, bredde/hoyde = målene
     gulv (iOS 17+): [{ x, z }] – gulvets hjørner, hvis telefonen fant dem

   Her blir det til det appen bruker i «Teknisk tegning»:
     punkter:  [{ x, y }]  rommets hjørner sett ovenfra (plan-y = telefonens z)
     apninger: [{ type: 'Dor'|'Vindu', b, h, sh, veggIndeks, pos }]
     takhoyde: meter

   Tüzük: ingenting gjettes. Hjørnene er der veggene faktisk møtes (linjene
   skjæres), og hver åpning legges på veggen den faktisk står på. Det eneste
   appen gjør, er å snu planen så den lengste veggen ligger rett (vannrett),
   og flytte den så den starter i 0,0 – det endrer ingen mål. */

const avst = (a, b) => Math.hypot(b.x - a.x, b.y - a.y);
const r2 = (v) => Math.round(v * 100) / 100;

/** Veggens to endepunkter i planet. */
function endepunkter(v) {
  const L = Math.hypot(v.dx, v.dz) || 1;
  const ux = v.dx / L, uy = v.dz / L, h = (v.bredde || 0) / 2;
  return { a: { x: v.cx - ux * h, y: v.cz - uy * h }, b: { x: v.cx + ux * h, y: v.cz + uy * h }, u: { x: ux, y: uy } };
}

/** Der linjene gjennom to vegger krysser hverandre (null hvis de er parallelle). */
function kryss(p, u, q, w) {
  const det = u.x * w.y - u.y * w.x;
  if (Math.abs(det) < 0.15) return null; // nesten parallelle (< ca. 9°)
  const t = ((q.x - p.x) * w.y - (q.y - p.y) * w.x) / det;
  return { x: p.x + u.x * t, y: p.y + u.y * t };
}

/** Setter veggene etter hverandre rundt rommet og finner hjørnene. */
export function kjedeVegger(vegger) {
  const seg = vegger.map(endepunkter);
  if (seg.length < 3) return [];
  const brukt = new Set([0]);
  const rekke = [seg[0]];
  let slutt = seg[0].b;
  while (rekke.length < seg.length) {
    let best = -1, snu = false, bestD = Infinity;
    seg.forEach((s, i) => {
      if (brukt.has(i)) return;
      const da = avst(slutt, s.a), db = avst(slutt, s.b);
      if (da < bestD) { bestD = da; best = i; snu = false; }
      if (db < bestD) { bestD = db; best = i; snu = true; }
    });
    if (best < 0) break;
    brukt.add(best);
    const s = seg[best];
    const neste = snu ? { a: s.b, b: s.a, u: { x: -s.u.x, y: -s.u.y } } : s;
    rekke.push(neste);
    slutt = neste.b;
  }
  const hjorner = [];
  for (let i = 0; i < rekke.length; i++) {
    const s = rekke[i], n = rekke[(i + 1) % rekke.length];
    const k = kryss(s.a, s.u, n.a, n.u);
    hjorner.push(k || { x: (s.b.x + n.a.x) / 2, y: (s.b.y + n.a.y) / 2 });
  }
  // Hjørne i blir mellom vegg i og i+1; roter så første punkt er starten på vegg 0.
  return [hjorner[hjorner.length - 1], ...hjorner.slice(0, -1)];
}

/** Fjerner punkter som nesten ligger oppå hverandre eller på rett linje. */
export function forenkle(punkter, minAvstand = 0.05, minVinkelGrader = 4) {
  let p = punkter.slice();
  let endret = true;
  while (endret && p.length > 3) {
    endret = false;
    for (let i = 0; i < p.length && p.length > 3; i++) {
      const a = p[(i - 1 + p.length) % p.length], b = p[i], c = p[(i + 1) % p.length];
      if (avst(a, b) < minAvstand) { p.splice(i, 1); endret = true; break; }
      const v1 = Math.atan2(b.y - a.y, b.x - a.x), v2 = Math.atan2(c.y - b.y, c.x - b.x);
      let d = Math.abs(v2 - v1) * 180 / Math.PI;
      if (d > 180) d = 360 - d;
      if (d < minVinkelGrader) { p.splice(i, 1); endret = true; break; }
    }
  }
  return p;
}

function signertAreal(p) {
  let s = 0;
  for (let i = 0; i < p.length; i++) { const a = p[i], b = p[(i + 1) % p.length]; s += a.x * b.y - b.x * a.y; }
  return s / 2;
}

const median = (xs) => {
  const s = xs.filter((x) => x > 0).sort((a, b) => a - b);
  if (!s.length) return 0;
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
};

/** Gjør rådata fra telefonen om til ett rom med åpninger. Kaster feil med norsk tekst. */
export function romFraSkann(raa) {
  if (!raa || typeof raa !== 'object') throw new Error('Skanningen ga ingen data.');
  const vegger = (raa.vegger || []).filter((v) => v && v.bredde > 0.2 && Number.isFinite(v.cx) && Number.isFinite(v.cz));
  const gulv = Array.isArray(raa.gulv) ? raa.gulv.filter((p) => Number.isFinite(p.x) && Number.isFinite(p.z)) : [];
  const advarsler = [];

  let plan;
  if (gulv.length >= 3) {
    plan = gulv.map((p) => ({ x: p.x, y: p.z }));
  } else if (vegger.length >= 3) {
    plan = kjedeVegger(vegger);
  } else {
    throw new Error('Fant for få vegger. Gå rundt i hele rommet og pek på alle veggene, og prøv igjen.');
  }
  plan = forenkle(plan);
  if (plan.length < 3) throw new Error('Klarte ikke å lage en plantegning av skanningen. Prøv igjen.');

  // Samme vei rundt som resten av appen (positivt areal med y nedover).
  if (signertAreal(plan) < 0) plan.reverse();

  // Snu planen så den lengste veggen ligger vannrett. Endrer ingen mål.
  let lengst = 0, vinkel = 0;
  for (let i = 0; i < plan.length; i++) {
    const a = plan[i], b = plan[(i + 1) % plan.length], l = avst(a, b);
    if (l > lengst) { lengst = l; vinkel = Math.atan2(b.y - a.y, b.x - a.x); }
  }
  const snapp = Math.round(vinkel / (Math.PI / 2)) * (Math.PI / 2);
  const rot = snapp - vinkel;
  const cos = Math.cos(rot), sin = Math.sin(rot);
  const drei = (p) => ({ x: p.x * cos - p.y * sin, y: p.x * sin + p.y * cos });
  let punkter = plan.map(drei);
  const minX = Math.min(...punkter.map((p) => p.x)), minY = Math.min(...punkter.map((p) => p.y));
  const flytt = (p) => ({ x: p.x - minX, y: p.y - minY });
  punkter = punkter.map((p) => { const q = flytt(p); return { x: r2(q.x), y: r2(q.y) }; });

  // Gulvhøyden: underkanten av veggene.
  const bunner = vegger.map((v) => v.cy - v.hoyde / 2).filter(Number.isFinite);
  const gulvY = bunner.length ? median(bunner.map((b) => b + 100)) - 100 : 0;
  const takhoyde = r2(median(vegger.map((v) => v.hoyde)) || 0);
  if (!takhoyde) advarsler.push('Fant ikke takhøyden – skriv den inn selv.');

  // Åpninger: legg hver dør/vindu på veggen den står nærmest.
  const apninger = [];
  const legg = (liste, type) => (liste || []).forEach((o) => {
    if (!o || !(o.bredde > 0.1) || !Number.isFinite(o.cx)) return;
    const s = flytt(drei({ x: o.cx, y: o.cz }));
    let best = -1, bestD = Infinity, bestT = 0, bestL = 0;
    for (let i = 0; i < punkter.length; i++) {
      const a = punkter[i], b = punkter[(i + 1) % punkter.length];
      const L = avst(a, b);
      if (L < 0.05) continue;
      const ux = (b.x - a.x) / L, uy = (b.y - a.y) / L;
      const t = Math.max(0, Math.min(L, (s.x - a.x) * ux + (s.y - a.y) * uy));
      const d = Math.hypot(s.x - (a.x + ux * t), s.y - (a.y + uy * t));
      if (d < bestD) { bestD = d; best = i; bestT = t; bestL = L; }
    }
    if (best < 0) return;
    if (bestD > 0.6) advarsler.push((type === 'Dor' ? 'En dør' : 'Et vindu') + ' sto ' + r2(bestD).toString().replace('.', ',') + ' m fra nærmeste vegg – sjekk plasseringen.');
    const b = r2(Math.min(o.bredde, bestL));
    const h = r2(o.hoyde || (type === 'Dor' ? 2.1 : 1.2));
    const sh = type === 'Dor' ? 0 : r2(Math.max(0, (o.cy - (o.hoyde || 0) / 2) - gulvY));
    apninger.push({ type, b, h, sh, veggIndeks: best, pos: r2(Math.max(0, Math.min(bestL - b, bestT - b / 2))) });
  });
  legg(raa.dorer, 'Dor');
  legg(raa.vinduer, 'Vindu');
  legg(raa.apninger, 'Dor');

  return {
    punkter, apninger, takhoyde, advarsler,
    antall: { vegger: vegger.length, dorer: (raa.dorer || []).length, vinduer: (raa.vinduer || []).length, apninger: (raa.apninger || []).length },
  };
}
