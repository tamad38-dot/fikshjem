/* FixOne – felles: norske tall i skjema og visning.
   Brukt i Fiks hjem v25 (TamerFixApp.jsx: tall, tilVisning, norskVisning, Felt, TallInput).
   Kopier fila inn i appen som trenger den – appene skal ikke være avhengige av hverandre.

   Problemet den løser:
   - Norsk tastatur gir komma («2,4»). Et <input type="number"> kan da gi tom verdi eller 2.
   - Skjermen skal vise «2,4 m» og «12 m²», mens utregningen bruker 2.4.            */

/** Leser «2,4», «2.4», « 2 » og tomt felt. Gir 0 når det ikke er et tall. */
export const tall = (v) => (parseFloat(String(v).replace(',', '.')) || 0);

/** Verdi fra regnestykket → tekst i feltet (2.4 → «2,4»). */
export const tilVisning = (v) => (v === null || v === undefined ? '' : String(v).replace('.', ','));

/** Ferdig tekst på skjermen: desimalkomma (maks to desimaler, så «526.413» røres ikke), m² og m³. */
export function norskVisning(v) {
  if (typeof v === 'number') return Number.isFinite(v) ? String(v).replace('.', ',') : '–';
  if (typeof v !== 'string') return v;
  return v.replace(/(\d)\.(\d{1,2})(?!\d)/g, '$1,$2').replace(/\bm2\b/g, 'm²').replace(/\bm3\b/g, 'm³');
}

/** Rens det brukeren skriver i et tallfelt, og gi tallet videre med punktum. */
export const rensTallfelt = (raa) => {
  const vis = String(raa).replace(/[^0-9,.\-\s]/g, '');
  return { vis, verdi: vis.replace(/\s/g, '').replace(',', '.') };
};

/* React-bruk (se Felt i TamerFixApp.jsx):
   <input type="text" inputMode="decimal" value={vis}
          onChange={(e) => { const r = rensTallfelt(e.target.value); setVis(r.vis); onChange(r.verdi); }} />
   og synk fra prop bare når tall(vis) !== tall(value), ellers forsvinner kommaet mens man skriver. */
