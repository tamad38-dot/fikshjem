# FixOne – felles deler

Kopier, ikke lenk: hver app har sin egen kopi og virker alene.

| Fil | Hva | Kom fra |
|---|---|---|
| `norsk-tall.js` | Norsk desimalkomma i felt og visning, m²/m³ | Fiks hjem v25 |
| `ios-tillatelser.mjs` | Kamera-/bilde-/posisjonstekster og lys statuslinje i iOS Info.plist etter `cap sync` | Fiks hjem v25 |
| `zoom.js` | To-finger zoom/panorering for bildeverktøy (rød prikk, fasade fra foto) | Fiks hjem v24 |
| `romplan.js` | LiDAR/RoomPlan-skann → rom (hjørner, dører, vinduer, takhøyde) | Fiks hjem v26 |
| `fiks-lidar/` | Swift: LiDAR-måler (ARKit) og romskanning (RoomPlan) for Capacitor | Fiks hjem v26 |
