// Legger inn iOS-tillatelsestekstene i ios/App/App/Info.plist.
//
// Hvorfor: appen bruker kameraet (foto av vegg, vindu, fasade og varer) og
// posisjon (adresse og vær). Uten disse tekstene i Info.plist stopper iOS appen
// første gang kameraet åpnes, og App Store avviser bygget.
// ios/-mappa lages av `npx cap add ios` og ligger ikke i prosjektet, derfor
// legges tekstene inn her etter hver `cap sync`. Kan kjøres så ofte du vil:
// nøkler som allerede finnes, røres ikke.
import fs from 'node:fs';
import path from 'node:path';

const plist = path.resolve('ios/App/App/Info.plist');
if (!fs.existsSync(plist)) {
  console.log('[ios-tillatelser] Fant ikke ' + plist + ' – kjør `npx cap add ios` først. Hopper over.');
  process.exit(0);
}

const TEKSTER = {
  NSCameraUsageDescription:
    'Fiks hjem bruker kameraet når du tar bilde av en vegg, et vindu, en fasade eller en vare, og når du måler eller skanner et rom med LiDAR.',
  NSPhotoLibraryUsageDescription:
    'Fiks hjem åpner bildene dine bare når du selv velger et bilde å måle på eller legge i prosjektet.',
  NSLocationWhenInUseUsageDescription:
    'Fiks hjem bruker posisjonen bare når du ber om det, for å finne adressen din og været der du bor.',
};

let xml = fs.readFileSync(plist, 'utf8');
const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const lagt = [];
for (const [nokkel, tekst] of Object.entries(TEKSTER)) {
  if (xml.includes('<key>' + nokkel + '</key>')) continue;
  const slutt = xml.lastIndexOf('</dict>');
  if (slutt < 0) { console.error('[ios-tillatelser] Info.plist har ikke forventet form.'); process.exit(1); }
  xml = xml.slice(0, slutt) + '\t<key>' + nokkel + '</key>\n\t<string>' + esc(tekst) + '</string>\n' + xml.slice(slutt);
  lagt.push(nokkel);
}
// Lys statuslinje (hvit klokke og batteri). Appen er mørkeblå; med iOS sin
// standard i lys modus ble klokka svart på mørk bakgrunn og nesten usynlig.
if (!xml.includes('<key>UIStatusBarStyle</key>')) {
  const slutt = xml.lastIndexOf('</dict>');
  xml = xml.slice(0, slutt) + '\t<key>UIStatusBarStyle</key>\n\t<string>UIStatusBarStyleLightContent</string>\n' + xml.slice(slutt);
  lagt.push('UIStatusBarStyle');
}
const vcNokkel = /<key>UIViewControllerBasedStatusBarAppearance<\/key>\s*<(true|false)\/>/;
if (vcNokkel.test(xml)) {
  if (/<key>UIViewControllerBasedStatusBarAppearance<\/key>\s*<true\/>/.test(xml)) {
    xml = xml.replace(vcNokkel, '<key>UIViewControllerBasedStatusBarAppearance</key>\n\t<false/>');
    lagt.push('UIViewControllerBasedStatusBarAppearance=false');
  }
} else {
  const slutt = xml.lastIndexOf('</dict>');
  xml = xml.slice(0, slutt) + '\t<key>UIViewControllerBasedStatusBarAppearance</key>\n\t<false/>\n' + xml.slice(slutt);
  lagt.push('UIViewControllerBasedStatusBarAppearance=false');
}

if (lagt.length) {
  fs.writeFileSync(plist, xml);
  console.log('[ios-tillatelser] La inn: ' + lagt.join(', '));
} else {
  console.log('[ios-tillatelser] Alt var på plass.');
}
