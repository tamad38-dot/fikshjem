// Fiks hjem – telefonens egen AI og bildelesing, uten nøkkel og uten nett.
//
// Tre lag, det beste som finnes på telefonen brukes:
//   1. Vision (alle iPhoner med iOS 15+): leser strekkoder, QR og tekst på
//      etiketter. Ingen Apple Intelligence nødvendig.
//   2. Foundation Models tekstmodell (iOS 26+, Apple Intelligence): får det
//      Vision leste, og lager produktsvaret i appens JSON-format.
//   3. Foundation Models med bilde (iOS 27+, Apple Intelligence): ser selve
//      bildet. Slått av til den er bygget og testet i Xcode 27 – sett
//      Swift-flagget FIKS_IOS27_BILDE for å slå den på (se LES-MEG).
//
// IKKE TESTET ENNÅ: skrevet uten Xcode. Første test er en bygging i Xcode
// på Mac og en kjøring på en ekte iPhone.
import Foundation
import UIKit
import Vision
import Capacitor
#if canImport(FoundationModels)
import FoundationModels
#endif

@objc(FiksLokalAIPlugin)
public class FiksLokalAIPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "FiksLokalAIPlugin"
    public let jsName = "FiksLokalAI"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "tilgjengelig", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "svar", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "lesBilde", returnType: CAPPluginReturnPromise)
    ]

    // MARK: - Finnes AI-en?

    private func modellKlar() -> (Bool, String) {
        #if canImport(FoundationModels)
        if #available(iOS 26.0, *) {
            switch SystemLanguageModel.default.availability {
            case .available: return (true, "")
            case .unavailable(let grunn): return (false, String(describing: grunn))
            @unknown default: return (false, "ukjent")
            }
        }
        #endif
        return (false, "krever iOS 26 og Apple Intelligence")
    }

    private func bildeModellKlar() -> Bool {
        #if FIKS_IOS27_BILDE && canImport(FoundationModels)
        if #available(iOS 27.0, *) { return modellKlar().0 }
        #endif
        return false
    }

    @objc func tilgjengelig(_ call: CAPPluginCall) {
        let (ok, grunn) = modellKlar()
        // `vision` er alltid sann på iOS 15+: strekkode og tekst virker på alle.
        call.resolve(["ok": ok, "grunn": grunn, "vision": true, "bilde": bildeModellKlar()])
    }

    // MARK: - Tekst inn, tekst ut

    @objc func svar(_ call: CAPPluginCall) {
        let prompt = call.getString("prompt") ?? ""
        let system = call.getString("system") ?? ""
        guard !prompt.isEmpty else { call.reject("Tom forespørsel"); return }
        Task {
            do { call.resolve(["tekst": try await self.spor(prompt, system)]) }
            catch { call.reject("Telefonens AI svarte ikke: \(error.localizedDescription)") }
        }
    }

    private func spor(_ prompt: String, _ system: String) async throws -> String {
        #if canImport(FoundationModels)
        if #available(iOS 26.0, *) {
            let okt = LanguageModelSession(instructions: system)
            return try await okt.respond(to: prompt).content
        }
        #endif
        throw NSError(domain: "FiksLokalAI", code: 1,
                      userInfo: [NSLocalizedDescriptionKey: "Telefonens AI finnes ikke på denne telefonen"])
    }

    // MARK: - Bilde inn: strekkoder, tekst og (hvis mulig) et produktsvar

    /// JS: lesBilde({ bilde: base64-jpeg, prompt: skanneprompten })
    /// Svar: { koder: [{type, verdi}], tekst: "lest tekst", svar: "JSON fra AI eller tom", kilde }
    @objc func lesBilde(_ call: CAPPluginCall) {
        guard let b64 = call.getString("bilde"),
              let data = Data(base64Encoded: b64, options: .ignoreUnknownCharacters),
              let bilde = UIImage(data: data), let cg = bilde.cgImage else {
            call.reject("Klarte ikke å lese bildet"); return
        }
        let prompt = call.getString("prompt") ?? ""

        Task {
            let (koder, tekst) = self.vision(cg)
            var svar = ""
            var kilde = "vision"

            #if FIKS_IOS27_BILDE && canImport(FoundationModels)
            if #available(iOS 27.0, *), self.modellKlar().0, !prompt.isEmpty {
                // iOS 27: modellen ser bildet selv. API-navnene er fra WWDC26
                // (økt 237) – sjekk dem mot Xcode 27 før flagget slås på.
                if let s = try? await LanguageModelSession().respond(to: Prompt {
                    prompt
                    Attachment(bilde)
                }).content {
                    svar = s; kilde = "bilde"
                }
            }
            #endif

            if svar.isEmpty, self.modellKlar().0, !prompt.isEmpty, !(koder.isEmpty && tekst.isEmpty) {
                // iOS 26: tekstmodellen får det Vision leste, ikke bildet.
                let lest = "Telefonen leste dette fra bildet (du ser ikke selve bildet):\n"
                    + (koder.isEmpty ? "" : "Strekkoder: " + koder.map { ($0["verdi"] as? String) ?? "" }.joined(separator: ", ") + "\n")
                    + (tekst.isEmpty ? "" : "Tekst på etiketten:\n" + String(tekst.prefix(1500)))
                if let s = try? await self.spor(prompt + "\n\n" + lest,
                        "Du identifiserer byggevarer ut fra tekst på etiketten. Gjett aldri mål.") {
                    svar = s; kilde = "tekstmodell"
                }
            }

            call.resolve(["koder": koder, "tekst": tekst, "svar": svar, "kilde": kilde])
        }
    }

    /// Vision: strekkoder og tekst. Virker uten Apple Intelligence.
    private func vision(_ cg: CGImage) -> ([JSObject], String) {
        // JSObject (Capacitors egen type), så lista kan sendes rett tilbake til JS.
        var koder: [JSObject] = []
        var linjer: [String] = []

        let strek = VNDetectBarcodesRequest { req, _ in
            for o in (req.results as? [VNBarcodeObservation]) ?? [] {
                if let v = o.payloadStringValue, !koder.contains(where: { ($0["verdi"] as? String) == v }) {
                    koder.append(["type": o.symbology.rawValue, "verdi": v])
                }
            }
        }
        let ocr = VNRecognizeTextRequest { req, _ in
            for o in (req.results as? [VNRecognizedTextObservation]) ?? [] {
                if let t = o.topCandidates(1).first, t.confidence > 0.3 { linjer.append(t.string) }
            }
        }
        ocr.recognitionLevel = .accurate
        ocr.usesLanguageCorrection = true
        // Bare språk telefonen faktisk støtter – et ukjent språk gir feil.
        let onsket = ["nb-NO", "no-NO", "nn-NO", "sv-SE", "da-DK", "en-US", "de-DE"]
        let finnes = (try? ocr.supportedRecognitionLanguages()) ?? ["en-US"]
        let valgt = onsket.filter { finnes.contains($0) }
        ocr.recognitionLanguages = valgt.isEmpty ? ["en-US"] : valgt

        try? VNImageRequestHandler(cgImage: cg, options: [:]).perform([strek, ocr])
        return (koder, linjer.joined(separator: "\n"))
    }
}
