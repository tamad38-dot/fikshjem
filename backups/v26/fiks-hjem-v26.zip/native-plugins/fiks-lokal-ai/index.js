// JS-siden ligger i appen (src/lib/lokalAI.ts). Denne pakken finnes for at
// `npx cap sync` skal ta med Swift-koden under ios/.
module.exports = {};
