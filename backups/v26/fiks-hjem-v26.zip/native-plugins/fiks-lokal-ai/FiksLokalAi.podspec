Pod::Spec.new do |s|
  s.name = 'FiksLokalAi'
  s.version = '0.1.0'
  s.summary = 'Fiks hjem: Apple Foundation Models som Capacitor-plugin'
  s.license = { :type => 'Proprietary' }
  s.homepage = 'https://github.com/tamad38-dot/fikshjem'
  s.author = 'Tamer Adiyaman'
  s.source = { :git => 'https://github.com/tamad38-dot/fikshjem.git', :tag => s.version.to_s }
  s.source_files = 'ios/Sources/**/*.swift'
  s.ios.deployment_target = '15.0'
  s.dependency 'Capacitor'
  s.swift_version = '5.9'
end
