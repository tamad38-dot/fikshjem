import json,sys
from playwright.sync_api import sync_playwright
JS=open('kontrast_js.txt').read()
J=json.load(open('jobber.json'))
U=sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8765/index.html'
funn={}
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':393,'height':852},is_mobile=True,has_touch=True)
    def sj(n):
        pg.wait_for_timeout(350); r=pg.evaluate(JS)
        if r: funn[n]=r
    def hjem(): pg.goto(U); pg.wait_for_timeout(1900)
    hjem(); sj('hjem')
    for t in ['guides','scan','cart','profile']: hjem(); pg.locator('[data-tf="tab-%s"]'%t).click(); sj('fane '+t)
    for d in ['hjem-bolig','hjem-beregn']: hjem(); pg.locator('[data-tf="%s"]'%d).click(); sj(d)
    # Teknisk tegning (Rom-modulen), alle fire trinn – nås fra modulvalget
    hjem(); pg.locator('[data-tf="hjem-fiks"]').click(); pg.wait_for_timeout(250)
    pg.get_by_text('Trapp',exact=True).first.click(); pg.get_by_text('Bygge trapp',exact=True).first.click(); pg.wait_for_timeout(250)
    pg.locator('[data-tf="fiks-vei-modul"]').click(); pg.wait_for_timeout(500); pg.get_by_text('‹ Alle prosjekter').click(); pg.wait_for_timeout(400)
    pg.locator('[data-tf="byggemoduler-ny-start"] > button').last.click(); pg.wait_for_timeout(700)
    for t in [1,2,3,4]:
        pg.locator('[data-tf="trinn-%d"]'%t).click(); pg.wait_for_timeout(500); sj('Teknisk tegning trinn %d'%t)
    for (d,n,*_) in J:
        hjem(); pg.locator('[data-tf="hjem-fiks"]').click(); pg.wait_for_timeout(250)
        pg.get_by_text(d,exact=True).first.click(); pg.wait_for_timeout(200); pg.get_by_text(n,exact=True).first.click(); sj('jobb '+n)
        veier=pg.locator('[data-tf^="fiks-vei-"]').evaluate_all('e=>e.filter(x=>x.tagName!=="A").map(x=>x.dataset.tf)')
        for v in veier:
            if v=='fiks-vei-film': continue
            pg.locator('[data-tf="%s"]'%v).click(); sj('%s / %s'%(n,v))
            if v=='fiks-vei-modul' and pg.locator('text=‹ Alle prosjekter').count():
                pg.get_by_text('‹ Alle prosjekter').click(); sj('modulvalg')
            hjem(); pg.locator('[data-tf="hjem-fiks"]').click(); pg.wait_for_timeout(250)
            pg.get_by_text(d,exact=True).first.click(); pg.wait_for_timeout(200); pg.get_by_text(n,exact=True).first.click(); pg.wait_for_timeout(250)
    b.close()
alle={}
for k,v in funn.items():
    for x in v: alle.setdefault(x,k)
for x,k in alle.items(): print(x,' <-',k)
print('unike funn:',len(alle))
