# To moduler i samlelisten -> «Send alt til handlelisten» -> begge skal ligge i handlelisten.
from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:8765/index.html'
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':393,'height':852},is_mobile=True,has_touch=True)
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    pg.goto(BASE); pg.wait_for_timeout(2200); pg.evaluate("localStorage.clear()"); pg.goto(BASE); pg.wait_for_timeout(2200)
    pg.locator('[data-tf="hjem-fiks"]').click(); pg.wait_for_timeout(300)
    pg.get_by_text('Terrasse og hage',exact=True).first.click(); pg.wait_for_timeout(300)
    pg.get_by_text('Bygge ny terrasse',exact=True).first.click(); pg.wait_for_timeout(300)
    pg.locator('[data-tf="fiks-vei-modul"]').click(); pg.wait_for_timeout(900)
    print('Terrassemodul synlig med en gang:', pg.get_by_text('Konstruksjon',exact=True).first.is_visible())
    pg.get_by_role('button',name='Legg i samlelisten').first.click(); pg.wait_for_timeout(300)
    # bytt til gulv i samme kategori? gulv ligger i annen mappe: gå via Alle prosjekter
    pg.get_by_text('‹ Alle prosjekter').click(); pg.wait_for_timeout(300)
    pg.get_by_role('button',name='Gulv').first.click(); pg.wait_for_timeout(600)
    pg.get_by_role('button',name='Legg i samlelisten').first.click(); pg.wait_for_timeout(300)
    print('Samleliste:', pg.get_by_text('Samleliste (').inner_text())
    pg.get_by_role('button',name='Send alt til handlelisten').click(); pg.wait_for_timeout(1200)
    navn=pg.evaluate("()=>JSON.parse(localStorage.getItem('fh_tf_cart')||'[]').map(x=>x.name)")
    print('Handlelisten (%d):'%len(navn), navn)
    terr=any('errassebord' in n or 'Bjelke' in n for n in navn); gulv=any('ulv' in n for n in navn)
    print('RESULTAT:', 'OK – begge modulene kom med' if terr and gulv else 'FEIL – en modul forsvant (terrasse=%s, gulv=%s)'%(terr,gulv))
    print('JS-feil:', errs or 'ingen'); b.close()
