# Arbeidsflyt-knappene (1 Mål … 5 Kontroll) i hver modul: skal hoppe til riktig del, uten feil.
from playwright.sync_api import sync_playwright
MOD=[('Vegg','Sette opp ny vegg'),('Vegg','Rive vegg eller lage døråpning'),('Gulv','Legge laminat eller parkett'),('Tak og loft','Beregne takkonstruksjon'),
     ('Terrasse og hage','Bygge ny terrasse'),('Terrasse og hage','Pergola'),('Trapp','Bygge trapp'),('Fasade','Ny kledning')]
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':393,'height':852},is_mobile=True,has_touch=True)
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    for d,n in MOD:
        pg.goto('http://127.0.0.1:8765/index.html'); pg.wait_for_timeout(2000)
        pg.locator('[data-tf="hjem-fiks"]').click(); pg.wait_for_timeout(250)
        pg.get_by_text(d,exact=True).first.click(); pg.get_by_text(n,exact=True).first.click(); pg.wait_for_timeout(250)
        pg.locator('[data-tf="fiks-vei-modul"]').click(); pg.wait_for_timeout(800)
        res=[]
        for i in range(5):
            pg.locator('[data-tf="flyt-%d"]'%i).click(); pg.wait_for_timeout(900)
            top=pg.evaluate("document.querySelector('main').scrollTop")
            res.append(int(top))
        print('%-32s scroll per steg: %s'%(n,res))
    print('JS-feil:',errs or 'ingen'); b.close()
