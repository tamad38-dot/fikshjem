const m = new Map();
export const Preferences = {
  async keys() { return { keys: [...m.keys()] }; },
  async get({ key }) { return { value: m.has(key) ? m.get(key) : null }; },
  async set({ key, value }) { m.set(key, value); },
  async remove({ key }) { m.delete(key); },
  async clear() { m.clear(); },
};
