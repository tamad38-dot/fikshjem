import React from 'react';
export default function RomViewer3D() { return <div data-tf="rom3d-stub" style={{padding:16,color:'#fff',background:'#10223a',borderRadius:12}}>3D-visning (three.js ikke i testbygget)</div>; }
