export const Capacitor = { isNativePlatform: () => false, getPlatform: () => 'web', isPluginAvailable: () => false };
export function registerPlugin() { return new Proxy({}, { get: () => async () => { throw new Error('ikke tilgjengelig i nettleser'); } }); }
