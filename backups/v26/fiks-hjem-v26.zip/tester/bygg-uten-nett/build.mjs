// Testbygg uten nett: esbuild + Tailwind v4 compile API. Speiler `vite build`.
import * as esbuild from '/opt/npm-tools/node_modules/esbuild/lib/main.js';
import { compile } from '/opt/npm-tools/node_modules/tailwindcss/dist/lib.mjs';
import fs from 'fs'; import path from 'path';
const ROOT = path.resolve(process.argv[2] || '/home/claude/src');
const OUT = path.resolve(process.argv[3] || '/home/claude/dist');
const SH = path.resolve('shims');
const STUB3D = process.env.STUB3D !== '0';
fs.rmSync(OUT, { recursive: true, force: true }); fs.mkdirSync(OUT + '/assets', { recursive: true });
fs.cpSync(ROOT + '/public', OUT, { recursive: true });
const NM = '/opt/npm-tools/node_modules';
const alias = {
  name: 'alias', setup(b) {
    b.onResolve({ filter: /^lucide-react$/ }, () => ({ path: SH + '/lucide-react.js' }));
    b.onResolve({ filter: /^react-icons\/lu$/ }, () => ({ path: NM + '/react-icons/lu/index.mjs' }));
    b.onResolve({ filter: /^react(-dom)?(\/.*)?$/ }, (a) => ({ path: require_resolve(a.path) }));
    b.onResolve({ filter: /^scheduler$/ }, () => ({ path: NM + '/scheduler/index.js' }));
    b.onResolve({ filter: /^@capacitor\/core$/ }, () => ({ path: SH + '/capacitor-core.js' }));
    b.onResolve({ filter: /^@capacitor\/preferences$/ }, () => ({ path: SH + '/capacitor-preferences.js' }));
    b.onResolve({ filter: /^@\// }, (a) => ({ path: resolveTs(path.join(ROOT, 'src', a.path.slice(2))) }));
    if (STUB3D) b.onResolve({ filter: /RomViewer3D(\.jsx)?$/ }, () => ({ path: SH + '/rom3d-stub.jsx' }));
    b.onLoad({ filter: /\.css$/ }, () => ({ contents: '', loader: 'css' }));
  }
};
import { createRequire } from 'module'; const req = createRequire(NM + '/x.js');
function require_resolve(p) { return req.resolve(p); }
function resolveTs(p) { for (const e of ['', '.ts', '.tsx', '.js', '.jsx']) if (fs.existsSync(p + e) && fs.statSync(p + e).isFile()) return p + e; return p; }
const r = await esbuild.build({
  entryPoints: [ROOT + '/src/main.tsx'], bundle: true, splitting: true, format: 'esm', outdir: OUT + '/assets',
  entryNames: 'index', chunkNames: '[name]-[hash]', assetNames: '[name]-[hash]', loader: { '.jpg': 'file', '.png': 'file', '.svg': 'file' },
  jsx: 'automatic', define: { 'process.env.NODE_ENV': '"production"', 'import.meta.env.DEV': 'false', 'import.meta.env.PROD': 'true' },
  minify: true, sourcemap: false, target: 'es2020', plugins: [alias], metafile: true, logLevel: 'warning', publicPath: '/assets',
});
// Tailwind
const css = fs.readFileSync(ROOT + '/src/styles.css', 'utf8');
const tw = await compile(css, {
  base: ROOT + '/src',
  loadStylesheet: async (id, base) => {
    if (id === 'tailwindcss') return { path: NM + '/tailwindcss/index.css', base: NM + '/tailwindcss', content: fs.readFileSync(NM + '/tailwindcss/index.css', 'utf8') };
    if (id.startsWith('tailwindcss/')) { const f = NM + '/' + id + (id.endsWith('.css') ? '' : '.css'); return { path: f, base: NM + '/tailwindcss', content: fs.readFileSync(f, 'utf8') }; }
    if (id === 'tw-animate-css') return { path: 'tw', base, content: '' };
    const f = path.resolve(base, id); return { path: f, base: path.dirname(f), content: fs.readFileSync(f, 'utf8') };
  },
  loadModule: async () => ({ module: {}, base: '' }),
});
const cand = new Set();
(function walk(d) { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) walk(p); else if (/\.(jsx?|tsx?|html)$/.test(f)) for (const t of fs.readFileSync(p, 'utf8').split(/[\s"'`{}<>()=,;\\]+/)) if (t && t.length < 80) cand.add(t); } })(ROOT + '/src');
fs.writeFileSync(OUT + '/assets/index.css', tw.build([...cand]));
const html = fs.readFileSync(ROOT + '/index.html', 'utf8').replace('<script type="module" src="/src/main.tsx"></script>', '<link rel="stylesheet" href="./assets/index.css"><script type="module" src="./assets/index.js"></script>').replace('href="/favicon.svg"', 'href="./favicon.svg"');
fs.writeFileSync(OUT + '/index.html', html);
const sz = Object.entries(r.metafile.outputs).map(([k, v]) => [path.basename(k), v.bytes]).sort((a, b) => b[1] - a[1]).slice(0, 6);
console.log('OK', JSON.stringify(sz), 'warnings', r.warnings.length);
