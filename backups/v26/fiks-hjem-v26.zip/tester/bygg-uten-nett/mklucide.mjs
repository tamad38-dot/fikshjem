import fs from 'fs'; import path from 'path';
const src = process.argv[2];
const files = [];
(function walk(d){ for (const f of fs.readdirSync(d)) { const p = path.join(d,f); if (fs.statSync(p).isDirectory()) walk(p); else if (/\.(jsx?|tsx?)$/.test(f)) files.push(p);} })(src);
const names = new Set();
for (const f of files) { const t = fs.readFileSync(f,'utf8'); for (const m of t.matchAll(/import\s*\{([^}]*)\}\s*from\s*['"]lucide-react['"]/g)) for (let n of m[1].split(',')) { n=n.trim().split(/\s+as\s+/)[0].trim(); if(n) names.add(n);} }
const lu = await import('/opt/npm-tools/node_modules/react-icons/lu/index.mjs');
const alias = { CheckCircle2:'LuCircleCheck', AlertCircle:'LuCircleAlert', HelpCircle:'LuCircleHelp', PlayCircle:'LuCirclePlay', Loader2:'LuLoaderCircle', Image:'LuImage', AlertTriangle:'LuTriangleAlert', XCircle:'LuCircleX', MoreHorizontal:'LuEllipsis', Edit:'LuPencil', Edit3:'LuPenLine', BarChart3:'LuChartColumn', Layers3:'LuLayers', Grid3x3:'LuGrid3X3', CheckCircle:'LuCircleCheckBig', Unlock:'LuLockOpen', Home:'LuHouse', ArrowUpRight:'LuArrowUpRight'};
let out = "import * as L from 'react-icons/lu';\nimport React from 'react';\nconst mk=(C)=>React.forwardRef(function I({size=24,color,strokeWidth=2,absoluteStrokeWidth,...p},ref){return React.createElement(C,{size,color,strokeWidth,ref,...p});});\nconst F=(p)=>React.createElement('svg',{width:p.size||24,height:p.size||24,viewBox:'0 0 24 24',fill:'none',stroke:'currentColor',strokeWidth:2,className:p.className,style:p.style},React.createElement('circle',{cx:12,cy:12,r:9}));\n";
const miss=[];
for (const n of names) { const k = alias[n] || ('Lu'+n); if (lu[k]) out += `export const ${n}=mk(L.${k});\n`; else { miss.push(n); out += `export const ${n}=F;\n`; } }
fs.writeFileSync('shims/lucide-react.js', out);
console.log('icons', names.size, 'missing', miss.join(','));
