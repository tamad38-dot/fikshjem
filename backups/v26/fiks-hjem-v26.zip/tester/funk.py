import json
from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:8765/'
L=[]
def ok(c,m): L.append(('OK   ' if c else 'FEIL ')+m)
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':393,'height':852},is_mobile=True,has_touch=True)
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)[:150]))
    api=[]; pg.on('request',lambda r: api.append(r.url) if 'anthropic' in r.url or '/v1/messages' in r.url else None)
    def til_ai():
        pg.goto(BASE+'index.html'); pg.wait_for_timeout(2600)
        pg.locator('[data-tf="hjem-fiks"]').click(); pg.wait_for_timeout(400)
        pg.get_by_text('Vegg',exact=True).first.click(); pg.wait_for_timeout(300)
        pg.get_by_text('Tapetsere',exact=True).first.click(); pg.wait_for_timeout(300)
        pg.locator('[data-tf="fiks-vei-film"]').click(); pg.wait_for_timeout(600)
    def spor(t):
        pg.locator('[data-tf="ai-felt"]').fill(t); pg.locator('[data-tf="ai-send"]').click(); pg.wait_for_timeout(1200)
    # 0: modulen lokalAI er med i bygget
    pg.goto(BASE+'index.html'); pg.wait_for_timeout(2600)
    ok(pg.evaluate("typeof window.FIKS_LOKAL_AI==='object' && typeof window.FIKS_LOKAL_AI.bilde==='function'"),'lokalAI-modulen er med i bygget (window.FIKS_LOKAL_AI finnes)')
    ok(pg.evaluate("window.FIKS_LOKAL_AI.finnes().then(x=>x===false)"),'I nettleser: telefonens AI rapporteres som ikke tilgjengelig')
    # 1: fagfolk-jobb stoppes lokalt, uten AI-kall
    til_ai(); ok(pg.locator('[data-tf="ai-jobb"]').count()==1,'AI-skjermen åpnes fra jobb uten guide (Tapetsere)')
    n0=len(api); spor('bytte sikringsskap og legge ny kurs')
    ok(pg.locator('[data-tf="ai-stopp"]').count()==1,'Elektrisk arbeid stoppes: «Krever fagfolk» vises')
    ok(len(api)==n0,'Ingen AI-kall ble sendt for fagfolk-jobben')
    # 2: vanlig jobb uten nøkkel og uten telefon-AI -> forklaring, ikke krasj
    til_ai(); spor('tapetsere en vegg i stua')
    ok(pg.locator('[data-tf="pro-skjerm"]').count()==1,'Uten nøkkel og uten telefon-AI: forklaringsskjermen vises')
    ok(len(api)==n0,'Fortsatt ingen AI-kall uten nøkkel')
    # 3: med (simulert) telefon-AI
    til_ai()
    pg.evaluate("""window.__kall=0; window.FIKS_LOKAL_AI={finnes:async()=>true, bildeFinnes:async()=>true, bilde:async()=>({}),
      svar:async()=>{window.__kall++; return JSON.stringify({jobb:'Tapetsere vegg',niva:'selv',steg:[{tittel:'Fjern gammel tapet',tekst:'Løsne tapeten med vann.'},{tittel:'Sparkle',tekst:'Sparkle hull.'},{tittel:'Tapetser',tekst:'Lim og heng opp banene.'}]})}}""")
    spor('tapetsere en vegg i stua')
    ok(pg.locator('[data-tf="ai-svar"]').count()==1,'Telefonens AI: forslag vises')
    body=pg.locator('[data-tf="ai-jobb"]').inner_text()
    ok('kildebelagt' in body.lower(),'Forslaget er merket «ikke kildebelagt»')
    ok(pg.evaluate('window.__kall')==1,'Telefonens AI ble spurt én gang')
    fb=pg.get_by_text('tegnefilm',exact=False)
    ok(fb.count()>0,'Knapp for tegnefilm av forslaget finnes')
    # 4: fagfolk-jobb med telefon-AI: AI skal ikke spørres
    spor('flytte stikkontakt på badet'); ok(pg.locator('[data-tf="ai-stopp"]').count()==1,'Fagfolk stoppes også når telefonens AI finnes')
    ok(pg.evaluate('window.__kall')==1,'Telefonens AI ble ikke spurt om fagfolk-jobben')
    # 5: beskjed i stedet for alert (ingen dialoger i hele testen)
    d=[]; pg.on('dialog',lambda x:(d.append(x.message),x.dismiss()))
    ok(len(d)==0,'Ingen alert/confirm-dialoger dukket opp')
    print('\n'.join(L)); print('JS-feil:',errs or 'ingen'); b.close()
