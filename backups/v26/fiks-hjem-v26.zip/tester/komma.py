# Skriver «2,4» med tastaturet i terrassemodulen og sjekker at arealet blir 2,4 × 3 = 7,2 m².
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':393,'height':852},is_mobile=True,has_touch=True,locale='nb-NO')
    pg.goto('http://127.0.0.1:8765/index.html'); pg.wait_for_timeout(2200); pg.evaluate("localStorage.clear()"); pg.goto('http://127.0.0.1:8765/index.html'); pg.wait_for_timeout(2200)
    pg.locator('[data-tf="hjem-fiks"]').click(); pg.wait_for_timeout(300)
    pg.get_by_text('Terrasse og hage',exact=True).first.click(); pg.get_by_text('Bygge ny terrasse',exact=True).first.click(); pg.wait_for_timeout(300)
    pg.locator('[data-tf="fiks-vei-modul"]').click(); pg.wait_for_timeout(900)
    f=pg.get_by_label('Bredde (m)').first
    print('felttype:', f.get_attribute('type'), f.get_attribute('inputmode'))
    f.click(); pg.keyboard.press('Control+A'); pg.keyboard.type('2,4', delay=80); pg.wait_for_timeout(400)
    print('feltet viser:', f.input_value())
    rad=pg.locator('text=Areal').first.locator('xpath=..').inner_text().replace('\n',' ')
    print('rad:', rad, '->', 'OK' if '7,2 m²' in rad else 'FEIL')
    # Fasadetegning (Teknisk tegning, trinn 4): «5,4» skal kunne skrives ferdig
    pg.goto('http://127.0.0.1:8765/index.html'); pg.wait_for_timeout(2000)
    pg.locator('[data-tf="hjem-fiks"]').click(); pg.wait_for_timeout(250)
    pg.get_by_text('Trapp',exact=True).first.click(); pg.get_by_text('Bygge trapp',exact=True).first.click(); pg.wait_for_timeout(250)
    pg.locator('[data-tf="fiks-vei-modul"]').click(); pg.wait_for_timeout(500); pg.get_by_text('‹ Alle prosjekter').click(); pg.wait_for_timeout(400)
    pg.locator('[data-tf="byggemoduler-ny-start"] > button').last.click(); pg.wait_for_timeout(700)
    pg.locator('[data-tf="trinn-4"]').click(); pg.wait_for_timeout(500)
    f2=pg.get_by_label('Fasadebredde (m)').first
    f2.click(); pg.keyboard.press('Control+A'); pg.keyboard.type('9,6', delay=80); pg.wait_for_timeout(400)
    print('fasadebredde viser:', f2.input_value(), '->', 'OK' if f2.input_value()=='9,6' else 'FEIL')
    b.close()
