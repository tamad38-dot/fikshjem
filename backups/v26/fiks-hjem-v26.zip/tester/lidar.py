# LiDAR-flyten i nettleseren med en SIMULERT telefon (ekte LiDAR kan bare testes på iPhone).
# Telefonens svar settes inn som window.TAMERFIX_MAAL_AR / TAMERFIX_SKANN_ROM før appen starter.
import json, sys
from playwright.sync_api import sync_playwright
U='http://127.0.0.1:8765/index.html'
RAA=open('lidar-eksempel.json').read()
SKUDD=sys.argv[1] if len(sys.argv)>1 else ''
L=[]
def ok(c,m): L.append(('OK   ' if c else 'FEIL ')+m)
INIT="window.TAMERFIX_MAAL_AR=async()=>{window.__maalt=(window.__maalt||0)+1;return 2.43};window.TAMERFIX_SKANN_ROM=async()=>(%s);"%RAA
with sync_playwright() as p:
    b=p.chromium.launch()
    # 1) Uten telefon: ingen LiDAR-knapper
    pg=b.new_page(viewport={'width':393,'height':852},is_mobile=True,has_touch=True)
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    pg.goto(U); pg.wait_for_timeout(1800); pg.evaluate('localStorage.clear()'); pg.goto(U); pg.wait_for_timeout(2000)
    pg.locator('[data-tf="hjem-fiks"]').click(); pg.get_by_text('Terrasse og hage',exact=True).first.click(); pg.get_by_text('Bygge ny terrasse',exact=True).first.click(); pg.wait_for_timeout(300)
    pg.locator('[data-tf="fiks-vei-modul"]').click(); pg.wait_for_timeout(700)
    ok(pg.locator('[data-tf="lidar-maal"]').count()==0,'Uten LiDAR-telefon: ingen «Mål»-knapper (nettleser)')
    pg.close()
    # 2) Med simulert iPhone med LiDAR
    ctx=b.new_context(viewport={'width':393,'height':852},device_scale_factor=2,is_mobile=True,has_touch=True)
    ctx.add_init_script(INIT); pg=ctx.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    pg.goto(U); pg.wait_for_timeout(1800); pg.evaluate('localStorage.clear()'); pg.goto(U); pg.wait_for_timeout(2000)
    pg.locator('[data-tf="hjem-fiks"]').click(); pg.get_by_text('Terrasse og hage',exact=True).first.click(); pg.get_by_text('Bygge ny terrasse',exact=True).first.click(); pg.wait_for_timeout(300)
    pg.locator('[data-tf="fiks-vei-modul"]').click(); pg.wait_for_timeout(700)
    n=pg.locator('[data-tf="lidar-maal"]').count()
    ok(n>=2,'Terrasse: «📏 Mål»-knapp ved Bredde og Dybde (%d)'%n)
    pg.locator('[data-tf="lidar-maal"]').first.click(); pg.wait_for_timeout(500)
    v=pg.get_by_label('Bredde (m)').first.input_value()
    ok(v=='2,43','Terrasse: målt bredde settes inn som 2,43 (%s)'%v)
    rad=pg.locator('text=Areal').first.locator('xpath=..').inner_text().replace('\n',' ')
    ok('7,29 m²' in rad,'Terrasse: areal regnes ut på nytt: 2,43 × 3 = 7,29 m² (%s)'%rad)
    if SKUDD: pg.get_by_label('Bredde (m)').first.scroll_into_view_if_needed(); pg.evaluate("document.querySelector('main').scrollBy(0,-160)"); pg.wait_for_timeout(300); pg.screenshot(path=SKUDD+'-maal.png')
    # Rom: skann
    pg.get_by_text('‹ Alle prosjekter').click(); pg.wait_for_timeout(500)
    kort=pg.get_by_text('📡 Skann rommet med LiDAR').count()
    ok(kort==1,'Byggemoduler: kortet heter «Skann rommet med LiDAR»')
    pg.get_by_text('📡 Skann rommet med LiDAR').click(); pg.wait_for_timeout(800)
    ok(pg.locator('[data-tf="lidar-kort"]').count()==1,'Teknisk tegning: LiDAR-kortet vises øverst')
    if SKUDD: pg.evaluate("document.querySelector('main').scrollTo(0,0)"); pg.wait_for_timeout(300); pg.screenshot(path=SKUDD+'-kort.png')
    pg.locator('[data-tf="lidar-skann-rom"]').click(); pg.wait_for_timeout(1200)
    navn=pg.locator('[data-tf="rom-navn"]')
    t=navn.inner_text() if navn.count() else ''
    ok('13 m²' in t or '13,0 m²' in t,'Skann: rommet er 4,2 × 3,1 = 13 m² («%s»)'%t.replace('\n',' ')[:90])
    ok('3 dører og vinduer' in t,'Skann: 1 dør og 2 vinduer funnet')
    if SKUDD: pg.wait_for_timeout(400); pg.screenshot(path=SKUDD+'-navn.png')
    navn.get_by_text('Stue',exact=True).click(); pg.wait_for_timeout(700)
    lag=pg.evaluate("()=>{const k=Object.keys(localStorage).find(x=>x.includes('tegninger'));return k?localStorage.getItem(k):''}")
    d=json.loads(lag) if lag else {}
    tegn=[v for v in d.values()][0] if d else {}
    romd=(tegn.get('rom') or {})
    ok(len(romd.get('rom',[]))==1 and romd['rom'][0]['navn']=='Stue','Rommet «Stue» er lagret')
    ap=romd.get('apninger',[])
    ok(len(ap)==3 and all(a.get('romId')==romd['rom'][0]['id'] for a in ap),'3 åpninger lagret og koblet til rommet')
    ok(abs(float(romd.get('takhoyde',0))-2.4)<0.01,'Takhøyden fra skanningen (2,4 m) er satt')
    if SKUDD:
        pg.evaluate("document.querySelector('main').scrollTo(0,0)"); pg.wait_for_timeout(300)
        pg.evaluate("()=>{const s=[...document.querySelectorAll('main svg')].sort((a,b)=>b.getBoundingClientRect().width*b.getBoundingClientRect().height-a.getBoundingClientRect().width*a.getBoundingClientRect().height)[0]; if(s) s.scrollIntoView({block:'center'})}")
        pg.wait_for_timeout(400); pg.screenshot(path=SKUDD+'-plan.png')
    b.close()
print('\n'.join(L)); print('JS-feil:',errs or 'ingen')
