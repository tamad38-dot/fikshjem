#!/usr/bin/env bash
# Kjører alle klikktestene mot bygget på http://127.0.0.1:8765/
#   npm run build && npx vite preview --port 8765   (i et annet vindu)
#   cd tester && bash kjor-alle.sh
set -u
cd "$(dirname "$0")"
mkdir -p systest katalog
echo "=== romplan (LiDAR-omforming, node)"
node romplan-test.mjs | tail -3
for t in funk verktoytest rodprikk-ramme-zoom samleliste komma lagring flyt lidar modulfuzz overflow kontrast; do
  echo "=== $t"
  python3 "$t.py" 2>&1 | tail -25
done
echo "=== systest (lang, ca. 15 min)"
python3 systest.py && python3 -c "import json;d=json.load(open('systest/res.json'));R=d['R'];print(len(R),'steg');[print(' ',r) for r in R if r[1]!='OK' or r[2]];print('JS-feil:',d['ERR'] or 'ingen');print('Nettfeil:',d['NET'] or 'ingen')"
