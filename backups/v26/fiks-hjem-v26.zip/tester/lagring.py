# Verdier i terrassemodulen og handlelisten skal overleve at appen lukkes og åpnes igjen.
from playwright.sync_api import sync_playwright
U='http://127.0.0.1:8765/index.html'
def til_terrasse(pg):
    pg.locator('[data-tf="hjem-fiks"]').click(); pg.wait_for_timeout(300)
    pg.get_by_text('Terrasse og hage',exact=True).first.click(); pg.get_by_text('Bygge ny terrasse',exact=True).first.click(); pg.wait_for_timeout(300)
    pg.locator('[data-tf="fiks-vei-modul"]').click(); pg.wait_for_timeout(900)
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':393,'height':852},is_mobile=True,has_touch=True)
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    pg.goto(U); pg.wait_for_timeout(2000); pg.evaluate("localStorage.clear()"); pg.goto(U); pg.wait_for_timeout(2200)
    til_terrasse(pg)
    f=pg.get_by_label('Bredde (m)').first; f.click(); pg.keyboard.press('Control+A'); pg.keyboard.type('5,5'); pg.wait_for_timeout(300)
    pg.get_by_role('button',name='Legg i samlelisten').first.click(); pg.get_by_role('button',name='Send alt til handlelisten').click(); pg.wait_for_timeout(1000)
    pg.goto(U); pg.wait_for_timeout(2500)
    til_terrasse(pg)
    v=pg.get_by_label('Bredde (m)').first.input_value()
    print('Bredde etter omstart:', v, 'OK' if v=='5,5' else 'FEIL')
    pg.locator('[data-tf="tab-cart"]').click(); pg.wait_for_timeout(600)
    t=pg.locator('main').inner_text()
    print('Handleliste etter omstart:', 'OK' if 'Terrassebord' in t else 'FEIL')
    print('JS-feil:', errs or 'ingen'); b.close()
