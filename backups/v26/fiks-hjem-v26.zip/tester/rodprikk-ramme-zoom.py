import re,pathlib
from playwright.sync_api import sync_playwright
L=[]
def ok(c,m): L.append(('OK   ' if c else 'FEIL ')+m)
with sync_playwright() as p:
  b=p.chromium.launch(); ctx=b.new_context(viewport={'width':393,'height':852},device_scale_factor=2,is_mobile=True,has_touch=True)
  pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
  pg.goto('http://127.0.0.1:8765/verktoy/rod-prikk.html'); pg.wait_for_timeout(800)
  s=pg.locator('#sahne').bounding_box()
  def tap(fx,fy):
    pg.mouse.click(s['x']+s['width']*fx, s['y']+s['height']*fy); pg.wait_for_timeout(200)
  def btn(t): pg.get_by_role('button',name=re.compile(t)).first.click(); pg.wait_for_timeout(200)
  def maal(v): pg.locator('#maalInn').fill(v); btn('^Lagre mål')
  # vindu: x 170-240 / 640, y 210-270 / 440
  C=[(170/640,210/440),(240/640,210/440),(240/640,270/440),(170/640,270/440)]
  tap(*C[0]); btn('Ferdig med punkt 1')
  tap(*C[1]); btn('Ferdig med punkt 2'); maal('1,20')
  tap(*C[2]); btn('Ferdig med punkt 3'); maal('1,00')
  tap(*C[3]); btn('Ferdig med punkt 4'); maal('1,20')
  ok(pg.get_by_role('button',name=re.compile('lukk rammen')).count()==1,'«Ferdig – lukk rammen» vises etter 4 hjørner')
  btn('lukk rammen'); ok(pg.locator('#maalInn').is_visible() and 'side D' in pg.locator('#stHva').inner_text(),'Lukking spør om siste side (D)')
  maal('1,00')
  ok('Hva er' in pg.locator('#stHva').inner_text(),'Spør om navn/type etter lukking')
  pg.get_by_role('button',name='Vindu',exact=True).click(); pg.wait_for_timeout(200)
  ok(pg.locator('.rnavn').first.inner_text()=='Vindu 1','Rammen heter «Vindu 1» og vises midt i figuren')
  lst=pg.locator('#maalListe').inner_text()
  ok(all(x in lst for x in ['A · punkt 1 → 2','D · punkt 4 → 1','1,20 m']),'Listen grupperer sidene A–D under rammen')
  # andre ramme: dør
  D=[(270/640,255/440),(350/640,255/440),(350/640,368/440),(270/640,368/440)]
  for i,c in enumerate(D):
    tap(*c); btn('Ferdig med punkt %d'%(i+1))
    if i: btn('Mål senere')
  btn('lukk rammen'); btn('Mål senere'); pg.get_by_role('button',name='Dør',exact=True).click(); pg.wait_for_timeout(200)
  navn=[x.inner_text() for x in pg.locator('.rnavn').all()]
  ok(navn==['Vindu 1','Dør 1'],'To rammer i samme bilde: %s'%navn)
  ok(pg.locator('.punkt').nth(4).inner_text()=='1','Punktene nummereres på nytt i hver ramme')
  # gi nytt navn
  pg.locator('.rnavnInn').nth(1).fill('Inngangsdør'); pg.locator('.rnavnInn').nth(1).press('Enter'); pg.locator('#stHva').click(); pg.wait_for_timeout(200)
  ok('Inngangsdør' in [x.inner_text() for x in pg.locator('.rnavn').all()],'Navn kan endres i listen')
  # zoom-knapper
  pg.get_by_role('button',name='Zoom inn').click(); pg.wait_for_timeout(200)
  tr=pg.locator('#flate').evaluate('e=>e.style.transform')
  ok('scale(1.6' in tr,'Zoom inn-knappen forstørrer bildet (%s)'%tr)
  # sett punkt mens zoomet: må havne der fingeren er
  before=pg.locator('.punkt').count(); bb=pg.locator('#sahne').bounding_box()
  pg.mouse.click(bb['x']+bb['width']*.5,bb['y']+bb['height']*.5); pg.wait_for_timeout(200)
  pk=pg.locator('.punkt.aktiv').bounding_box()
  ok(pk and abs(pk['x']+pk['width']/2-(bb['x']+bb['width']*.5))<4,'Punkt satt i zoom havner under fingeren')
  ok(pk and pk['width']<40,'Punktet holder samme størrelse når bildet er zoomet (%.0f px)'%(pk['width'] if pk else 0))
  btn('Slett punktet')
  # knip med to fingre via CDP
  cdp=ctx.new_cdp_session(pg); cx=bb['x']+bb['width']/2; cy=bb['y']+bb['height']/2
  pg.get_by_role('button',name='Tilpass').click(); pg.wait_for_timeout(200)
  def tp(pts): return [{'x':x,'y':y,'id':i} for i,(x,y) in enumerate(pts)]
  cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':tp([(cx-30,cy),(cx+30,cy)])})
  for k in range(1,8): cdp.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':tp([(cx-30-k*12,cy),(cx+30+k*12,cy)])})
  cdp.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]}); pg.wait_for_timeout(300)
  tr=pg.locator('#flate').evaluate('e=>e.style.transform'); sc=float(re.search(r'scale\(([\d.]+)',tr).group(1))
  ok(sc>1.8,'Knip med to fingre zoomer inn (skala %.2f)'%sc)
  ok(pg.locator('.punkt').count()==before,'Knipet satte ikke noe nytt punkt')
  pg.screenshot(path='rp1.png')
  pg.get_by_role('button',name='Tilpass').click(); pg.wait_for_timeout(200); pg.screenshot(path='rp2.png')
  pg.get_by_role('button',name=re.compile('Tegning')).click(); pg.wait_for_timeout(300); pg.screenshot(path='rp3.png')
  ok('Vindu 1' in pg.locator('#teknikSvg').inner_html(),'Teknisk tegning viser rammenavn')
  # angre åpner siste ramme igjen
  pg.get_by_role('button',name=re.compile('Punkt')).first.click(); pg.wait_for_timeout(200)
  btn('Angre siste punkt'); ok('åpnet igjen' in pg.locator('#melding').inner_text(),'Angre åpner siste ramme igjen')
  print('\n'.join(L)); print('JS-feil:',errs or 'ingen'); b.close()
