// Enhetstest for LiDAR-omformingen (src/lib/romplan.js) med kunstige skann.
// Kjør: node tester/romplan-test.mjs
import { romFraSkann } from '../src/lib/romplan.js';
let feil = 0;
const ok = (c, m) => { console.log((c ? 'OK   ' : 'FEIL ') + m); if (!c) feil++; };
const naer = (a, b, t = 0.03) => Math.abs(a - b) <= t;
const areal = (p) => { let s = 0; for (let i = 0; i < p.length; i++) { const a = p[i], b = p[(i + 1) % p.length]; s += a.x * b.y - b.x * a.y; } return Math.abs(s) / 2; };
const kant = (p, i) => { const a = p[i], b = p[(i + 1) % p.length]; return Math.hypot(b.x - a.x, b.y - a.y); };

// Lager RoomPlan-lignende rådata fra et rom tegnet i planet, dreid og flyttet som en ekte skann.
export function lagSkann(hjorner, { vinkel = 0.52, tx = 5, tz = -2, gulvY = -1.3, hoyde = 2.4, over = 0.08, apn = [] } = {}) {
  const c = Math.cos(vinkel), s = Math.sin(vinkel);
  const T = (p) => ({ x: p.x * c - p.y * s + tx, z: p.x * s + p.y * c + tz });
  const vegger = hjorner.map((a, i) => {
    const b = hjorner[(i + 1) % hjorner.length];
    const A = T(a), B = T(b), L = Math.hypot(B.x - A.x, B.z - A.z);
    // annenhver vegg har motsatt retning, og rekkefølgen stokkes – slik RoomPlan gjør
    const rett = i % 2 === 0;
    return { cx: (A.x + B.x) / 2, cy: gulvY + hoyde / 2, cz: (A.z + B.z) / 2,
      dx: (rett ? 1 : -1) * (B.x - A.x) / L, dz: (rett ? 1 : -1) * (B.z - A.z) / L, bredde: L + over, hoyde };
  });
  const stokket = [vegger[2], vegger[0], ...vegger.slice(3), vegger[1]];
  const ut = { vegger: stokket, dorer: [], vinduer: [], apninger: [] };
  apn.forEach((o) => {
    const a = hjorner[o.vegg], b = hjorner[(o.vegg + 1) % hjorner.length];
    const L = Math.hypot(b.x - a.x, b.y - a.y), ux = (b.x - a.x) / L, uy = (b.y - a.y) / L;
    const m = T({ x: a.x + ux * (o.pos + o.b / 2), y: a.y + uy * (o.pos + o.b / 2) });
    (o.type === 'Dor' ? ut.dorer : ut.vinduer).push({ cx: m.x, cz: m.z, cy: gulvY + o.sh + o.h / 2, dx: 0, dz: 1, bredde: o.b, hoyde: o.h });
  });
  return ut;
}

// 1) Rektangel 4,2 × 3,1 m, dreid 30°, vinduet 1,2 m bredt 1,0 m fra hjørnet, brystning 0,9 m
{
  const H = [{ x: 0, y: 0 }, { x: 4.2, y: 0 }, { x: 4.2, y: 3.1 }, { x: 0, y: 3.1 }];
  const r = romFraSkann(lagSkann(H, { apn: [{ type: 'Vindu', vegg: 0, pos: 1.0, b: 1.2, h: 1.0, sh: 0.9 }, { type: 'Dor', vegg: 2, pos: 0.4, b: 0.9, h: 2.1, sh: 0 }] }));
  ok(r.punkter.length === 4, 'Rektangel: 4 hjørner (' + r.punkter.length + ')');
  ok(naer(areal(r.punkter), 13.02, 0.06), 'Rektangel: areal 13,02 m² (' + areal(r.punkter).toFixed(2) + ')');
  ok(r.punkter.every((p) => p.x >= -0.001 && p.y >= -0.001), 'Rektangel: planen starter i 0,0');
  const kanter = r.punkter.map((_, i) => kant(r.punkter, i)).sort((a, b) => a - b);
  ok(naer(kanter[0], 3.1) && naer(kanter[3], 4.2), 'Rektangel: veggene er 3,1 og 4,2 m (veggenes overheng er fjernet)');
  ok(r.punkter.every((p, i) => { const q = r.punkter[(i + 1) % 4]; return naer(p.x, q.x, 0.01) || naer(p.y, q.y, 0.01); }), 'Rektangel: veggene ligger rett (snudd til akse)');
  ok(naer(r.takhoyde, 2.4, 0.001), 'Rektangel: takhøyde 2,4 m');
  const v = r.apninger.find((a) => a.type === 'Vindu'), d = r.apninger.find((a) => a.type === 'Dor');
  ok(v && naer(kant(r.punkter, v.veggIndeks), 4.2), 'Vindu: ligger på en 4,2 m-vegg');
  ok(v && (naer(v.pos, 1.0) || naer(v.pos, 4.2 - 1.0 - 1.2)), 'Vindu: 1,0 m fra hjørnet (' + (v && v.pos) + ')');
  ok(v && naer(v.sh, 0.9) && naer(v.b, 1.2) && naer(v.h, 1.0), 'Vindu: brystning 0,9, 1,2 × 1,0 m');
  ok(d && naer(kant(r.punkter, d.veggIndeks), 4.2) && d.sh === 0 && naer(d.b, 0.9), 'Dør: på riktig vegg, 0,9 m, fra gulvet');
  ok(r.advarsler.length === 0, 'Ingen advarsler (' + r.advarsler.join(' / ') + ')');
}
// 2) L-formet stue (6 vegger)
{
  const H = [{ x: 0, y: 0 }, { x: 6, y: 0 }, { x: 6, y: 2.5 }, { x: 3.5, y: 2.5 }, { x: 3.5, y: 5 }, { x: 0, y: 5 }];
  const r = romFraSkann(lagSkann(H, { vinkel: -1.1, tx: -3, tz: 7 }));
  ok(r.punkter.length === 6, 'L-rom: 6 hjørner (' + r.punkter.length + ')');
  ok(naer(areal(r.punkter), 6 * 2.5 + 3.5 * 2.5, 0.08), 'L-rom: areal 23,75 m² (' + areal(r.punkter).toFixed(2) + ')');
}
// 3) iOS 17+: gulvets hjørner fra telefonen brukes direkte
{
  const r = romFraSkann({ vegger: [{ cx: 0, cy: 0, cz: 0, dx: 1, dz: 0, bredde: 3, hoyde: 2.5 }], gulv: [{ x: 1, z: 1 }, { x: 4, z: 1 }, { x: 4, z: 3.5 }, { x: 1, z: 3.5 }] });
  ok(naer(areal(r.punkter), 7.5, 0.01) && naer(r.takhoyde, 2.5), 'Gulvpolygon: 3 × 2,5 m, takhøyde 2,5');
}
// 4) For lite data gir forståelig feil, ikke krasj
{
  let melding = '';
  try { romFraSkann({ vegger: [{ cx: 0, cy: 0, cz: 0, dx: 1, dz: 0, bredde: 3, hoyde: 2.5 }] }); } catch (e) { melding = e.message; }
  ok(/for få vegger/i.test(melding), 'For få vegger: norsk feilmelding («' + melding + '»)');
  try { romFraSkann(null); melding = ''; } catch (e) { melding = e.message; }
  ok(/ingen data/.test(melding), 'Tom skann: norsk feilmelding');
}
console.log(feil ? feil + ' FEIL' : 'Alle romplan-testene OK');
process.exit(feil ? 1 : 0);
