import re
from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:8765/verktoy/'
L=[]
def ok(c,m): L.append(('OK   ' if c else 'FEIL ')+m)
TR=re.compile(r'\b(ve|bir|için|icin|Hesapla|Açı|Kesim|Uyarı|resim|nokta|ölçü|Kaydet|Tamam)\b|[ğışİĞŞ]')
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':393,'height':852},is_mobile=True,has_touch=True)
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)[:150]))
    d=[]; pg.on('dialog',lambda x:(d.append(x.message),x.dismiss()))
    for f in ['index','slik-gjor-du','fasade-fra-foto','rod-prikk','vinkel-kapp','fasadetegning']:
        pg.goto(BASE+f+'.html'); pg.wait_for_timeout(1200)
        t=pg.locator('body').inner_text(); m=TR.findall(t)
        ok(not m,'%s: ingen tyrkisk tekst på skjermen %s'%(f, m[:5] if m else ''))
    # Rød prikk: eksempelbilde, tre punkter, mål med komma
    pg.goto(BASE+'rod-prikk.html'); pg.wait_for_timeout(1000)
    pg.locator('#eksempel').click(); pg.wait_for_timeout(900)
    s=pg.locator('#sahne').bounding_box()
    def tap(x,y): pg.mouse.click(s['x']+s['width']*x, s['y']+s['height']*y); pg.wait_for_timeout(350)
    tap(.2,.3); ok(pg.locator('#punktLag *').count()>0,'Rød prikk: første punkt satt')
    tap(.25,.35); ok('Ferdig' in pg.locator('#status').inner_text(),'Rød prikk: aktivt punkt kan flyttes før «Ferdig»')
    pg.get_by_text(re.compile('Ferdig med punkt 1')).click(); pg.wait_for_timeout(300)
    tap(.7,.35); pg.get_by_text(re.compile('Ferdig med punkt 2')).click(); pg.wait_for_timeout(400)
    vis=pg.locator('#maalInn').is_visible()
    ok(vis,'Rød prikk: spør om mål mellom punkt 1 og 2')
    if vis:
        pg.locator('#maalInn').fill('2,40'); pg.get_by_text('Lagre mål').click(); pg.wait_for_timeout(400)
        ok('2,40' in pg.locator('#maalListe').inner_text() or '2,40' in pg.locator('#etikettLag').inner_text(),'Rød prikk: 2,40 m lagret og vist med komma')
    ok(pg.locator('#linjeLag line, #linjeLag path, #linjeLag polyline').count()>0,'Rød prikk: svart linje mellom punktene')
    # Vinkel og kapp: regn ut med komma
    pg.goto(BASE+'vinkel-kapp.html'); pg.wait_for_timeout(900)
    inp=pg.locator('input:visible')
    ok(inp.count()>0,'Vinkel og kapp: feltene vises')
    print('\n'.join(L)); print('Dialoger:',d or 'ingen'); print('JS-feil:',errs or 'ingen'); b.close()
