# Fyller alle tallfelt i hver beregningsmodul med vanskelige verdier og ser etter krasj, NaN, Infinity, undefined.
import json, re, sys
from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:8765/index.html'
MOD=[('Vegg','Sette opp ny vegg'),('Vegg','Rive vegg eller lage døråpning'),('Gulv','Legge laminat eller parkett'),('Tak og loft','Beregne takkonstruksjon'),
     ('Terrasse og hage','Bygge ny terrasse'),('Terrasse og hage','Pergola'),('Trapp','Bygge trapp'),('Fasade','Ny kledning')]
VERDIER=['0','','-3','2,5','9999','0.001','abc']
SETT="""([i,v])=>{const el=[...document.querySelectorAll('main input')].filter(e=>e.offsetParent!==null)[i]; if(!el) return 'mangler';
 const s=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set; s.call(el,v); el.dispatchEvent(new Event('input',{bubbles:true})); el.dispatchEvent(new Event('change',{bubbles:true})); return el.value}"""
BAD=re.compile(r'NaN|Infinity|undefined|\[object Object\]')
res=[]
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':393,'height':852},is_mobile=True,has_touch=True)
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    for d,n in MOD:
        pg.goto(BASE); pg.wait_for_timeout(2200)
        pg.locator('[data-tf="hjem-fiks"]').click(); pg.wait_for_timeout(300)
        pg.get_by_text(d,exact=True).first.click(); pg.wait_for_timeout(300)
        pg.get_by_text(n,exact=True).first.click(); pg.wait_for_timeout(300)
        pg.locator('[data-tf="fiks-vei-modul"]').click(); pg.wait_for_timeout(900)
        typer=pg.evaluate("()=>[...document.querySelectorAll('main input')].filter(e=>e.offsetParent!==null).map(e=>e.type)")
        funn=set(); e0=len(errs)
        for i,t in enumerate(typer):
            if t not in ('number','text','') : continue
            for v in VERDIER:
                pg.evaluate(SETT,[i,v]); pg.wait_for_timeout(60)
                txt=pg.locator('main').inner_text()
                for m in BAD.finditer(txt):
                    s=txt[max(0,m.start()-50):m.end()+10].replace('\n',' | ')
                    funn.add('felt %d=%r: …%s…'%(i,v,s))
                if len(errs)>e0: funn.add('felt %d=%r: JS-FEIL %s'%(i,v,errs[-1])); break
                if pg.locator('main').count()==0 or len(txt)<30: funn.add('felt %d=%r: TOM SKJERM'%(i,v)); break
        res.append([d,n,len(typer),sorted(funn)[:12]])
        print(d,'/',n,'felt:',len(typer),'funn:',len(funn)); [print('   ',f) for f in sorted(funn)[:12]]
    json.dump(res,open('modulfuzz.json','w'),ensure_ascii=False,indent=1); b.close()
