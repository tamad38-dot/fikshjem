import json,sys
from playwright.sync_api import sync_playwright
J=[j for j in json.load(open('jobber.json')) if j[2] and not j[3]]
VELG=[int(x) for x in sys.argv[1].split(',')] if len(sys.argv)>1 else None
res=[]
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':393,'height':852},device_scale_factor=1.5,is_mobile=True,has_touch=True)
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://127.0.0.1:8765/index.html'); pg.wait_for_timeout(4000)
    for i,(d,n,g,*_) in enumerate(J):
        if VELG is not None and i not in VELG: continue
        try:
            pg.evaluate("location.hash=''"); pg.goto('http://127.0.0.1:8765/index.html'); pg.wait_for_timeout(2200)
            pg.locator('[data-tf="hjem-fiks"]').click(); pg.wait_for_timeout(500)
            pg.get_by_text(d,exact=True).first.click(); pg.wait_for_timeout(450)
            pg.get_by_text(n,exact=True).first.click(); pg.wait_for_timeout(450)
            pg.locator('[data-tf="fiks-vei-film"]').click(); pg.wait_for_timeout(600)
            f=pg.locator('[data-tf="ugla-film"]'); k=f.locator('button[aria-label^="Steg "]').count()
            f.locator('button[aria-label="Steg %d"]'%max(1,(k+1)//2)).click(); pg.wait_for_timeout(2600)
            f.locator('canvas').screenshot(path='katalog/%02d-a.png'%i)
            f.locator('button[aria-label="Steg %d"]'%k).click(); pg.wait_for_timeout(4700)
            f.locator('canvas').screenshot(path='katalog/%02d-b.png'%i)
            res.append([i,d,n,g,'ok'])
        except Exception as e:
            res.append([i,d,n,g,'FEIL '+str(e)[:80]])
        json.dump(res,open('katalog/res.json','w'))
    json.dump({'res':res,'errs':errs[:10]},open('katalog/res.json','w')); b.close()
