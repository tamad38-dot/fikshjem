# Klikktester (Playwright)

Testene åpner appen i en mobilvisning (393 × 852) og klikker seg gjennom den.
De forventer at det ferdige bygget serveres på http://127.0.0.1:8765/
(f.eks. `npx vite preview --port 8765`, eller `python3 -m http.server 8765 -d dist`).

Kjør alt: `bash kjor-alle.sh`. Krever `pip install playwright` og `playwright install chromium`.

| Test | Hva den sjekker |
|---|---|
| `systest.py` | Alle faner, hjemkort, profil, alle 47 jobber og hver vei i hver jobb, søk og verktøysidene. Tom skjerm, JS-feil, 404, innhold utenfor skjermen. Resultat: `systest/res.json`. |
| `funk.py` | AI-reglene: fagfolk-jobber stoppes før AI spørres, ingen AI uten nøkkel/telefon-AI, «ikke kildebelagt». |
| `verktoytest.py` | Verktøysidene: ingen tyrkisk tekst, rød prikk, vinkel og kapp. |
| `rodprikk-ramme-zoom.py` | Rød prikk: rammer, navn, zoom med to fingre. |
| `samleliste.py` (v25) | To moduler i samlelisten → «Send alt» → begge havner i handlelisten. |
| `komma.py` (v25) | «2,4» skrevet med tastaturet blir 2,4 m og areal 7,2 m². |
| `lagring.py` (v25) | Modulverdier og handleliste overlever at appen lukkes og åpnes. |
| `flyt.py` (v25) | «1 Mål … 5 Kontroll» hopper til riktig del i alle åtte modulene. |
| `modulfuzz.py` (v25) | Alle tallfelt i alle moduler fylles med 0, tomt, -3, 2,5, 9999, 0.001, abc: ingen NaN, Infinity, krasj. |
| `overflow.py` (v25) | Ingen knapp/felt stikker ut av kortet sitt, på alle skjermer og jobbveier. |
| `kontrast.py` (v25) | Ingen tekst med for svak kontrast (f.eks. hvit tekst på hvitt kort). Gjelder HTML-tekst; tekst inne i tegningene (SVG) sjekkes med øyet. |
| `romplan-test.mjs` (v26) | `node romplan-test.mjs`: LiDAR-skann → rom. Dreid rektangel og L-rom med vegger som stikker forbi hverandre, dør og vinduer på riktig vegg, brystning, takhøyde, iOS 17-gulvpolygon, feilmeldinger. |
| `lidar.py` (v26) | LiDAR-flyten med SIMULERT telefon (`lidar-eksempel.json`): «📏 Mål» fyller feltet og regner på nytt, romskanning lager rom + dør + vinduer + takhøyde og lagrer dem. Uten telefon vises ingen LiDAR-knapper. |
| `katalog.py` | Tar bilder av tegnefilmen for hver jobb (`katalog/NN-a.png`). |

`jobber.json` lages fra `FIKS_DELER` (se katalog.py).

`bygg-uten-nett/` er bare for AI-økter som ikke når npm: bygger med esbuild + Tailwind uten `npm install`.
