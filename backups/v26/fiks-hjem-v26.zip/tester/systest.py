import json, time
from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:8765/'
J=json.load(open('jobber.json'))
R=[]; ERR=[]; NET=[]
def rapport(): json.dump({'R':R,'ERR':ERR,'NET':NET},open('systest/res.json','w'),ensure_ascii=False,indent=0)
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':393,'height':852},device_scale_factor=1,is_mobile=True,has_touch=True)
    pg=ctx.new_page(); cur={'s':'start'}
    pg.on('pageerror',lambda e:ERR.append([cur['s'],'pageerror',str(e)[:200]]))
    pg.on('console',lambda m:ERR.append([cur['s'],'console',m.text[:200]]) if m.type=='error' else None)
    pg.on('response',lambda r:NET.append([cur['s'],r.status,r.url]) if r.status>=400 else None)
    def sjekk(navn, shot=False):
        cur['s']=navn
        pg.wait_for_timeout(350)
        info=pg.evaluate("()=>({tekst:(document.getElementById('root')||document.body).innerText.length, bredde:document.documentElement.scrollWidth, vw:innerWidth, bredest:(()=>{let w=0,el='';document.querySelectorAll('#root *').forEach(e=>{const r=e.getBoundingClientRect();if(r.right>innerWidth+2&&r.width>0&&getComputedStyle(e).position!=='fixed'){const x=Math.round(r.right);if(x>w){w=x;el=e.tagName+'.'+String(e.className).slice(0,50)+' '+(e.innerText||'').slice(0,30)}}});return [w,el]})()})")
        ok = info['tekst']>20
        over = info['bredde']>info['vw']+2
        R.append([navn, 'OK' if ok else 'TOM SKJERM', 'TASER' if over else '', info['bredest'] if over else ''])
        if shot or not ok or over: pg.screenshot(path='systest/%03d.png'%len(R))
        rapport()
    def hjem():
        pg.goto(BASE+'index.html'); pg.wait_for_timeout(2600)
    def klikk(loc, navn):
        try:
            loc.first.click(timeout=4000); pg.wait_for_timeout(500); sjekk(navn)
        except Exception as e:
            R.append([navn,'KLIKK-FEIL',str(e)[:120],'']); rapport()
    # 1 hjem + faner
    hjem(); sjekk('Hjem',True)
    for t in ['guides','scan','cart','profile','home']:
        klikk(pg.locator('[data-tf="tab-%s"]'%t),'Fane '+t)
    # 2 hjem-kort
    for d in ['hjem-skann','hjem-beregn','hjem-bolig','hjem-fiks']:
        hjem(); klikk(pg.locator('[data-tf="%s"]'%d),'Hjemkort '+d)
    hjem(); pg.mouse.wheel(0,1400); pg.wait_for_timeout(400); sjekk('Hjem nederst',True)
    # 3 profil: alle knapper med data-tf i profilen
    hjem(); pg.locator('[data-tf="tab-profile"]').click(); pg.wait_for_timeout(600)
    pk=pg.locator('#root button[data-tf]').evaluate_all('e=>e.filter(x=>!x.disabled).map(x=>x.dataset.tf)')  # deaktiverte knapper (f.eks. «Lagre» uten nøkkel) hoppes over
    for d in pk:
        if any(x in d for x in ['fjern','slett','logg','tab-','nullstill']): continue
        hjem(); pg.locator('[data-tf="tab-profile"]').click(); pg.wait_for_timeout(500)
        klikk(pg.locator('[data-tf="%s"]'%d),'Profil '+d)
    # 4 alle deler og jobber, og hver vei i jobben
    for (d,n,*_) in J:
        hjem(); pg.locator('[data-tf="hjem-fiks"]').click(); pg.wait_for_timeout(500)
        try:
            pg.get_by_text(d,exact=True).first.click(); pg.wait_for_timeout(400)
            pg.get_by_text(n,exact=True).first.click(); pg.wait_for_timeout(500); sjekk('Jobb: %s / %s'%(d,n))
        except Exception as e:
            R.append(['Jobb: %s / %s'%(d,n),'KLIKK-FEIL',str(e)[:100],'']); rapport(); continue
        veier=pg.locator('[data-tf^="fiks-vei-"]').evaluate_all('e=>e.map(x=>[x.dataset.tf,x.tagName,x.getAttribute("href")||""])')
        for (v,tag,href) in veier:
            if tag=='A':
                cur['s']='Lenke %s %s'%(n,v)
                r=pg.request.get(BASE+href.lstrip('./').lstrip('/')) if href else None
                R.append(['Lenke: %s / %s -> %s'%(n,v,href),'OK' if (r and r.ok) else 'LENKE-FEIL','','']); rapport(); continue
            try:
                pg.locator('[data-tf="%s"]'%v).click(timeout=4000); pg.wait_for_timeout(700)
                sjekk('Vei: %s / %s'%(n,v))
                if pg.locator('[data-tf="ugla-lukk"]').count(): pg.locator('[data-tf="ugla-lukk"]').click(); pg.wait_for_timeout(300)
                else:
                    # gå tilbake til jobben
                    hjem(); pg.locator('[data-tf="hjem-fiks"]').click(); pg.wait_for_timeout(400)
                    pg.get_by_text(d,exact=True).first.click(); pg.wait_for_timeout(300); pg.get_by_text(n,exact=True).first.click(); pg.wait_for_timeout(400)
            except Exception as e:
                R.append(['Vei: %s / %s'%(n,v),'KLIKK-FEIL',str(e)[:100],'']); rapport()
    # 5 søk
    hjem()
    try:
        s=pg.locator('input').first; s.fill('bytte vindu'); s.press('Enter'); pg.wait_for_timeout(800); sjekk('Søk: bytte vindu',True)
        hjem(); s=pg.locator('input').first; s.fill('xyzqq'); s.press('Enter'); pg.wait_for_timeout(800); sjekk('Søk: ingen treff',True)
    except Exception as e: R.append(['Søk','KLIKK-FEIL',str(e)[:100],'']); rapport()
    # 6 verktøysider
    for f in ['index','slik-gjor-du','fasade-fra-foto','rod-prikk','vinkel-kapp','fasadetegning']:
        pg.goto(BASE+'verktoy/%s.html'%f); pg.wait_for_timeout(1500); cur['s']='Verktøy '+f
        info=pg.evaluate("()=>({t:document.body.innerText.length,b:document.documentElement.scrollWidth,v:innerWidth})")
        R.append(['Verktøy: '+f,'OK' if info['t']>20 else 'TOM','TASER' if info['b']>info['v']+2 else '','']); pg.screenshot(path='systest/v-%s.png'%f); rapport()
    rapport(); b.close()
