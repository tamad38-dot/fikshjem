# Fiks hjem v24 — v23-3d üzerine yapılan düzeltmeler (25–26.09.2026)

## 1. Veriler artık kaybolmuyor
- Eskiden: prosjektler, handleliste ve byggemoduler sadece localStorage'daydı. iOS yer açmak için bunu silebilir.
- Şimdi: `src/lib/lagring.ts` her yazılanı Capacitor Preferences'a da kopyalıyor (normal uygulama verisi). Açılışta geri yüklüyor. Eski veriler ilk açılışta otomatik taşınıyor. Tarayıcıda hiçbir şey değişmiyor.

## 2. Capacitor eklendi (iPhone uygulaması için)
- `package.json`: @capacitor/core, @capacitor/ios, @capacitor/cli (8.5.2), @capacitor/preferences (8.0.1).
- `capacitor.config.json`: webDir = dist.
- **KONTROL ET:** `appId` şu an `no.fikshjem.app`. App Store Connect / TestFlight'taki Bundle ID farklıysa bunu onunla değiştir.

## 3. Apple'ın telefon-içi AI'sı (Foundation Models)
- `native-plugins/fiks-lokal-ai/`: Swift eklentisi. iOS 26+ ve Apple Intelligence açık iPhone'da çalışır. Ücretsiz, internetsiz, anahtarsız.
- `src/lib/lokalAI.ts`: sıra şu: önce telefonun AI'sı, yoksa kullanıcının kendi anahtarı, o da yoksa AI yok.
- Şimdilik bağlı olan yer: çizimlere fagtekst yazma (`fagtekst.functions.ts`). Diğer AI yerleri (fotoğraf okuma, ürün tarama) resim istiyor; Apple'ın resim desteği iOS 27 ile geliyor.
- **TEST EDİLMEDİ:** Swift kodu Xcode olmadan yazıldı. İlk test: Mac'te Xcode 26 ile derleme.

## 4. Yeni araçlar uygulamada
- `public/verktoy/slik-gjor-du.html`: çizgi film motoru (kapı açıklığı + teras, NO/TR).
- `public/verktoy/fasade-fra-foto.html`: fotoğraf + kendi ölçün = cephe çizimi.
- Ana ekranda iki yeni kart: "Slik gjør du" ve "Fasade fra foto". İnternetsiz çalışır.

## 5. Fiyat: 80 kr
- Kodda satın alma ekranı yok, olması da gerekmiyor: 80 kr tek seferlik fiyat App Store Connect'te **ücretli uygulama** olarak ayarlanır. Kodda değişiklik gerekmez.
- Not: fiyatı değiştirmek için App Store Connect → Uygulama → Fiyatlandırma ve Kullanılabilirlik.

## 6. Taramada bulunan hatalar (düzeltildi)
- Tüm kaynak dosyalar TypeScript derleyicisiyle tarandı (yazım hatası ve tanımsız isim kontrolü).
- `TamerFixApp.jsx`: fotoğraf günlüğünün (BildeDagbok) yardımcıları `bildeNokkel`, `bildeIndeksNokkel`, `BILDE_FASER` silinmişti. Ekran kullanılsaydı uygulama çökerdi. Geri eklendi.
- `TamerFixApp.jsx`: `S.smaa` yazı stili tanımsızdı (uyarılar kartındaki küçük yazı stilsiz kalıyordu). Eklendi.
- Başka yazım hatası veya tanımsız isim bulunmadı.

## 7. Ana ekran eski haline döndü (26.09)
- v23'te uygulama "ModernFiksApp" adlı başka bir ekranla açılıyordu (6 kutucuk, farklı yazı tipi). Asıl Fiks hjem ekranı (arka planda usta, Skann/Beregn, Byggemoduler, Boligen, "Fra Fiks hjem") yine kodun içindeydi ama açılmıyordu.
- `src/main.tsx` artık doğrudan asıl ekranı (TamerFixApp) açıyor. ModernFiksApp.jsx dosyası silinmedi, sadece kullanılmıyor.
- Ana ekrana yeni kart: **"Slik gjør du & verktøy"** → `public/verktoy/index.html`.

## 8. Masaüstündeki eksik araçlar eklendi (26.09)
- `public/verktoy/rod-prikk.html` (kırmızı nokta, tam sürüm)
- `public/verktoy/vinkel-kapp.html` (derece / kesim açısı)
- `public/verktoy/fasadetegning.html` (ölçüden cephe çizimi)
- Hepsinin sol üstünde "‹ Verktøy" geri düğmesi var.


## 9. Tek kapı: "Hva vil du fikse?" (26.09)
- Üç ayrı giriş (Byggemoduler "Hva skal du bygge?", Oppussing "Hva skal pusses opp?", Fagområder) tek bir resimli ekranda birleşti.
- Akış: evin bölümü (14 resimli kart: Vegg, Gulv, Dør, Vindu, Tak og loft, Terrasse og hage, Trapp, Fasade, Bad, Kjøkken, Strøm, Rør og varme, Garasje og bod, Hele huset) → ne yapacaksın (ör. Vegg: sette opp, rive/døråpning, male, tapet, panel, isolere, flis) → iş sayfası.
- İş sayfasında hepsi bir arada: Steg for steg (kılavuz), Beregn og tegn (modül), tegnefilm, araç, uyarılar ve seviye etiketi (Kan gjøres selv / Delvis selv / Kan kreve søknad / Krever fagfolk).
- Ana ekranda "Oppussing" ve "Byggemoduler" kartları yerine tek resimli "Hva vil du fikse?" kartı var. Alt menüdeki pusula da buraya açılıyor.
- Kılavuzdan, hesaptan veya AI'dan "Tilbake" deyince kullanıcı kaldığı işe dönüyor.
- Eski ekranlar ve kılavuzlar silinmedi, sadece bu kapının arkasına alındı.
- Kod: `TamerFixApp.jsx` içinde `FIKS_DELER` (liste) ve `FiksAltScreen`. Yeni iş eklemek için sadece listeye bir satır eklemek yeterli.

## 10. AI: rehberde olmayan iş (26.09)
- Rehberi olmayan işte (ör. tapet, panel) veya aramada sonuç çıkmazsa "Få forslag fra AI" çıkıyor, iş adı hazır yazılı geliyor.
- Kullanıcının kendi anahtarı varsa AI önce internette arama yapıyor (Norveç kaynakları: produsent, Byggforsk, DiBK, DSB). Okuduğu sayfalar "Sider AI-en leste" başlığıyla listeleniyor.
- Anahtar yoksa ve telefonda Apple AI varsa, telefonun AI'sı cevap veriyor (arama yapmadan, ücretsiz).
- Tüzük korumaları aynı kaldı: "Dette er ikke kildebelagt" uyarısı, tek kaynaklı rakamlar "sjekk selv" bölümüne gidiyor, elektrik gibi fagfolk işlerine yöntem verilmiyor (AI'ya hiç sorulmadan engelleniyor).
- TEST EDİLMEDİ: gerçek AI cevabı (anahtar gerekli) ve web araması. Ekranlar ve akış test edildi.

## 11. Baykuş çizgi film her işte (26.09)
- Yeni motor: `UglaFilm` (TamerFixApp.jsx). Kılavuz adımlarından otomatik film: baretli baykuş konuşur, adıma uygun alet çalışır (metre, testere, matkap, çekiç, rulo, su terazisi, spatula, kalem), yüzey adım adım biter (boya, tapet, fayans, tahta, kaplama, kiremit, yalıtım), sonunda konfeti.
- Rehberi olan her işte "Se tegnefilm med ugla" düğmesi var. Kapı ve terasta el yapımı filmler kaldı.
- Rehberi olmayan işte "Lag tegnefilm med ugla": AI önce adımları yazar, sonra "Se forslaget som tegnefilm" ile film olur (AI uyarısıyla).
- Fagfolk işlerinde filmin üstünde "Krever fagfolk" uyarısı çıkar.
- Film kendi rakam eklemez, sadece kılavuzun yazdığını gösterir.

## 12. Rød prikk yeniden yazıldı (26.09)
- Nokta koyunca sarı olur: sürükleyerek ya da resme dokunarak yeri değiştirilir. "✓ Ferdig med punkt N" ile kilitlenir.
- Kilitli noktalar sırayla siyah çizgiyle bağlanır (beyaz kenarlı, her fotoğrafta görünür). Her yeni noktadan sonra "Mål fra punkt 1 til 2" sorulur, çizginin üstünde "2,40 m" ya da "? m" yazar.
- Konmuş bir noktaya dokununca: Flytt punktet / Ikke tydelig. İki nokta seçince aralarına ekstra ölçü (ör. köşegen) girilir.
- Ondalık virgül kabul edilir (2,40). Açılır pencereler kaldırıldı, bütün yazılar Norveççe.

## 13. Uygulamada Türkçe kalmadı (26.09)
- Vinkel og kapp ve Fasadetegning tamamen Norveççe. Ondalık virgül kabul ediliyor ve sonuçlar virgülle gösteriliyor (89,9°).
- Fasadetegning'de telefonda taşan pencere tablosu düzeltildi, açılır pencereler kaldırıldı.
- Çizgi film sayfasında TR seçeneği yerine EN (İngilizce) var: NO / EN.
- Kodun içinde ekranda görünen Türkçe yazı yok. (Bu açıklama dosyası Türkçe kaldı, sadece senin için.)

## 14. AI anahtarsız: telefonun kendi AI'ı (27.09)
- "Spørre AI om en jobb" artık anahtar istemiyor: Apple Intelligence olan iPhone'da (iOS 26+) telefonun kendi modeli cevaplıyor. Anahtar hâlâ seçenek olarak duruyor (internette arama + okuduğu siteler listesi için).
- Ürün tarama anahtarsız çalışıyor. Telefon barkodu ve etiketteki yazıyı Vision ile okuyor; bu her iPhone'da var, Apple Intelligence gerekmiyor. Apple Intelligence varsa okunan yazıdan ürün adını ve kategoriyi de çıkarıyor. Sonuçta "ikke kildebelagt" rozeti ve barkod görünüyor. Tahmini fiyat gösterilmiyor ("sjekk selv" kuralı).
- Swift eklentisine (native-plugins/fiks-lokal-ai) `lesBilde` metodu eklendi: barkod ve OCR (Norveççe dahil), sonra iOS 26 metin modeli. iOS 27'nin resmi doğrudan gören modu kodda hazır ama `FIKS_IOS27_BILDE` bayrağıyla kapalı. Xcode'da API adları kontrol edilince açılacak.
- ProSkjerm yeniden yazıldı. Üç grup var: "Virker alltid, uten AI", "Med telefonens egen AI – uten nøkkel" ve "Med egen nøkkel i tillegg".
- Ekrandaki Norveççe yazılarda æ/ø/å düzeltildi, yaklaşık 310 yerde (nokkel→nøkkel, pa→på, nar→når, gar→går, a→å …). Arama kelime listelerine dokunulmadı.
- Test edilmedi: Swift kodu. Gerçek iPhone'da Xcode ile denenmesi lazım.

## 15. Adım adım kılavuzda yeni çizimler (27.09)
- Her adımın basit gri çizimi yerine artık baykuşlu canlı çizim var (çizgi filmle aynı motor). Baykuş adımı söylüyor, alet çalışıyor, yüzey o adıma kadar doluyor. Döngüde oynuyor; ekran dışındayken duruyor, "azaltılmış hareket" açıksa sabit resim gösteriyor.
- Kartın altında "🦉 Se hele jobben som tegnefilm" düğmesi: bütün işi film olarak açar.
- Test sürümünde kartın düzeni bozuktu ("ForrigeNeste steg", "Du trengerSe…"). Sebebi uygulamanın kendi stil dosyasının test sürümüne girmemesiydi, düzeltildi. Gerçek uygulamada bu sorun yoktu.
- Dosyalar: Instruksjon3D.jsx (renderTegning), TamerFixApp.jsx (UglaSteg, StepGuide), styles.css.

## 16. Çizgi filmler artık işin konusunu gösteriyor (27.09)
- Sorun: bütün filmler aynı "duvarı boya/kapla" sahnesini kullanıyordu ("Bytte vindu" filminde boş duvar vardı).
- Çizim motoruna 18 yeni sahne eklendi. İş parça parça kuruluyor: pencere (açıklık → kasa → takozlar → pencere → dolgu köpüğü → denizlik → pervaz), kapı, levegg/çit, teras (yukarıdan: temel → kiriş → döşeme), teras boyama, merdiven, parke/laminat, duvar iskeleti, ıslak hacim (eğim → membran → fayans → süzgeç), klozet, lavabo/musluk, garaj/depo, çatı kiremidi.
- Usta işleri (elektrik, şarj kutusu, ısı pompası, havalandırma, davlumbaz, soba/şömine) kendi sahnelerinde ve kırmızı "FAGPERSON" damgasıyla gösteriliyor. Elde alet yok, çünkü bunları kendin yapmıyorsun.
- Hangi sahnenin çıkacağına önce kılavuzun anahtarı, sonra işin adı karar veriyor (`uglaScene`). İç/dış mekân da sahneye göre seçiliyor (`uglaUte`). Örneğin "Isolere loft" artık içeride.
- Katalogdaki rehberi olan 32 işin hepsi tek tek açılıp kontrol edildi, JS hatası yok.

## 17. Sistem kontrolü ve test (27.09)
Tıklama testi: 171 ekran/adım. Bütün sekmeler, ana ekran kartları, profil, 14 bölümdeki 47 işin hepsi ve her işin bütün yolları (rehber, film, modül, çatı, tadilat, araç linkleri), arama ve 6 araç sayfası.
- Sonuç: boş ekran yok, JS hatası yok, kırık link yok, ekrandan taşan içerik yok.
- AI güvenlik kuralları: 14/14 geçti. Usta işi (sigorta kutusu, banyoda priz) AI'ya hiç sorulmadan durduruluyor; anahtar ya da telefon AI'ı yoksa istek gönderilmiyor; AI cevabı "ikke kildebelagt" olarak işaretleniyor.
- Araçlar: 12/12 geçti. Hiçbir sayfada Türkçe yazı yok; Rød prikk'te nokta, çizgi ve virgüllü ölçü (2,40) çalışıyor.
- Tarama ve ProSkjerm testleri tekrar geçti.

Bulunan ve düzeltilen hatalar:
1. **Önemli:** package.json'daki `"sideEffects": false` yüzünden gerçek derlemede telefonun AI modülü (lokalAI) atlanabiliyordu, yani iPhone'da AI hiç çalışmayabilirdi. Ayar kaldırıldı, main.tsx modülü açıkça kullanıyor.
2. Çıktı alma hatalarında `window.alert` açılıyordu (fasade, fagtegninger, kommunelevering). Bunun yerine ekranın altında kendiliğinden kaybolan bir mesaj çıkıyor (`src/lib/beskjed.js`).
3. Swift eklentisi: barkod listesi Capacitor'ün kendi tipine (JSObject) çevrildi; derleme hatası vermesin diye.

Test edilemeyenler: 3D ekranlar (test ortamında three.js yok), Swift kodu (Xcode lazım), gerçek AI çağrıları. Testler: v24/tester/.

## 18. Rød prikk: zoom, çerçeve ve isim + yeni fasad çizimi (02.10)
**Rød prikk**
- Zoom: iki parmakla kıstırınca resim büyüyor, iki parmakla kaydırılıyor. Tek parmak eskisi gibi nokta koyuyor. PC'de + / − / Tilpass düğmeleri. Noktalar zoom'da da parmağın altına düşüyor ve ekranda aynı boyda kalıyor.
- Çerçeve: köşeler sırayla konur, en az 3 köşeden sonra "✓ Ferdig – lukk rammen" çıkar. Otomatik kapanmaz, sen basınca kapanır (kaç köşe olursa olsun). Kapanınca son kenarın ölçüsü sorulur.
- İsim ve numara: kapanınca "Hva er dette?" sorulur. Vindu / Dør / Vegg / Tak / Annet seçilince kendiliğinden numaralanır (Vindu 1, Vindu 2, Dør 1). İstersen kendi ismini yazarsın; listede sonradan da değiştirebilirsin.
- Bir fotoğrafta birden çok çerçeve olabilir. Her çerçevenin noktaları 1'den başlar, kenarları A, B, C, D diye harflenir. Ölçüler çerçevenin altında gruplanır, karışmaz.
- "Angre" kapanmış son çerçeveyi önce tekrar açar.
- Düzeltilen eski hata: ölçek hesabı fotoğrafın en/boy oranını hesaba katmıyordu, kare olmayan fotoğrafta dikey kenarlar yanlış çıkıyor ve boşuna "ölçüler uyuşmuyor" uyarısı veriyordu.

**Fasade fra foto**
- Alttaki teknik çizim gerçek mimari fasad çizimi gibi yeniden yazıldı (Maxbo Proff / Norhus örneklerine göre): beyaz kağıt, kalın-ince çizgi hiyerarşisi, sıra sıra kiremit, mahya, vindski, hjørnekasser, kledning (stående veya liggende), görünen grunnmur, karmlı-çerçeveli pencereler (isteğe bağlı sprosser), vannbrett, kapı panelleri, balkon korkuluğu, zemin çizgisi ve tarama, ölçü zincirleri, aks daireleri (1, 2), kotlar (Terreng / Takfot / Møne) ve sağ altta çizim başlığı ("FASADE MOT SØR", tarih).
- Yeni seçimler: Fasadetype (Langvegg / Gavlvegg), Kledning (stående / liggende), Fasade mot (nord/sør/øst/vest), Sprosser, Synlig grunnmur (mm).
- Yeni eleman: Pipe (baca), fotoğrafta işaretlenip çizime şapkasıyla çıkıyor.
- Fotoğraf adımlarında da iki parmakla zoom var (köşeleri ve pencereleri rahat işaretlemek için).
- Kural aynı: bütün ölçüler senin girdiğin ölçülerden; desenler sadece görünüş.

Ortak parça: `public/verktoy/zoom.js` (FixOne ortak deposuna da ait). Test: `tester/rodprikk-ramme-zoom.py` 15/15, araç testleri 12/12.

## Eksik kalan (bu pakette yok)
- Fasade aracının köşeden sürükleme sürümü sesli oturumda kaybolmuştu; buradaki ilk sürüm.
