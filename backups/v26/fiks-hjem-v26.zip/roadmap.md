# Roadmap

- [x] Bygg interaktiv 3D-romvisning med mål og iPhone-vennlige kamerakontroller
- [x] Legg til visuell og numerisk plassering av alle byggemoduler
- [x] Lagre takhøyde og modulplasseringer per eiendom
- [x] Utvid RoomPlan-broen med høyde og objekter
- [x] Forny logo, hovedskjerm, prosjektbilder og romtegninger
- [x] Verifiser siste flyt på desktop og mobil
- [x] Erstatt enkle hus- og kategoriillustrasjoner med naturtro prosjektbilder
- [x] La bilder fylle rammene og legg inn den komplette listen med nye jobber
- [x] Legg til søk og filtrering i Byggemoduler etter type, størrelse og veiledende pris
- [x] Gjør alle jobbgruppene tilgjengelige som mål- og kostnadsmoduler
- [x] Test de nye modulene og søket på mobil og stor skjerm
- [x] Beregn modulantall og jobber per m² fra rommålingen og vis totalpris i 3D-rommet
- [x] Rett feil i totalt stolpeantall, dybdejustering og veggplassering i 3D
- [x] Forny gamle dekorative illustrasjoner med profesjonelle prosjektbilder
- [x] Forny takprosjektets hovedbilde og stegminiatyrer med realistiske arbeidsfoto
- [x] Legg inn et reelt norsk eksempelprosjekt med rom, vegger, tak, fagjobber og totalpris i 3D
- [x] Forny 3D-rommets tak med ekte takbilder, korrekt takform og målte høyder

## Nye moduler (16.09)
- Ferdige byggmoduler med egne tegninger, innsetting og bytte i 3D
- Teknisk fasadetegning for/etter med LiDAR-skann og utskrift til kommunen
- Takjobber: takstige og snofanger, taklister, takstein, takvindu med foto og pris i 3D

## Detaljerte arbeidstegninger (16.09)
- [x] Innfør felles FIKS-lignende 3D-tegnestandard i alle jobbguider
- [x] Legg til komplett sluttsteg og ferdigkontroll i alle arbeidsforløp
- [x] Legg til manuell navigasjon, automatisk avspilling, pause og omstart
- [x] Oppgrader ferdigmoduler og fasadeutskrift med samme delnummerstandard
- [x] Kontroller felles stegvisning på mobil og stor skjerm uten visnings- eller konsollfeil

## Fra tegning til levering (16.09)
- [x] Bygg 3D-rommet fra hele den opplastede byggtegningen med målestokk
- [x] Leveranseside til kommunen med adresse, gnr/bnr og vedleggsliste
- [x] Bytt vinduer, dører og moduler direkte i 3D med oppdatert pris og fagtegning
- [x] Fasadeverktøyet vist som før/etter i 3D-rommet
- [x] Kontrollert på mobil og stor skjerm uten kjørefeil
