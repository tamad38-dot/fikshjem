# Fiks hjem

Norsk gjør-det-selv-app: skann og mål, 2D/3D/4D, materialliste, bygg steg for steg.
Vanlig Vite + React-prosjekt – ingen leverandørbinding.

## Kjør lokalt
```sh
npm install
npm run dev      # utvikling
npm run build    # lager dist/ (statiske filer)
```

## Publisere
- Web: last opp `dist/` til Netlify, Vercel, Cloudflare Pages eller GitHub Pages.
- iOS/Android: Capacitor med `webDir: "dist"`.

## AI
Ingen innebygd AI-kostnad. AI-funksjoner virker bare med brukerens egen API-nøkkel.

## iPhone-appen (Capacitor) — på Mac
```sh
npm install
npm run build
npx cap add ios        # bare første gang
npm run ios            # bygger, synker og åpner Xcode
```
- `npm run ios` legger også inn iOS-tillatelsene (kamera, bilder, posisjon) og hvit statuslinje i
  `ios/App/App/Info.plist` (`scripts/ios-tillatelser.mjs`). Uten kameratekst stopper iOS appen første gang kameraet åpnes.
- Sjekk at `appId` i `capacitor.config.json` er samme Bundle ID som i App Store Connect.
- Telefonens egen AI (native-plugins/fiks-lokal-ai) krever Xcode 26 og iOS 26.
- LiDAR-måling og romskanning: native-plugins/fiks-lidar (se LES-MEG.md der).
- Data lagres i Capacitor Preferences (src/lib/lagring.ts), ikke bare i localStorage.

## Test
```sh
npm run build && npx vite preview --port 8765   # eget vindu
cd tester && bash kjor-alle.sh
```
Regler for endringer: se `AGENTS.md`.
