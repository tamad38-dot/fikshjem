# Fiks hjem v25 — v24 üzerine yapılan düzeltmeler (10.10.2026)

Başlangıç: `fiks-hjem-v24.zip` (02.10, Rød prikk zoom/çerçeve + fasad çizimi dahil).
Mac'teki `Desktop/fikshjem/v24` klasörü bundan eski (27.09'da bitiyor), yani bu zip en son sürümdü.

## Kısaca
- 14 gerçek hata bulundu ve düzeltildi. Çoğu kullanıcının doğrudan göreceği türden: yanlış ekran, listeden kaybolan malzeme, görünmeyen liste, iPhone'da çift saat, 149,90 kr yerine 14 990 kr.
- Teras hesabı yeniden kaynaklı tabloya bağlandı (tüzük: tahmin rakam yok).
- Ekrandaki Norveççe yazıda yaklaşık 320 kelimede eksik æ/ø/å düzeltildi.
- 7 yeni test eklendi. Eskileri de dahil bütün testler geçiyor (sonuçlar en altta).

## 1. «Beregn og tegn» yanlış ekranı açıyordu — DÜZELTİLDİ
- Eskiden: «Hva vil du fikse?» → iş (ör. Bygge ny terrasse) → «Beregn og tegn» deyince hesap değil, yine
  «Hva skal du bygge?» seçim listesi açılıyordu. 8 hesap modülünün hepsinde aynıydı. Kullanıcı işi iki kez seçmek zorundaydı.
- Şimdi: seçtiğin modül doğrudan açılıyor.

## 2. Teras: kaynaksız taslak yerine doğrulanmış modül — DÜZELTİLDİ (tüzük)
- v23'ten kalan `TerrasseProsjektFlyt` adlı bir taslak, asıl teras modülünün yerine geçmişti. Kendi rakamları vardı:
  «m² başına 35 vida», «temel = alan / 3», kiriş her zaman c/c 600, tahta = alan × 7,5. Hiçbiri kaynaklı değildi.
- Doğrulanmış teras modülü (NOBB kiriş tablosu, Byggforsk 526.413 direk aralığı, uyarılar, «Kilde» satırı) kodda duruyordu ama hiç açılmıyordu.
- Şimdi: doğrulanmış modül açılıyor, taslak silindi. Değerler eskisi gibi kaydediliyor (kapatıp açınca geri geliyor).

## 3. «Send alt til handlelisten»: sadece son modül listeye giriyordu — DÜZELTİLDİ
- Toplama listesine (samleliste) iki modül koyup «hepsini gönder» deyince, ikincisi birincinin üstüne yazıyordu.
  Test: teras + zemin gönderildi → listede sadece zemin vardı.
- Şimdi: ikisi de geliyor (5 kalem). Testi: `tester/samleliste.py`.

## 4. iPhone'da çift saat, sahte pil — DÜZELTİLDİ
- Uygulama kendi içinde sahte bir iOS durum çubuğu çiziyordu: saat, sinyal, wifi, hep «80» pil ve siyah ada.
  iPhone zaten kendi çubuğunu gösterdiği için ikisi üst üste geliyordu. Altta da sahte bir ana ekran çizgisi vardı.
- Şimdi: telefonda gerçek güvenli alan (safe area) kullanılıyor. Sahte çubuk sadece PC'deki telefon çerçevesi önizlemesinde görünüyor.
- `scripts/ios-tillatelser.mjs`: iPhone'da durum çubuğu beyaz yazıyla (koyu arka plan üstünde okunur).

## 5. iPhone izin metinleri eksikti — EKLENDİ
- Uygulama kamerayı (fotoğraf, ürün tarama) ve konumu (adres, hava) kullanıyor. Info.plist'te izin metni yoksa
  iOS uygulamayı kamera açıldığı anda kapatır, App Store da reddeder. Bu metinler hiçbir yerde yoktu.
- Şimdi: `npm run ios` her seferinde kamera, fotoğraf ve konum metinlerini Norveççe ekliyor (zaten varsa dokunmuyor).

## 6. Virgüllü sayılar (2,4) — DÜZELTİLDİ
- Hesap kutuları `type="number"` idi. Norveç klavyesi virgül verir; bu tür kutu «2,4»ü boş ya da 2 sayabilir.
- Şimdi: sayı klavyeli yazı kutusu. «2,4» de «2.4» de doğru okunuyor. Sonuçlar Norveççe gösteriliyor: 7,2 m² · 1,4 m (eskiden 7.2 m2).
- Alışveriş listesinde fiyat: «149,90» yazınca 14 990 kr kaydediliyordu. Şimdi 149,90 kr.

## 7. Görünmeyen yazılar ve taşan kutular — DÜZELTİLDİ
- «Bytt oppgave i denne kategorien» açılınca boş beyaz kutular çıkıyordu: yazı da beyazdı. Artık okunuyor.
- «Skann, mål og tegn» kartında beyaz yazı açık yeşil üstündeydi. Artık koyu.
- Çizimlerdeki «Bjelke / Stolpe» açıklaması beyaz üstüne beyazdı. Düzeldi.
- Alışveriş listesinde fiyat kutusu ve profilde bütçe kutusu kartın dışına taşıyordu. Düzeldi.
- Vinkel og kapp sayfasında üst boşluk iPhone çentiğini hesaba katmıyordu. Düzeldi.

## 8. Görünüm
- Alt menüde her sekmenin adı var: Hjem · Fiks · Skann · Liste · Profil (eskiden sadece «Profil» yazıyordu).
- «Hva skal du bygge?» ekranında emoji yerine gerçek fotoğraflar (diğer ekranlarla aynı).
- «1 Mål · 2 Tegn · 3 Materialer · 4 Bygg · 5 Kontroll» eskiden süstü (hep «1 Mål» yanıyordu).
  Şimdi dokununca modülün o bölümüne gidiyor (Bygg = katmanları sırayla gösteren 3D).
- «Hele huset» kartı garajın fotoğrafını kullanıyordu, artık ev fotoğrafı.

## 9. Norveççe yazım (æ ø å)
- Cevap bankasında (SVARBANK), modüllerde, çizimlerde ve hata mesajlarında yaklaşık 320 kelime düzeltildi:
  høyt, døråpningen, våtromsnorm, rømningsvindu, Bærebjelke, Møne, Prøv igjen, før du river …
- Bilerek DOKUNULMAYANLAR: arama kelime listeleri (insanlar æøå'sız da arar), kod anahtarları ('vatrom', 'Dor'),
  ve «mal/male» gibi iki anlamlı kelimelerde boya anlamında olanlar (Mal i seksjoner = boya).

## 10. Gizlilik / internetsiz
- «Slik gjør du» ve «Fasade fra foto» Google'dan yazı tipi indiriyordu (internetsiz çalışır dediğimiz sayfalar, ve Google'a bağlantı).
  Kaldırıldı; iPhone'un kendi yazı tipleri kullanılıyor.

## Yeni dosyalar
- `AGENTS.md` — kodu değiştiren her kişi/AI için kurallar (tüzük, æøå, sayı kutuları, renkler, test).
- `scripts/ios-tillatelser.mjs` — iPhone izin metinleri ve beyaz durum çubuğu.
- `fixone-ortak/` — FixOne ortak deposuna: `norsk-tall.js` (virgüllü sayı), `ios-tillatelser.mjs`, `zoom.js`.
- `tester/` — 7 yeni test + hepsini çalıştıran `kjor-alle.sh`.

## Test sonuçları (10.10.2026)
| Test | Sonuç |
|---|---|
| Sistem testi (bütün sekmeler, 14 bölüm, 47 iş, her işin bütün yolları, arama, 6 araç) | 170/170 ekran, JS hatası yok, kırık link yok, taşma yok |
| AI güvenlik kuralları (`funk.py`) | 14/14 |
| Araçlar (`verktoytest.py`) | 12/12 |
| Rød prikk çerçeve + zoom | 15/15 |
| Çizgi filmler (`katalog.py`) | 32/32 iş, JS hatası yok |
| Toplama listesi → alışveriş listesi (yeni) | Geçti (eskiden 1 modül kayboluyordu) |
| Virgüllü sayı «2,4» (yeni) | Geçti: 7,2 m² |
| Kapat-aç sonrası kayıt (yeni) | Geçti |
| «1 Mål … 5 Kontroll» düğmeleri, 8 modül (yeni) | 40/40 doğru bölüme gidiyor |
| Kötü giriş testi: 0, boş, -3, 2,5, 9999, 0.001, abc → 8 modülün 45 kutusu (yeni) | NaN/Infinity/çökme yok |
| Kutudan taşma, bütün ekranlar (yeni) | 0 |
| Okunmayan yazı (kontrast), bütün ekranlar (yeni) | 0 |

## Test edilemeyenler (dürüst liste)
- 3D ekran (three.js): buradaki ortamda internet kapalıydı, three.js kurulamadı. 3D dosyasına dokunulmadı.
- Swift eklentisi (telefonun AI'ı): Xcode lazım. Kod okundu, değiştirilmedi.
- Gerçek iPhone: durum çubuğu ve izinler mantıken doğru, ama ilk gerçek test senin TestFlight derlemen.
- Derleme bu ortamda `vite` yerine aynı kaynaktan esbuild + Tailwind ile yapıldı (npm'e erişim yoktu).
  Mac'te `npm install && npm run build` normal şekilde çalışmalı.

## Sana kalan kontrol
- `capacitor.config.json` → `appId` hâlâ `no.fikshjem.app`. App Store Connect'teki Bundle ID farklıysa değiştir.
- Mac'te bir kez: `npm install` → `npm run ios`. Xcode açılınca Info.plist'te 3 izin metnini göreceksin.
