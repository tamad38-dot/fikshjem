# Fiks hjem – regler for den som endrer koden (menneske eller AI)

Eieren skriver ikke kode selv. Alt som endres her må være forklart, testet og mulig å stole på.

## Tüzük (grunnreglene)
1. **Ingen tall uten kilde.** Mål, spenn, avstander og mengder kommer fra den kildebelagte regelmotoren
   (`BJELKE_SPENN`, `STOLPE_SPENN`, sperretabellen osv. i `TamerFixApp.jsx`) eller fra brukerens egne mål.
   Lag aldri en ny «enkel» kalkulator med tommelfingertall ved siden av. (v25 fjernet `TerrasseProsjektFlyt`
   av akkurat denne grunnen.) Mangler kilde: skriv «sjekk selv» / «ikke verifisert», ikke et gjettet tall.
2. **AI regner aldri.** AI kan lese og foreslå tekst. Matematikken gjør appen. AI-svar merkes «ikke kildebelagt».
   Fagfolk-jobber (f.eks. elektrisk arbeid) stoppes før AI spørres.
3. **Norsk på skjermen, med æ ø å.** Desimalkomma i visning (`norskVisning`, `tilVisning`), m² og m³.
   Søkeord-lister (`sok:`, `ord:`) og koder/nøkler skal IKKE endres – de er bevisst uten æøå.
4. **Tallfelt = `Felt` / `TallInput`.** Ikke `type="number"`: norsk tastatur gir komma. `tall()` leser både «2,4» og «2.4».
5. **iPhone:** ingen tegnet statuslinje eller hjemstrek på telefon – bruk `env(safe-area-inset-*)`.
   Etter `npx cap add ios` / `cap sync` kjøres `node scripts/ios-tillatelser.mjs` (kamera-, bilde- og posisjonstekster).
6. **Lyse kort = mørk tekst.** `U.*` er farger for mørk bakgrunn, `F.*` for papir/lyse flater. Ikke bland `U.ramme` (hvit) med `F.flate` (hvit).
7. **LiDAR:** telefonen måler, appen regner. `native-plugins/fiks-lidar` (Swift) → `src/lib/lidar.ts` setter
   `window.TAMERFIX_MAAL_AR` / `TAMERFIX_SKANN_ROM` → `lesBro()` → knappene (`OlcKnapp`, LiDAR-kortet i `Rom`).
   Omformingen fra skann til rom ligger i `src/lib/romplan.js` og har egen test. Nye lengdefelt: bruk `FeltMedAR`.
8. **Nye fellesdeler** (rød prikk, vinkel, tallformat …) legges også i `fixone-ortak/` (FixOne-depotet).

## Før du leverer
```sh
npm run build && npx vite preview --port 8765    # eget vindu
cd tester && bash kjor-alle.sh
```
Alle testene skal stå på OK, uten JS-feil. Se `tester/LES-MEG.md`.
